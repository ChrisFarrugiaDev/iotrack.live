
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model assets
 * 
 */
export type assets = $Result.DefaultSelection<Prisma.$assetsPayload>
/**
 * Model devices
 * This table contains check constraints and requires additional setup for migrations. Visit https://pris.ly/d/check-constraints for more info.
 */
export type devices = $Result.DefaultSelection<Prisma.$devicesPayload>
/**
 * Model organisations
 * 
 */
export type organisations = $Result.DefaultSelection<Prisma.$organisationsPayload>
/**
 * Model permissions
 * 
 */
export type permissions = $Result.DefaultSelection<Prisma.$permissionsPayload>
/**
 * Model role_permissions
 * 
 */
export type role_permissions = $Result.DefaultSelection<Prisma.$role_permissionsPayload>
/**
 * Model roles
 * 
 */
export type roles = $Result.DefaultSelection<Prisma.$rolesPayload>
/**
 * Model telemetry
 * 
 */
export type telemetry = $Result.DefaultSelection<Prisma.$telemetryPayload>
/**
 * Model users
 * 
 */
export type users = $Result.DefaultSelection<Prisma.$usersPayload>
/**
 * Model codec12_commands
 * 
 */
export type codec12_commands = $Result.DefaultSelection<Prisma.$codec12_commandsPayload>
/**
 * Model user_organisation_access
 * 
 */
export type user_organisation_access = $Result.DefaultSelection<Prisma.$user_organisation_accessPayload>
/**
 * Model user_asset_access
 * 
 */
export type user_asset_access = $Result.DefaultSelection<Prisma.$user_asset_accessPayload>
/**
 * Model user_device_access
 * 
 */
export type user_device_access = $Result.DefaultSelection<Prisma.$user_device_accessPayload>
/**
 * Model files
 * 
 */
export type files = $Result.DefaultSelection<Prisma.$filesPayload>
/**
 * Model images
 * 
 */
export type images = $Result.DefaultSelection<Prisma.$imagesPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Assets
 * const assets = await prisma.assets.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Assets
   * const assets = await prisma.assets.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.assets`: Exposes CRUD operations for the **assets** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Assets
    * const assets = await prisma.assets.findMany()
    * ```
    */
  get assets(): Prisma.assetsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.devices`: Exposes CRUD operations for the **devices** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Devices
    * const devices = await prisma.devices.findMany()
    * ```
    */
  get devices(): Prisma.devicesDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.organisations`: Exposes CRUD operations for the **organisations** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Organisations
    * const organisations = await prisma.organisations.findMany()
    * ```
    */
  get organisations(): Prisma.organisationsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.permissions`: Exposes CRUD operations for the **permissions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Permissions
    * const permissions = await prisma.permissions.findMany()
    * ```
    */
  get permissions(): Prisma.permissionsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.role_permissions`: Exposes CRUD operations for the **role_permissions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Role_permissions
    * const role_permissions = await prisma.role_permissions.findMany()
    * ```
    */
  get role_permissions(): Prisma.role_permissionsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.roles`: Exposes CRUD operations for the **roles** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Roles
    * const roles = await prisma.roles.findMany()
    * ```
    */
  get roles(): Prisma.rolesDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.telemetry`: Exposes CRUD operations for the **telemetry** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Telemetries
    * const telemetries = await prisma.telemetry.findMany()
    * ```
    */
  get telemetry(): Prisma.telemetryDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.users`: Exposes CRUD operations for the **users** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.users.findMany()
    * ```
    */
  get users(): Prisma.usersDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.codec12_commands`: Exposes CRUD operations for the **codec12_commands** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Codec12_commands
    * const codec12_commands = await prisma.codec12_commands.findMany()
    * ```
    */
  get codec12_commands(): Prisma.codec12_commandsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.user_organisation_access`: Exposes CRUD operations for the **user_organisation_access** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more User_organisation_accesses
    * const user_organisation_accesses = await prisma.user_organisation_access.findMany()
    * ```
    */
  get user_organisation_access(): Prisma.user_organisation_accessDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.user_asset_access`: Exposes CRUD operations for the **user_asset_access** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more User_asset_accesses
    * const user_asset_accesses = await prisma.user_asset_access.findMany()
    * ```
    */
  get user_asset_access(): Prisma.user_asset_accessDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.user_device_access`: Exposes CRUD operations for the **user_device_access** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more User_device_accesses
    * const user_device_accesses = await prisma.user_device_access.findMany()
    * ```
    */
  get user_device_access(): Prisma.user_device_accessDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.files`: Exposes CRUD operations for the **files** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Files
    * const files = await prisma.files.findMany()
    * ```
    */
  get files(): Prisma.filesDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.images`: Exposes CRUD operations for the **images** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Images
    * const images = await prisma.images.findMany()
    * ```
    */
  get images(): Prisma.imagesDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.12.0
   * Query Engine version: 8047c96bbd92db98a2abc7c9323ce77c02c89dbc
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    assets: 'assets',
    devices: 'devices',
    organisations: 'organisations',
    permissions: 'permissions',
    role_permissions: 'role_permissions',
    roles: 'roles',
    telemetry: 'telemetry',
    users: 'users',
    codec12_commands: 'codec12_commands',
    user_organisation_access: 'user_organisation_access',
    user_asset_access: 'user_asset_access',
    user_device_access: 'user_device_access',
    files: 'files',
    images: 'images'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "assets" | "devices" | "organisations" | "permissions" | "role_permissions" | "roles" | "telemetry" | "users" | "codec12_commands" | "user_organisation_access" | "user_asset_access" | "user_device_access" | "files" | "images"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      assets: {
        payload: Prisma.$assetsPayload<ExtArgs>
        fields: Prisma.assetsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.assetsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.assetsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>
          }
          findFirst: {
            args: Prisma.assetsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.assetsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>
          }
          findMany: {
            args: Prisma.assetsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>[]
          }
          create: {
            args: Prisma.assetsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>
          }
          createMany: {
            args: Prisma.assetsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.assetsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>[]
          }
          delete: {
            args: Prisma.assetsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>
          }
          update: {
            args: Prisma.assetsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>
          }
          deleteMany: {
            args: Prisma.assetsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.assetsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.assetsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>[]
          }
          upsert: {
            args: Prisma.assetsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$assetsPayload>
          }
          aggregate: {
            args: Prisma.AssetsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAssets>
          }
          groupBy: {
            args: Prisma.assetsGroupByArgs<ExtArgs>
            result: $Utils.Optional<AssetsGroupByOutputType>[]
          }
          count: {
            args: Prisma.assetsCountArgs<ExtArgs>
            result: $Utils.Optional<AssetsCountAggregateOutputType> | number
          }
        }
      }
      devices: {
        payload: Prisma.$devicesPayload<ExtArgs>
        fields: Prisma.devicesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.devicesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.devicesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>
          }
          findFirst: {
            args: Prisma.devicesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.devicesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>
          }
          findMany: {
            args: Prisma.devicesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>[]
          }
          create: {
            args: Prisma.devicesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>
          }
          createMany: {
            args: Prisma.devicesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.devicesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>[]
          }
          delete: {
            args: Prisma.devicesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>
          }
          update: {
            args: Prisma.devicesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>
          }
          deleteMany: {
            args: Prisma.devicesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.devicesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.devicesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>[]
          }
          upsert: {
            args: Prisma.devicesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$devicesPayload>
          }
          aggregate: {
            args: Prisma.DevicesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateDevices>
          }
          groupBy: {
            args: Prisma.devicesGroupByArgs<ExtArgs>
            result: $Utils.Optional<DevicesGroupByOutputType>[]
          }
          count: {
            args: Prisma.devicesCountArgs<ExtArgs>
            result: $Utils.Optional<DevicesCountAggregateOutputType> | number
          }
        }
      }
      organisations: {
        payload: Prisma.$organisationsPayload<ExtArgs>
        fields: Prisma.organisationsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.organisationsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.organisationsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>
          }
          findFirst: {
            args: Prisma.organisationsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.organisationsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>
          }
          findMany: {
            args: Prisma.organisationsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>[]
          }
          create: {
            args: Prisma.organisationsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>
          }
          createMany: {
            args: Prisma.organisationsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.organisationsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>[]
          }
          delete: {
            args: Prisma.organisationsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>
          }
          update: {
            args: Prisma.organisationsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>
          }
          deleteMany: {
            args: Prisma.organisationsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.organisationsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.organisationsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>[]
          }
          upsert: {
            args: Prisma.organisationsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$organisationsPayload>
          }
          aggregate: {
            args: Prisma.OrganisationsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOrganisations>
          }
          groupBy: {
            args: Prisma.organisationsGroupByArgs<ExtArgs>
            result: $Utils.Optional<OrganisationsGroupByOutputType>[]
          }
          count: {
            args: Prisma.organisationsCountArgs<ExtArgs>
            result: $Utils.Optional<OrganisationsCountAggregateOutputType> | number
          }
        }
      }
      permissions: {
        payload: Prisma.$permissionsPayload<ExtArgs>
        fields: Prisma.permissionsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.permissionsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.permissionsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>
          }
          findFirst: {
            args: Prisma.permissionsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.permissionsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>
          }
          findMany: {
            args: Prisma.permissionsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>[]
          }
          create: {
            args: Prisma.permissionsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>
          }
          createMany: {
            args: Prisma.permissionsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.permissionsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>[]
          }
          delete: {
            args: Prisma.permissionsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>
          }
          update: {
            args: Prisma.permissionsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>
          }
          deleteMany: {
            args: Prisma.permissionsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.permissionsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.permissionsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>[]
          }
          upsert: {
            args: Prisma.permissionsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$permissionsPayload>
          }
          aggregate: {
            args: Prisma.PermissionsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePermissions>
          }
          groupBy: {
            args: Prisma.permissionsGroupByArgs<ExtArgs>
            result: $Utils.Optional<PermissionsGroupByOutputType>[]
          }
          count: {
            args: Prisma.permissionsCountArgs<ExtArgs>
            result: $Utils.Optional<PermissionsCountAggregateOutputType> | number
          }
        }
      }
      role_permissions: {
        payload: Prisma.$role_permissionsPayload<ExtArgs>
        fields: Prisma.role_permissionsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.role_permissionsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.role_permissionsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>
          }
          findFirst: {
            args: Prisma.role_permissionsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.role_permissionsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>
          }
          findMany: {
            args: Prisma.role_permissionsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>[]
          }
          create: {
            args: Prisma.role_permissionsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>
          }
          createMany: {
            args: Prisma.role_permissionsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.role_permissionsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>[]
          }
          delete: {
            args: Prisma.role_permissionsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>
          }
          update: {
            args: Prisma.role_permissionsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>
          }
          deleteMany: {
            args: Prisma.role_permissionsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.role_permissionsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.role_permissionsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>[]
          }
          upsert: {
            args: Prisma.role_permissionsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$role_permissionsPayload>
          }
          aggregate: {
            args: Prisma.Role_permissionsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateRole_permissions>
          }
          groupBy: {
            args: Prisma.role_permissionsGroupByArgs<ExtArgs>
            result: $Utils.Optional<Role_permissionsGroupByOutputType>[]
          }
          count: {
            args: Prisma.role_permissionsCountArgs<ExtArgs>
            result: $Utils.Optional<Role_permissionsCountAggregateOutputType> | number
          }
        }
      }
      roles: {
        payload: Prisma.$rolesPayload<ExtArgs>
        fields: Prisma.rolesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.rolesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.rolesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>
          }
          findFirst: {
            args: Prisma.rolesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.rolesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>
          }
          findMany: {
            args: Prisma.rolesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>[]
          }
          create: {
            args: Prisma.rolesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>
          }
          createMany: {
            args: Prisma.rolesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.rolesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>[]
          }
          delete: {
            args: Prisma.rolesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>
          }
          update: {
            args: Prisma.rolesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>
          }
          deleteMany: {
            args: Prisma.rolesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.rolesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.rolesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>[]
          }
          upsert: {
            args: Prisma.rolesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rolesPayload>
          }
          aggregate: {
            args: Prisma.RolesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateRoles>
          }
          groupBy: {
            args: Prisma.rolesGroupByArgs<ExtArgs>
            result: $Utils.Optional<RolesGroupByOutputType>[]
          }
          count: {
            args: Prisma.rolesCountArgs<ExtArgs>
            result: $Utils.Optional<RolesCountAggregateOutputType> | number
          }
        }
      }
      telemetry: {
        payload: Prisma.$telemetryPayload<ExtArgs>
        fields: Prisma.telemetryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.telemetryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.telemetryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>
          }
          findFirst: {
            args: Prisma.telemetryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.telemetryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>
          }
          findMany: {
            args: Prisma.telemetryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>[]
          }
          create: {
            args: Prisma.telemetryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>
          }
          createMany: {
            args: Prisma.telemetryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.telemetryCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>[]
          }
          delete: {
            args: Prisma.telemetryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>
          }
          update: {
            args: Prisma.telemetryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>
          }
          deleteMany: {
            args: Prisma.telemetryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.telemetryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.telemetryUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>[]
          }
          upsert: {
            args: Prisma.telemetryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$telemetryPayload>
          }
          aggregate: {
            args: Prisma.TelemetryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTelemetry>
          }
          groupBy: {
            args: Prisma.telemetryGroupByArgs<ExtArgs>
            result: $Utils.Optional<TelemetryGroupByOutputType>[]
          }
          count: {
            args: Prisma.telemetryCountArgs<ExtArgs>
            result: $Utils.Optional<TelemetryCountAggregateOutputType> | number
          }
        }
      }
      users: {
        payload: Prisma.$usersPayload<ExtArgs>
        fields: Prisma.usersFieldRefs
        operations: {
          findUnique: {
            args: Prisma.usersFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.usersFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          findFirst: {
            args: Prisma.usersFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.usersFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          findMany: {
            args: Prisma.usersFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>[]
          }
          create: {
            args: Prisma.usersCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          createMany: {
            args: Prisma.usersCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.usersCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>[]
          }
          delete: {
            args: Prisma.usersDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          update: {
            args: Prisma.usersUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          deleteMany: {
            args: Prisma.usersDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.usersUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.usersUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>[]
          }
          upsert: {
            args: Prisma.usersUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usersPayload>
          }
          aggregate: {
            args: Prisma.UsersAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUsers>
          }
          groupBy: {
            args: Prisma.usersGroupByArgs<ExtArgs>
            result: $Utils.Optional<UsersGroupByOutputType>[]
          }
          count: {
            args: Prisma.usersCountArgs<ExtArgs>
            result: $Utils.Optional<UsersCountAggregateOutputType> | number
          }
        }
      }
      codec12_commands: {
        payload: Prisma.$codec12_commandsPayload<ExtArgs>
        fields: Prisma.codec12_commandsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.codec12_commandsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.codec12_commandsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>
          }
          findFirst: {
            args: Prisma.codec12_commandsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.codec12_commandsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>
          }
          findMany: {
            args: Prisma.codec12_commandsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>[]
          }
          create: {
            args: Prisma.codec12_commandsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>
          }
          createMany: {
            args: Prisma.codec12_commandsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.codec12_commandsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>[]
          }
          delete: {
            args: Prisma.codec12_commandsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>
          }
          update: {
            args: Prisma.codec12_commandsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>
          }
          deleteMany: {
            args: Prisma.codec12_commandsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.codec12_commandsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.codec12_commandsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>[]
          }
          upsert: {
            args: Prisma.codec12_commandsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$codec12_commandsPayload>
          }
          aggregate: {
            args: Prisma.Codec12_commandsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCodec12_commands>
          }
          groupBy: {
            args: Prisma.codec12_commandsGroupByArgs<ExtArgs>
            result: $Utils.Optional<Codec12_commandsGroupByOutputType>[]
          }
          count: {
            args: Prisma.codec12_commandsCountArgs<ExtArgs>
            result: $Utils.Optional<Codec12_commandsCountAggregateOutputType> | number
          }
        }
      }
      user_organisation_access: {
        payload: Prisma.$user_organisation_accessPayload<ExtArgs>
        fields: Prisma.user_organisation_accessFieldRefs
        operations: {
          findUnique: {
            args: Prisma.user_organisation_accessFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.user_organisation_accessFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>
          }
          findFirst: {
            args: Prisma.user_organisation_accessFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.user_organisation_accessFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>
          }
          findMany: {
            args: Prisma.user_organisation_accessFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>[]
          }
          create: {
            args: Prisma.user_organisation_accessCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>
          }
          createMany: {
            args: Prisma.user_organisation_accessCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.user_organisation_accessCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>[]
          }
          delete: {
            args: Prisma.user_organisation_accessDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>
          }
          update: {
            args: Prisma.user_organisation_accessUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>
          }
          deleteMany: {
            args: Prisma.user_organisation_accessDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.user_organisation_accessUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.user_organisation_accessUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>[]
          }
          upsert: {
            args: Prisma.user_organisation_accessUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_organisation_accessPayload>
          }
          aggregate: {
            args: Prisma.User_organisation_accessAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser_organisation_access>
          }
          groupBy: {
            args: Prisma.user_organisation_accessGroupByArgs<ExtArgs>
            result: $Utils.Optional<User_organisation_accessGroupByOutputType>[]
          }
          count: {
            args: Prisma.user_organisation_accessCountArgs<ExtArgs>
            result: $Utils.Optional<User_organisation_accessCountAggregateOutputType> | number
          }
        }
      }
      user_asset_access: {
        payload: Prisma.$user_asset_accessPayload<ExtArgs>
        fields: Prisma.user_asset_accessFieldRefs
        operations: {
          findUnique: {
            args: Prisma.user_asset_accessFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.user_asset_accessFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>
          }
          findFirst: {
            args: Prisma.user_asset_accessFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.user_asset_accessFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>
          }
          findMany: {
            args: Prisma.user_asset_accessFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>[]
          }
          create: {
            args: Prisma.user_asset_accessCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>
          }
          createMany: {
            args: Prisma.user_asset_accessCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.user_asset_accessCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>[]
          }
          delete: {
            args: Prisma.user_asset_accessDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>
          }
          update: {
            args: Prisma.user_asset_accessUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>
          }
          deleteMany: {
            args: Prisma.user_asset_accessDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.user_asset_accessUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.user_asset_accessUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>[]
          }
          upsert: {
            args: Prisma.user_asset_accessUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_asset_accessPayload>
          }
          aggregate: {
            args: Prisma.User_asset_accessAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser_asset_access>
          }
          groupBy: {
            args: Prisma.user_asset_accessGroupByArgs<ExtArgs>
            result: $Utils.Optional<User_asset_accessGroupByOutputType>[]
          }
          count: {
            args: Prisma.user_asset_accessCountArgs<ExtArgs>
            result: $Utils.Optional<User_asset_accessCountAggregateOutputType> | number
          }
        }
      }
      user_device_access: {
        payload: Prisma.$user_device_accessPayload<ExtArgs>
        fields: Prisma.user_device_accessFieldRefs
        operations: {
          findUnique: {
            args: Prisma.user_device_accessFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.user_device_accessFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>
          }
          findFirst: {
            args: Prisma.user_device_accessFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.user_device_accessFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>
          }
          findMany: {
            args: Prisma.user_device_accessFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>[]
          }
          create: {
            args: Prisma.user_device_accessCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>
          }
          createMany: {
            args: Prisma.user_device_accessCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.user_device_accessCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>[]
          }
          delete: {
            args: Prisma.user_device_accessDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>
          }
          update: {
            args: Prisma.user_device_accessUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>
          }
          deleteMany: {
            args: Prisma.user_device_accessDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.user_device_accessUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.user_device_accessUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>[]
          }
          upsert: {
            args: Prisma.user_device_accessUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$user_device_accessPayload>
          }
          aggregate: {
            args: Prisma.User_device_accessAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser_device_access>
          }
          groupBy: {
            args: Prisma.user_device_accessGroupByArgs<ExtArgs>
            result: $Utils.Optional<User_device_accessGroupByOutputType>[]
          }
          count: {
            args: Prisma.user_device_accessCountArgs<ExtArgs>
            result: $Utils.Optional<User_device_accessCountAggregateOutputType> | number
          }
        }
      }
      files: {
        payload: Prisma.$filesPayload<ExtArgs>
        fields: Prisma.filesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.filesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.filesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>
          }
          findFirst: {
            args: Prisma.filesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.filesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>
          }
          findMany: {
            args: Prisma.filesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>[]
          }
          create: {
            args: Prisma.filesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>
          }
          createMany: {
            args: Prisma.filesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.filesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>[]
          }
          delete: {
            args: Prisma.filesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>
          }
          update: {
            args: Prisma.filesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>
          }
          deleteMany: {
            args: Prisma.filesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.filesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.filesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>[]
          }
          upsert: {
            args: Prisma.filesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$filesPayload>
          }
          aggregate: {
            args: Prisma.FilesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateFiles>
          }
          groupBy: {
            args: Prisma.filesGroupByArgs<ExtArgs>
            result: $Utils.Optional<FilesGroupByOutputType>[]
          }
          count: {
            args: Prisma.filesCountArgs<ExtArgs>
            result: $Utils.Optional<FilesCountAggregateOutputType> | number
          }
        }
      }
      images: {
        payload: Prisma.$imagesPayload<ExtArgs>
        fields: Prisma.imagesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.imagesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.imagesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>
          }
          findFirst: {
            args: Prisma.imagesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.imagesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>
          }
          findMany: {
            args: Prisma.imagesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>[]
          }
          create: {
            args: Prisma.imagesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>
          }
          createMany: {
            args: Prisma.imagesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.imagesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>[]
          }
          delete: {
            args: Prisma.imagesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>
          }
          update: {
            args: Prisma.imagesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>
          }
          deleteMany: {
            args: Prisma.imagesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.imagesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.imagesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>[]
          }
          upsert: {
            args: Prisma.imagesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$imagesPayload>
          }
          aggregate: {
            args: Prisma.ImagesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateImages>
          }
          groupBy: {
            args: Prisma.imagesGroupByArgs<ExtArgs>
            result: $Utils.Optional<ImagesGroupByOutputType>[]
          }
          count: {
            args: Prisma.imagesCountArgs<ExtArgs>
            result: $Utils.Optional<ImagesCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    assets?: assetsOmit
    devices?: devicesOmit
    organisations?: organisationsOmit
    permissions?: permissionsOmit
    role_permissions?: role_permissionsOmit
    roles?: rolesOmit
    telemetry?: telemetryOmit
    users?: usersOmit
    codec12_commands?: codec12_commandsOmit
    user_organisation_access?: user_organisation_accessOmit
    user_asset_access?: user_asset_accessOmit
    user_device_access?: user_device_accessOmit
    files?: filesOmit
    images?: imagesOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type AssetsCountOutputType
   */

  export type AssetsCountOutputType = {
    devices: number
    user_asset_access: number
  }

  export type AssetsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    devices?: boolean | AssetsCountOutputTypeCountDevicesArgs
    user_asset_access?: boolean | AssetsCountOutputTypeCountUser_asset_accessArgs
  }

  // Custom InputTypes
  /**
   * AssetsCountOutputType without action
   */
  export type AssetsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AssetsCountOutputType
     */
    select?: AssetsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * AssetsCountOutputType without action
   */
  export type AssetsCountOutputTypeCountDevicesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: devicesWhereInput
  }

  /**
   * AssetsCountOutputType without action
   */
  export type AssetsCountOutputTypeCountUser_asset_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_asset_accessWhereInput
  }


  /**
   * Count Type DevicesCountOutputType
   */

  export type DevicesCountOutputType = {
    user_device_access: number
  }

  export type DevicesCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user_device_access?: boolean | DevicesCountOutputTypeCountUser_device_accessArgs
  }

  // Custom InputTypes
  /**
   * DevicesCountOutputType without action
   */
  export type DevicesCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DevicesCountOutputType
     */
    select?: DevicesCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * DevicesCountOutputType without action
   */
  export type DevicesCountOutputTypeCountUser_device_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_device_accessWhereInput
  }


  /**
   * Count Type OrganisationsCountOutputType
   */

  export type OrganisationsCountOutputType = {
    assets: number
    devices: number
    other_organisations: number
    user_organisation_access: number
    users: number
  }

  export type OrganisationsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | OrganisationsCountOutputTypeCountAssetsArgs
    devices?: boolean | OrganisationsCountOutputTypeCountDevicesArgs
    other_organisations?: boolean | OrganisationsCountOutputTypeCountOther_organisationsArgs
    user_organisation_access?: boolean | OrganisationsCountOutputTypeCountUser_organisation_accessArgs
    users?: boolean | OrganisationsCountOutputTypeCountUsersArgs
  }

  // Custom InputTypes
  /**
   * OrganisationsCountOutputType without action
   */
  export type OrganisationsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OrganisationsCountOutputType
     */
    select?: OrganisationsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * OrganisationsCountOutputType without action
   */
  export type OrganisationsCountOutputTypeCountAssetsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: assetsWhereInput
  }

  /**
   * OrganisationsCountOutputType without action
   */
  export type OrganisationsCountOutputTypeCountDevicesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: devicesWhereInput
  }

  /**
   * OrganisationsCountOutputType without action
   */
  export type OrganisationsCountOutputTypeCountOther_organisationsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: organisationsWhereInput
  }

  /**
   * OrganisationsCountOutputType without action
   */
  export type OrganisationsCountOutputTypeCountUser_organisation_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_organisation_accessWhereInput
  }

  /**
   * OrganisationsCountOutputType without action
   */
  export type OrganisationsCountOutputTypeCountUsersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usersWhereInput
  }


  /**
   * Count Type PermissionsCountOutputType
   */

  export type PermissionsCountOutputType = {
    role_permissions: number
  }

  export type PermissionsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    role_permissions?: boolean | PermissionsCountOutputTypeCountRole_permissionsArgs
  }

  // Custom InputTypes
  /**
   * PermissionsCountOutputType without action
   */
  export type PermissionsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PermissionsCountOutputType
     */
    select?: PermissionsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PermissionsCountOutputType without action
   */
  export type PermissionsCountOutputTypeCountRole_permissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: role_permissionsWhereInput
  }


  /**
   * Count Type RolesCountOutputType
   */

  export type RolesCountOutputType = {
    role_permissions: number
    users: number
  }

  export type RolesCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    role_permissions?: boolean | RolesCountOutputTypeCountRole_permissionsArgs
    users?: boolean | RolesCountOutputTypeCountUsersArgs
  }

  // Custom InputTypes
  /**
   * RolesCountOutputType without action
   */
  export type RolesCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RolesCountOutputType
     */
    select?: RolesCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * RolesCountOutputType without action
   */
  export type RolesCountOutputTypeCountRole_permissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: role_permissionsWhereInput
  }

  /**
   * RolesCountOutputType without action
   */
  export type RolesCountOutputTypeCountUsersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usersWhereInput
  }


  /**
   * Count Type UsersCountOutputType
   */

  export type UsersCountOutputType = {
    user_asset_access: number
    user_device_access: number
    user_organisation_access: number
  }

  export type UsersCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user_asset_access?: boolean | UsersCountOutputTypeCountUser_asset_accessArgs
    user_device_access?: boolean | UsersCountOutputTypeCountUser_device_accessArgs
    user_organisation_access?: boolean | UsersCountOutputTypeCountUser_organisation_accessArgs
  }

  // Custom InputTypes
  /**
   * UsersCountOutputType without action
   */
  export type UsersCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersCountOutputType
     */
    select?: UsersCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UsersCountOutputType without action
   */
  export type UsersCountOutputTypeCountUser_asset_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_asset_accessWhereInput
  }

  /**
   * UsersCountOutputType without action
   */
  export type UsersCountOutputTypeCountUser_device_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_device_accessWhereInput
  }

  /**
   * UsersCountOutputType without action
   */
  export type UsersCountOutputTypeCountUser_organisation_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_organisation_accessWhereInput
  }


  /**
   * Models
   */

  /**
   * Model assets
   */

  export type AggregateAssets = {
    _count: AssetsCountAggregateOutputType | null
    _avg: AssetsAvgAggregateOutputType | null
    _sum: AssetsSumAggregateOutputType | null
    _min: AssetsMinAggregateOutputType | null
    _max: AssetsMaxAggregateOutputType | null
  }

  export type AssetsAvgAggregateOutputType = {
    id: number | null
    organisation_id: number | null
  }

  export type AssetsSumAggregateOutputType = {
    id: bigint | null
    organisation_id: bigint | null
  }

  export type AssetsMinAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    organisation_id: bigint | null
    name: string | null
    asset_type: string | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type AssetsMaxAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    organisation_id: bigint | null
    name: string | null
    asset_type: string | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type AssetsCountAggregateOutputType = {
    id: number
    uuid: number
    organisation_id: number
    name: number
    asset_type: number
    attributes: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type AssetsAvgAggregateInputType = {
    id?: true
    organisation_id?: true
  }

  export type AssetsSumAggregateInputType = {
    id?: true
    organisation_id?: true
  }

  export type AssetsMinAggregateInputType = {
    id?: true
    uuid?: true
    organisation_id?: true
    name?: true
    asset_type?: true
    created_at?: true
    updated_at?: true
  }

  export type AssetsMaxAggregateInputType = {
    id?: true
    uuid?: true
    organisation_id?: true
    name?: true
    asset_type?: true
    created_at?: true
    updated_at?: true
  }

  export type AssetsCountAggregateInputType = {
    id?: true
    uuid?: true
    organisation_id?: true
    name?: true
    asset_type?: true
    attributes?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type AssetsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which assets to aggregate.
     */
    where?: assetsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of assets to fetch.
     */
    orderBy?: assetsOrderByWithRelationInput | assetsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: assetsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` assets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` assets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned assets
    **/
    _count?: true | AssetsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AssetsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AssetsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AssetsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AssetsMaxAggregateInputType
  }

  export type GetAssetsAggregateType<T extends AssetsAggregateArgs> = {
        [P in keyof T & keyof AggregateAssets]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAssets[P]>
      : GetScalarType<T[P], AggregateAssets[P]>
  }




  export type assetsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: assetsWhereInput
    orderBy?: assetsOrderByWithAggregationInput | assetsOrderByWithAggregationInput[]
    by: AssetsScalarFieldEnum[] | AssetsScalarFieldEnum
    having?: assetsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AssetsCountAggregateInputType | true
    _avg?: AssetsAvgAggregateInputType
    _sum?: AssetsSumAggregateInputType
    _min?: AssetsMinAggregateInputType
    _max?: AssetsMaxAggregateInputType
  }

  export type AssetsGroupByOutputType = {
    id: bigint
    uuid: string | null
    organisation_id: bigint
    name: string
    asset_type: string | null
    attributes: JsonValue
    created_at: Date
    updated_at: Date
    _count: AssetsCountAggregateOutputType | null
    _avg: AssetsAvgAggregateOutputType | null
    _sum: AssetsSumAggregateOutputType | null
    _min: AssetsMinAggregateOutputType | null
    _max: AssetsMaxAggregateOutputType | null
  }

  type GetAssetsGroupByPayload<T extends assetsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AssetsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AssetsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AssetsGroupByOutputType[P]>
            : GetScalarType<T[P], AssetsGroupByOutputType[P]>
        }
      >
    >


  export type assetsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    organisation_id?: boolean
    name?: boolean
    asset_type?: boolean
    attributes?: boolean
    created_at?: boolean
    updated_at?: boolean
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    devices?: boolean | assets$devicesArgs<ExtArgs>
    user_asset_access?: boolean | assets$user_asset_accessArgs<ExtArgs>
    _count?: boolean | AssetsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["assets"]>

  export type assetsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    organisation_id?: boolean
    name?: boolean
    asset_type?: boolean
    attributes?: boolean
    created_at?: boolean
    updated_at?: boolean
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["assets"]>

  export type assetsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    organisation_id?: boolean
    name?: boolean
    asset_type?: boolean
    attributes?: boolean
    created_at?: boolean
    updated_at?: boolean
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["assets"]>

  export type assetsSelectScalar = {
    id?: boolean
    uuid?: boolean
    organisation_id?: boolean
    name?: boolean
    asset_type?: boolean
    attributes?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type assetsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "uuid" | "organisation_id" | "name" | "asset_type" | "attributes" | "created_at" | "updated_at", ExtArgs["result"]["assets"]>
  export type assetsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    devices?: boolean | assets$devicesArgs<ExtArgs>
    user_asset_access?: boolean | assets$user_asset_accessArgs<ExtArgs>
    _count?: boolean | AssetsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type assetsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
  }
  export type assetsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
  }

  export type $assetsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "assets"
    objects: {
      organisations: Prisma.$organisationsPayload<ExtArgs>
      devices: Prisma.$devicesPayload<ExtArgs>[]
      user_asset_access: Prisma.$user_asset_accessPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      uuid: string | null
      organisation_id: bigint
      name: string
      asset_type: string | null
      attributes: Prisma.JsonValue
      created_at: Date
      updated_at: Date
    }, ExtArgs["result"]["assets"]>
    composites: {}
  }

  type assetsGetPayload<S extends boolean | null | undefined | assetsDefaultArgs> = $Result.GetResult<Prisma.$assetsPayload, S>

  type assetsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<assetsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AssetsCountAggregateInputType | true
    }

  export interface assetsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['assets'], meta: { name: 'assets' } }
    /**
     * Find zero or one Assets that matches the filter.
     * @param {assetsFindUniqueArgs} args - Arguments to find a Assets
     * @example
     * // Get one Assets
     * const assets = await prisma.assets.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends assetsFindUniqueArgs>(args: SelectSubset<T, assetsFindUniqueArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Assets that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {assetsFindUniqueOrThrowArgs} args - Arguments to find a Assets
     * @example
     * // Get one Assets
     * const assets = await prisma.assets.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends assetsFindUniqueOrThrowArgs>(args: SelectSubset<T, assetsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Assets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {assetsFindFirstArgs} args - Arguments to find a Assets
     * @example
     * // Get one Assets
     * const assets = await prisma.assets.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends assetsFindFirstArgs>(args?: SelectSubset<T, assetsFindFirstArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Assets that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {assetsFindFirstOrThrowArgs} args - Arguments to find a Assets
     * @example
     * // Get one Assets
     * const assets = await prisma.assets.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends assetsFindFirstOrThrowArgs>(args?: SelectSubset<T, assetsFindFirstOrThrowArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Assets that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {assetsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Assets
     * const assets = await prisma.assets.findMany()
     * 
     * // Get first 10 Assets
     * const assets = await prisma.assets.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const assetsWithIdOnly = await prisma.assets.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends assetsFindManyArgs>(args?: SelectSubset<T, assetsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Assets.
     * @param {assetsCreateArgs} args - Arguments to create a Assets.
     * @example
     * // Create one Assets
     * const Assets = await prisma.assets.create({
     *   data: {
     *     // ... data to create a Assets
     *   }
     * })
     * 
     */
    create<T extends assetsCreateArgs>(args: SelectSubset<T, assetsCreateArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Assets.
     * @param {assetsCreateManyArgs} args - Arguments to create many Assets.
     * @example
     * // Create many Assets
     * const assets = await prisma.assets.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends assetsCreateManyArgs>(args?: SelectSubset<T, assetsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Assets and returns the data saved in the database.
     * @param {assetsCreateManyAndReturnArgs} args - Arguments to create many Assets.
     * @example
     * // Create many Assets
     * const assets = await prisma.assets.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Assets and only return the `id`
     * const assetsWithIdOnly = await prisma.assets.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends assetsCreateManyAndReturnArgs>(args?: SelectSubset<T, assetsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Assets.
     * @param {assetsDeleteArgs} args - Arguments to delete one Assets.
     * @example
     * // Delete one Assets
     * const Assets = await prisma.assets.delete({
     *   where: {
     *     // ... filter to delete one Assets
     *   }
     * })
     * 
     */
    delete<T extends assetsDeleteArgs>(args: SelectSubset<T, assetsDeleteArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Assets.
     * @param {assetsUpdateArgs} args - Arguments to update one Assets.
     * @example
     * // Update one Assets
     * const assets = await prisma.assets.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends assetsUpdateArgs>(args: SelectSubset<T, assetsUpdateArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Assets.
     * @param {assetsDeleteManyArgs} args - Arguments to filter Assets to delete.
     * @example
     * // Delete a few Assets
     * const { count } = await prisma.assets.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends assetsDeleteManyArgs>(args?: SelectSubset<T, assetsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Assets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {assetsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Assets
     * const assets = await prisma.assets.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends assetsUpdateManyArgs>(args: SelectSubset<T, assetsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Assets and returns the data updated in the database.
     * @param {assetsUpdateManyAndReturnArgs} args - Arguments to update many Assets.
     * @example
     * // Update many Assets
     * const assets = await prisma.assets.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Assets and only return the `id`
     * const assetsWithIdOnly = await prisma.assets.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends assetsUpdateManyAndReturnArgs>(args: SelectSubset<T, assetsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Assets.
     * @param {assetsUpsertArgs} args - Arguments to update or create a Assets.
     * @example
     * // Update or create a Assets
     * const assets = await prisma.assets.upsert({
     *   create: {
     *     // ... data to create a Assets
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Assets we want to update
     *   }
     * })
     */
    upsert<T extends assetsUpsertArgs>(args: SelectSubset<T, assetsUpsertArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Assets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {assetsCountArgs} args - Arguments to filter Assets to count.
     * @example
     * // Count the number of Assets
     * const count = await prisma.assets.count({
     *   where: {
     *     // ... the filter for the Assets we want to count
     *   }
     * })
    **/
    count<T extends assetsCountArgs>(
      args?: Subset<T, assetsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AssetsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Assets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AssetsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AssetsAggregateArgs>(args: Subset<T, AssetsAggregateArgs>): Prisma.PrismaPromise<GetAssetsAggregateType<T>>

    /**
     * Group by Assets.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {assetsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends assetsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: assetsGroupByArgs['orderBy'] }
        : { orderBy?: assetsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, assetsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAssetsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the assets model
   */
  readonly fields: assetsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for assets.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__assetsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    organisations<T extends organisationsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, organisationsDefaultArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    devices<T extends assets$devicesArgs<ExtArgs> = {}>(args?: Subset<T, assets$devicesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    user_asset_access<T extends assets$user_asset_accessArgs<ExtArgs> = {}>(args?: Subset<T, assets$user_asset_accessArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the assets model
   */
  interface assetsFieldRefs {
    readonly id: FieldRef<"assets", 'BigInt'>
    readonly uuid: FieldRef<"assets", 'String'>
    readonly organisation_id: FieldRef<"assets", 'BigInt'>
    readonly name: FieldRef<"assets", 'String'>
    readonly asset_type: FieldRef<"assets", 'String'>
    readonly attributes: FieldRef<"assets", 'Json'>
    readonly created_at: FieldRef<"assets", 'DateTime'>
    readonly updated_at: FieldRef<"assets", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * assets findUnique
   */
  export type assetsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * Filter, which assets to fetch.
     */
    where: assetsWhereUniqueInput
  }

  /**
   * assets findUniqueOrThrow
   */
  export type assetsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * Filter, which assets to fetch.
     */
    where: assetsWhereUniqueInput
  }

  /**
   * assets findFirst
   */
  export type assetsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * Filter, which assets to fetch.
     */
    where?: assetsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of assets to fetch.
     */
    orderBy?: assetsOrderByWithRelationInput | assetsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for assets.
     */
    cursor?: assetsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` assets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` assets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of assets.
     */
    distinct?: AssetsScalarFieldEnum | AssetsScalarFieldEnum[]
  }

  /**
   * assets findFirstOrThrow
   */
  export type assetsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * Filter, which assets to fetch.
     */
    where?: assetsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of assets to fetch.
     */
    orderBy?: assetsOrderByWithRelationInput | assetsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for assets.
     */
    cursor?: assetsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` assets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` assets.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of assets.
     */
    distinct?: AssetsScalarFieldEnum | AssetsScalarFieldEnum[]
  }

  /**
   * assets findMany
   */
  export type assetsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * Filter, which assets to fetch.
     */
    where?: assetsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of assets to fetch.
     */
    orderBy?: assetsOrderByWithRelationInput | assetsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing assets.
     */
    cursor?: assetsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` assets from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` assets.
     */
    skip?: number
    distinct?: AssetsScalarFieldEnum | AssetsScalarFieldEnum[]
  }

  /**
   * assets create
   */
  export type assetsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * The data needed to create a assets.
     */
    data: XOR<assetsCreateInput, assetsUncheckedCreateInput>
  }

  /**
   * assets createMany
   */
  export type assetsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many assets.
     */
    data: assetsCreateManyInput | assetsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * assets createManyAndReturn
   */
  export type assetsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * The data used to create many assets.
     */
    data: assetsCreateManyInput | assetsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * assets update
   */
  export type assetsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * The data needed to update a assets.
     */
    data: XOR<assetsUpdateInput, assetsUncheckedUpdateInput>
    /**
     * Choose, which assets to update.
     */
    where: assetsWhereUniqueInput
  }

  /**
   * assets updateMany
   */
  export type assetsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update assets.
     */
    data: XOR<assetsUpdateManyMutationInput, assetsUncheckedUpdateManyInput>
    /**
     * Filter which assets to update
     */
    where?: assetsWhereInput
    /**
     * Limit how many assets to update.
     */
    limit?: number
  }

  /**
   * assets updateManyAndReturn
   */
  export type assetsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * The data used to update assets.
     */
    data: XOR<assetsUpdateManyMutationInput, assetsUncheckedUpdateManyInput>
    /**
     * Filter which assets to update
     */
    where?: assetsWhereInput
    /**
     * Limit how many assets to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * assets upsert
   */
  export type assetsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * The filter to search for the assets to update in case it exists.
     */
    where: assetsWhereUniqueInput
    /**
     * In case the assets found by the `where` argument doesn't exist, create a new assets with this data.
     */
    create: XOR<assetsCreateInput, assetsUncheckedCreateInput>
    /**
     * In case the assets was found with the provided `where` argument, update it with this data.
     */
    update: XOR<assetsUpdateInput, assetsUncheckedUpdateInput>
  }

  /**
   * assets delete
   */
  export type assetsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    /**
     * Filter which assets to delete.
     */
    where: assetsWhereUniqueInput
  }

  /**
   * assets deleteMany
   */
  export type assetsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which assets to delete
     */
    where?: assetsWhereInput
    /**
     * Limit how many assets to delete.
     */
    limit?: number
  }

  /**
   * assets.devices
   */
  export type assets$devicesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    where?: devicesWhereInput
    orderBy?: devicesOrderByWithRelationInput | devicesOrderByWithRelationInput[]
    cursor?: devicesWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DevicesScalarFieldEnum | DevicesScalarFieldEnum[]
  }

  /**
   * assets.user_asset_access
   */
  export type assets$user_asset_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    where?: user_asset_accessWhereInput
    orderBy?: user_asset_accessOrderByWithRelationInput | user_asset_accessOrderByWithRelationInput[]
    cursor?: user_asset_accessWhereUniqueInput
    take?: number
    skip?: number
    distinct?: User_asset_accessScalarFieldEnum | User_asset_accessScalarFieldEnum[]
  }

  /**
   * assets without action
   */
  export type assetsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
  }


  /**
   * Model devices
   */

  export type AggregateDevices = {
    _count: DevicesCountAggregateOutputType | null
    _avg: DevicesAvgAggregateOutputType | null
    _sum: DevicesSumAggregateOutputType | null
    _min: DevicesMinAggregateOutputType | null
    _max: DevicesMaxAggregateOutputType | null
  }

  export type DevicesAvgAggregateOutputType = {
    id: number | null
    organisation_id: number | null
    asset_id: number | null
  }

  export type DevicesSumAggregateOutputType = {
    id: bigint | null
    organisation_id: bigint | null
    asset_id: bigint | null
  }

  export type DevicesMinAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    organisation_id: bigint | null
    asset_id: bigint | null
    external_id: string | null
    external_id_type: string | null
    protocol: string | null
    vendor: string | null
    model: string | null
    status: string | null
    last_telemetry_ts: Date | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type DevicesMaxAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    organisation_id: bigint | null
    asset_id: bigint | null
    external_id: string | null
    external_id_type: string | null
    protocol: string | null
    vendor: string | null
    model: string | null
    status: string | null
    last_telemetry_ts: Date | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type DevicesCountAggregateOutputType = {
    id: number
    uuid: number
    organisation_id: number
    asset_id: number
    external_id: number
    external_id_type: number
    protocol: number
    vendor: number
    model: number
    status: number
    attributes: number
    last_telemetry: number
    last_telemetry_ts: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type DevicesAvgAggregateInputType = {
    id?: true
    organisation_id?: true
    asset_id?: true
  }

  export type DevicesSumAggregateInputType = {
    id?: true
    organisation_id?: true
    asset_id?: true
  }

  export type DevicesMinAggregateInputType = {
    id?: true
    uuid?: true
    organisation_id?: true
    asset_id?: true
    external_id?: true
    external_id_type?: true
    protocol?: true
    vendor?: true
    model?: true
    status?: true
    last_telemetry_ts?: true
    created_at?: true
    updated_at?: true
  }

  export type DevicesMaxAggregateInputType = {
    id?: true
    uuid?: true
    organisation_id?: true
    asset_id?: true
    external_id?: true
    external_id_type?: true
    protocol?: true
    vendor?: true
    model?: true
    status?: true
    last_telemetry_ts?: true
    created_at?: true
    updated_at?: true
  }

  export type DevicesCountAggregateInputType = {
    id?: true
    uuid?: true
    organisation_id?: true
    asset_id?: true
    external_id?: true
    external_id_type?: true
    protocol?: true
    vendor?: true
    model?: true
    status?: true
    attributes?: true
    last_telemetry?: true
    last_telemetry_ts?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type DevicesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which devices to aggregate.
     */
    where?: devicesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of devices to fetch.
     */
    orderBy?: devicesOrderByWithRelationInput | devicesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: devicesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` devices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` devices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned devices
    **/
    _count?: true | DevicesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: DevicesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: DevicesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DevicesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DevicesMaxAggregateInputType
  }

  export type GetDevicesAggregateType<T extends DevicesAggregateArgs> = {
        [P in keyof T & keyof AggregateDevices]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDevices[P]>
      : GetScalarType<T[P], AggregateDevices[P]>
  }




  export type devicesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: devicesWhereInput
    orderBy?: devicesOrderByWithAggregationInput | devicesOrderByWithAggregationInput[]
    by: DevicesScalarFieldEnum[] | DevicesScalarFieldEnum
    having?: devicesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DevicesCountAggregateInputType | true
    _avg?: DevicesAvgAggregateInputType
    _sum?: DevicesSumAggregateInputType
    _min?: DevicesMinAggregateInputType
    _max?: DevicesMaxAggregateInputType
  }

  export type DevicesGroupByOutputType = {
    id: bigint
    uuid: string | null
    organisation_id: bigint
    asset_id: bigint | null
    external_id: string
    external_id_type: string
    protocol: string | null
    vendor: string | null
    model: string | null
    status: string
    attributes: JsonValue
    last_telemetry: JsonValue
    last_telemetry_ts: Date
    created_at: Date
    updated_at: Date
    _count: DevicesCountAggregateOutputType | null
    _avg: DevicesAvgAggregateOutputType | null
    _sum: DevicesSumAggregateOutputType | null
    _min: DevicesMinAggregateOutputType | null
    _max: DevicesMaxAggregateOutputType | null
  }

  type GetDevicesGroupByPayload<T extends devicesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<DevicesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DevicesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DevicesGroupByOutputType[P]>
            : GetScalarType<T[P], DevicesGroupByOutputType[P]>
        }
      >
    >


  export type devicesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    organisation_id?: boolean
    asset_id?: boolean
    external_id?: boolean
    external_id_type?: boolean
    protocol?: boolean
    vendor?: boolean
    model?: boolean
    status?: boolean
    attributes?: boolean
    last_telemetry?: boolean
    last_telemetry_ts?: boolean
    created_at?: boolean
    updated_at?: boolean
    assets?: boolean | devices$assetsArgs<ExtArgs>
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    user_device_access?: boolean | devices$user_device_accessArgs<ExtArgs>
    _count?: boolean | DevicesCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["devices"]>

  export type devicesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    organisation_id?: boolean
    asset_id?: boolean
    external_id?: boolean
    external_id_type?: boolean
    protocol?: boolean
    vendor?: boolean
    model?: boolean
    status?: boolean
    attributes?: boolean
    last_telemetry?: boolean
    last_telemetry_ts?: boolean
    created_at?: boolean
    updated_at?: boolean
    assets?: boolean | devices$assetsArgs<ExtArgs>
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["devices"]>

  export type devicesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    organisation_id?: boolean
    asset_id?: boolean
    external_id?: boolean
    external_id_type?: boolean
    protocol?: boolean
    vendor?: boolean
    model?: boolean
    status?: boolean
    attributes?: boolean
    last_telemetry?: boolean
    last_telemetry_ts?: boolean
    created_at?: boolean
    updated_at?: boolean
    assets?: boolean | devices$assetsArgs<ExtArgs>
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["devices"]>

  export type devicesSelectScalar = {
    id?: boolean
    uuid?: boolean
    organisation_id?: boolean
    asset_id?: boolean
    external_id?: boolean
    external_id_type?: boolean
    protocol?: boolean
    vendor?: boolean
    model?: boolean
    status?: boolean
    attributes?: boolean
    last_telemetry?: boolean
    last_telemetry_ts?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type devicesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "uuid" | "organisation_id" | "asset_id" | "external_id" | "external_id_type" | "protocol" | "vendor" | "model" | "status" | "attributes" | "last_telemetry" | "last_telemetry_ts" | "created_at" | "updated_at", ExtArgs["result"]["devices"]>
  export type devicesInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | devices$assetsArgs<ExtArgs>
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    user_device_access?: boolean | devices$user_device_accessArgs<ExtArgs>
    _count?: boolean | DevicesCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type devicesIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | devices$assetsArgs<ExtArgs>
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
  }
  export type devicesIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | devices$assetsArgs<ExtArgs>
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
  }

  export type $devicesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "devices"
    objects: {
      assets: Prisma.$assetsPayload<ExtArgs> | null
      organisations: Prisma.$organisationsPayload<ExtArgs>
      user_device_access: Prisma.$user_device_accessPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      uuid: string | null
      organisation_id: bigint
      asset_id: bigint | null
      external_id: string
      external_id_type: string
      protocol: string | null
      vendor: string | null
      model: string | null
      status: string
      attributes: Prisma.JsonValue
      last_telemetry: Prisma.JsonValue
      last_telemetry_ts: Date
      created_at: Date
      updated_at: Date
    }, ExtArgs["result"]["devices"]>
    composites: {}
  }

  type devicesGetPayload<S extends boolean | null | undefined | devicesDefaultArgs> = $Result.GetResult<Prisma.$devicesPayload, S>

  type devicesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<devicesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: DevicesCountAggregateInputType | true
    }

  export interface devicesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['devices'], meta: { name: 'devices' } }
    /**
     * Find zero or one Devices that matches the filter.
     * @param {devicesFindUniqueArgs} args - Arguments to find a Devices
     * @example
     * // Get one Devices
     * const devices = await prisma.devices.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends devicesFindUniqueArgs>(args: SelectSubset<T, devicesFindUniqueArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Devices that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {devicesFindUniqueOrThrowArgs} args - Arguments to find a Devices
     * @example
     * // Get one Devices
     * const devices = await prisma.devices.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends devicesFindUniqueOrThrowArgs>(args: SelectSubset<T, devicesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Devices that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {devicesFindFirstArgs} args - Arguments to find a Devices
     * @example
     * // Get one Devices
     * const devices = await prisma.devices.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends devicesFindFirstArgs>(args?: SelectSubset<T, devicesFindFirstArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Devices that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {devicesFindFirstOrThrowArgs} args - Arguments to find a Devices
     * @example
     * // Get one Devices
     * const devices = await prisma.devices.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends devicesFindFirstOrThrowArgs>(args?: SelectSubset<T, devicesFindFirstOrThrowArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Devices that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {devicesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Devices
     * const devices = await prisma.devices.findMany()
     * 
     * // Get first 10 Devices
     * const devices = await prisma.devices.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const devicesWithIdOnly = await prisma.devices.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends devicesFindManyArgs>(args?: SelectSubset<T, devicesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Devices.
     * @param {devicesCreateArgs} args - Arguments to create a Devices.
     * @example
     * // Create one Devices
     * const Devices = await prisma.devices.create({
     *   data: {
     *     // ... data to create a Devices
     *   }
     * })
     * 
     */
    create<T extends devicesCreateArgs>(args: SelectSubset<T, devicesCreateArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Devices.
     * @param {devicesCreateManyArgs} args - Arguments to create many Devices.
     * @example
     * // Create many Devices
     * const devices = await prisma.devices.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends devicesCreateManyArgs>(args?: SelectSubset<T, devicesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Devices and returns the data saved in the database.
     * @param {devicesCreateManyAndReturnArgs} args - Arguments to create many Devices.
     * @example
     * // Create many Devices
     * const devices = await prisma.devices.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Devices and only return the `id`
     * const devicesWithIdOnly = await prisma.devices.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends devicesCreateManyAndReturnArgs>(args?: SelectSubset<T, devicesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Devices.
     * @param {devicesDeleteArgs} args - Arguments to delete one Devices.
     * @example
     * // Delete one Devices
     * const Devices = await prisma.devices.delete({
     *   where: {
     *     // ... filter to delete one Devices
     *   }
     * })
     * 
     */
    delete<T extends devicesDeleteArgs>(args: SelectSubset<T, devicesDeleteArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Devices.
     * @param {devicesUpdateArgs} args - Arguments to update one Devices.
     * @example
     * // Update one Devices
     * const devices = await prisma.devices.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends devicesUpdateArgs>(args: SelectSubset<T, devicesUpdateArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Devices.
     * @param {devicesDeleteManyArgs} args - Arguments to filter Devices to delete.
     * @example
     * // Delete a few Devices
     * const { count } = await prisma.devices.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends devicesDeleteManyArgs>(args?: SelectSubset<T, devicesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Devices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {devicesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Devices
     * const devices = await prisma.devices.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends devicesUpdateManyArgs>(args: SelectSubset<T, devicesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Devices and returns the data updated in the database.
     * @param {devicesUpdateManyAndReturnArgs} args - Arguments to update many Devices.
     * @example
     * // Update many Devices
     * const devices = await prisma.devices.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Devices and only return the `id`
     * const devicesWithIdOnly = await prisma.devices.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends devicesUpdateManyAndReturnArgs>(args: SelectSubset<T, devicesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Devices.
     * @param {devicesUpsertArgs} args - Arguments to update or create a Devices.
     * @example
     * // Update or create a Devices
     * const devices = await prisma.devices.upsert({
     *   create: {
     *     // ... data to create a Devices
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Devices we want to update
     *   }
     * })
     */
    upsert<T extends devicesUpsertArgs>(args: SelectSubset<T, devicesUpsertArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Devices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {devicesCountArgs} args - Arguments to filter Devices to count.
     * @example
     * // Count the number of Devices
     * const count = await prisma.devices.count({
     *   where: {
     *     // ... the filter for the Devices we want to count
     *   }
     * })
    **/
    count<T extends devicesCountArgs>(
      args?: Subset<T, devicesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DevicesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Devices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DevicesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DevicesAggregateArgs>(args: Subset<T, DevicesAggregateArgs>): Prisma.PrismaPromise<GetDevicesAggregateType<T>>

    /**
     * Group by Devices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {devicesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends devicesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: devicesGroupByArgs['orderBy'] }
        : { orderBy?: devicesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, devicesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDevicesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the devices model
   */
  readonly fields: devicesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for devices.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__devicesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    assets<T extends devices$assetsArgs<ExtArgs> = {}>(args?: Subset<T, devices$assetsArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    organisations<T extends organisationsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, organisationsDefaultArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    user_device_access<T extends devices$user_device_accessArgs<ExtArgs> = {}>(args?: Subset<T, devices$user_device_accessArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the devices model
   */
  interface devicesFieldRefs {
    readonly id: FieldRef<"devices", 'BigInt'>
    readonly uuid: FieldRef<"devices", 'String'>
    readonly organisation_id: FieldRef<"devices", 'BigInt'>
    readonly asset_id: FieldRef<"devices", 'BigInt'>
    readonly external_id: FieldRef<"devices", 'String'>
    readonly external_id_type: FieldRef<"devices", 'String'>
    readonly protocol: FieldRef<"devices", 'String'>
    readonly vendor: FieldRef<"devices", 'String'>
    readonly model: FieldRef<"devices", 'String'>
    readonly status: FieldRef<"devices", 'String'>
    readonly attributes: FieldRef<"devices", 'Json'>
    readonly last_telemetry: FieldRef<"devices", 'Json'>
    readonly last_telemetry_ts: FieldRef<"devices", 'DateTime'>
    readonly created_at: FieldRef<"devices", 'DateTime'>
    readonly updated_at: FieldRef<"devices", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * devices findUnique
   */
  export type devicesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * Filter, which devices to fetch.
     */
    where: devicesWhereUniqueInput
  }

  /**
   * devices findUniqueOrThrow
   */
  export type devicesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * Filter, which devices to fetch.
     */
    where: devicesWhereUniqueInput
  }

  /**
   * devices findFirst
   */
  export type devicesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * Filter, which devices to fetch.
     */
    where?: devicesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of devices to fetch.
     */
    orderBy?: devicesOrderByWithRelationInput | devicesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for devices.
     */
    cursor?: devicesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` devices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` devices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of devices.
     */
    distinct?: DevicesScalarFieldEnum | DevicesScalarFieldEnum[]
  }

  /**
   * devices findFirstOrThrow
   */
  export type devicesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * Filter, which devices to fetch.
     */
    where?: devicesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of devices to fetch.
     */
    orderBy?: devicesOrderByWithRelationInput | devicesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for devices.
     */
    cursor?: devicesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` devices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` devices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of devices.
     */
    distinct?: DevicesScalarFieldEnum | DevicesScalarFieldEnum[]
  }

  /**
   * devices findMany
   */
  export type devicesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * Filter, which devices to fetch.
     */
    where?: devicesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of devices to fetch.
     */
    orderBy?: devicesOrderByWithRelationInput | devicesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing devices.
     */
    cursor?: devicesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` devices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` devices.
     */
    skip?: number
    distinct?: DevicesScalarFieldEnum | DevicesScalarFieldEnum[]
  }

  /**
   * devices create
   */
  export type devicesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * The data needed to create a devices.
     */
    data: XOR<devicesCreateInput, devicesUncheckedCreateInput>
  }

  /**
   * devices createMany
   */
  export type devicesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many devices.
     */
    data: devicesCreateManyInput | devicesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * devices createManyAndReturn
   */
  export type devicesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * The data used to create many devices.
     */
    data: devicesCreateManyInput | devicesCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * devices update
   */
  export type devicesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * The data needed to update a devices.
     */
    data: XOR<devicesUpdateInput, devicesUncheckedUpdateInput>
    /**
     * Choose, which devices to update.
     */
    where: devicesWhereUniqueInput
  }

  /**
   * devices updateMany
   */
  export type devicesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update devices.
     */
    data: XOR<devicesUpdateManyMutationInput, devicesUncheckedUpdateManyInput>
    /**
     * Filter which devices to update
     */
    where?: devicesWhereInput
    /**
     * Limit how many devices to update.
     */
    limit?: number
  }

  /**
   * devices updateManyAndReturn
   */
  export type devicesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * The data used to update devices.
     */
    data: XOR<devicesUpdateManyMutationInput, devicesUncheckedUpdateManyInput>
    /**
     * Filter which devices to update
     */
    where?: devicesWhereInput
    /**
     * Limit how many devices to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * devices upsert
   */
  export type devicesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * The filter to search for the devices to update in case it exists.
     */
    where: devicesWhereUniqueInput
    /**
     * In case the devices found by the `where` argument doesn't exist, create a new devices with this data.
     */
    create: XOR<devicesCreateInput, devicesUncheckedCreateInput>
    /**
     * In case the devices was found with the provided `where` argument, update it with this data.
     */
    update: XOR<devicesUpdateInput, devicesUncheckedUpdateInput>
  }

  /**
   * devices delete
   */
  export type devicesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    /**
     * Filter which devices to delete.
     */
    where: devicesWhereUniqueInput
  }

  /**
   * devices deleteMany
   */
  export type devicesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which devices to delete
     */
    where?: devicesWhereInput
    /**
     * Limit how many devices to delete.
     */
    limit?: number
  }

  /**
   * devices.assets
   */
  export type devices$assetsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    where?: assetsWhereInput
  }

  /**
   * devices.user_device_access
   */
  export type devices$user_device_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    where?: user_device_accessWhereInput
    orderBy?: user_device_accessOrderByWithRelationInput | user_device_accessOrderByWithRelationInput[]
    cursor?: user_device_accessWhereUniqueInput
    take?: number
    skip?: number
    distinct?: User_device_accessScalarFieldEnum | User_device_accessScalarFieldEnum[]
  }

  /**
   * devices without action
   */
  export type devicesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
  }


  /**
   * Model organisations
   */

  export type AggregateOrganisations = {
    _count: OrganisationsCountAggregateOutputType | null
    _avg: OrganisationsAvgAggregateOutputType | null
    _sum: OrganisationsSumAggregateOutputType | null
    _min: OrganisationsMinAggregateOutputType | null
    _max: OrganisationsMaxAggregateOutputType | null
  }

  export type OrganisationsAvgAggregateOutputType = {
    id: number | null
    parent_org_id: number | null
  }

  export type OrganisationsSumAggregateOutputType = {
    id: bigint | null
    parent_org_id: bigint | null
  }

  export type OrganisationsMinAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    name: string | null
    parent_org_id: bigint | null
    path: string | null
    maps_api_key: string | null
    can_inherit_key: boolean | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type OrganisationsMaxAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    name: string | null
    parent_org_id: bigint | null
    path: string | null
    maps_api_key: string | null
    can_inherit_key: boolean | null
    created_at: Date | null
    updated_at: Date | null
  }

  export type OrganisationsCountAggregateOutputType = {
    id: number
    uuid: number
    name: number
    parent_org_id: number
    path: number
    maps_api_key: number
    can_inherit_key: number
    attributes: number
    created_at: number
    updated_at: number
    _all: number
  }


  export type OrganisationsAvgAggregateInputType = {
    id?: true
    parent_org_id?: true
  }

  export type OrganisationsSumAggregateInputType = {
    id?: true
    parent_org_id?: true
  }

  export type OrganisationsMinAggregateInputType = {
    id?: true
    uuid?: true
    name?: true
    parent_org_id?: true
    path?: true
    maps_api_key?: true
    can_inherit_key?: true
    created_at?: true
    updated_at?: true
  }

  export type OrganisationsMaxAggregateInputType = {
    id?: true
    uuid?: true
    name?: true
    parent_org_id?: true
    path?: true
    maps_api_key?: true
    can_inherit_key?: true
    created_at?: true
    updated_at?: true
  }

  export type OrganisationsCountAggregateInputType = {
    id?: true
    uuid?: true
    name?: true
    parent_org_id?: true
    path?: true
    maps_api_key?: true
    can_inherit_key?: true
    attributes?: true
    created_at?: true
    updated_at?: true
    _all?: true
  }

  export type OrganisationsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which organisations to aggregate.
     */
    where?: organisationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of organisations to fetch.
     */
    orderBy?: organisationsOrderByWithRelationInput | organisationsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: organisationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` organisations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` organisations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned organisations
    **/
    _count?: true | OrganisationsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: OrganisationsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: OrganisationsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: OrganisationsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: OrganisationsMaxAggregateInputType
  }

  export type GetOrganisationsAggregateType<T extends OrganisationsAggregateArgs> = {
        [P in keyof T & keyof AggregateOrganisations]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOrganisations[P]>
      : GetScalarType<T[P], AggregateOrganisations[P]>
  }




  export type organisationsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: organisationsWhereInput
    orderBy?: organisationsOrderByWithAggregationInput | organisationsOrderByWithAggregationInput[]
    by: OrganisationsScalarFieldEnum[] | OrganisationsScalarFieldEnum
    having?: organisationsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: OrganisationsCountAggregateInputType | true
    _avg?: OrganisationsAvgAggregateInputType
    _sum?: OrganisationsSumAggregateInputType
    _min?: OrganisationsMinAggregateInputType
    _max?: OrganisationsMaxAggregateInputType
  }

  export type OrganisationsGroupByOutputType = {
    id: bigint
    uuid: string
    name: string
    parent_org_id: bigint | null
    path: string | null
    maps_api_key: string | null
    can_inherit_key: boolean | null
    attributes: JsonValue
    created_at: Date
    updated_at: Date
    _count: OrganisationsCountAggregateOutputType | null
    _avg: OrganisationsAvgAggregateOutputType | null
    _sum: OrganisationsSumAggregateOutputType | null
    _min: OrganisationsMinAggregateOutputType | null
    _max: OrganisationsMaxAggregateOutputType | null
  }

  type GetOrganisationsGroupByPayload<T extends organisationsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<OrganisationsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof OrganisationsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], OrganisationsGroupByOutputType[P]>
            : GetScalarType<T[P], OrganisationsGroupByOutputType[P]>
        }
      >
    >


  export type organisationsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    name?: boolean
    parent_org_id?: boolean
    path?: boolean
    maps_api_key?: boolean
    can_inherit_key?: boolean
    attributes?: boolean
    created_at?: boolean
    updated_at?: boolean
    assets?: boolean | organisations$assetsArgs<ExtArgs>
    devices?: boolean | organisations$devicesArgs<ExtArgs>
    organisations?: boolean | organisations$organisationsArgs<ExtArgs>
    other_organisations?: boolean | organisations$other_organisationsArgs<ExtArgs>
    user_organisation_access?: boolean | organisations$user_organisation_accessArgs<ExtArgs>
    users?: boolean | organisations$usersArgs<ExtArgs>
    _count?: boolean | OrganisationsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["organisations"]>

  export type organisationsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    name?: boolean
    parent_org_id?: boolean
    path?: boolean
    maps_api_key?: boolean
    can_inherit_key?: boolean
    attributes?: boolean
    created_at?: boolean
    updated_at?: boolean
    organisations?: boolean | organisations$organisationsArgs<ExtArgs>
  }, ExtArgs["result"]["organisations"]>

  export type organisationsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    name?: boolean
    parent_org_id?: boolean
    path?: boolean
    maps_api_key?: boolean
    can_inherit_key?: boolean
    attributes?: boolean
    created_at?: boolean
    updated_at?: boolean
    organisations?: boolean | organisations$organisationsArgs<ExtArgs>
  }, ExtArgs["result"]["organisations"]>

  export type organisationsSelectScalar = {
    id?: boolean
    uuid?: boolean
    name?: boolean
    parent_org_id?: boolean
    path?: boolean
    maps_api_key?: boolean
    can_inherit_key?: boolean
    attributes?: boolean
    created_at?: boolean
    updated_at?: boolean
  }

  export type organisationsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "uuid" | "name" | "parent_org_id" | "path" | "maps_api_key" | "can_inherit_key" | "attributes" | "created_at" | "updated_at", ExtArgs["result"]["organisations"]>
  export type organisationsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | organisations$assetsArgs<ExtArgs>
    devices?: boolean | organisations$devicesArgs<ExtArgs>
    organisations?: boolean | organisations$organisationsArgs<ExtArgs>
    other_organisations?: boolean | organisations$other_organisationsArgs<ExtArgs>
    user_organisation_access?: boolean | organisations$user_organisation_accessArgs<ExtArgs>
    users?: boolean | organisations$usersArgs<ExtArgs>
    _count?: boolean | OrganisationsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type organisationsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisations$organisationsArgs<ExtArgs>
  }
  export type organisationsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisations$organisationsArgs<ExtArgs>
  }

  export type $organisationsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "organisations"
    objects: {
      assets: Prisma.$assetsPayload<ExtArgs>[]
      devices: Prisma.$devicesPayload<ExtArgs>[]
      organisations: Prisma.$organisationsPayload<ExtArgs> | null
      other_organisations: Prisma.$organisationsPayload<ExtArgs>[]
      user_organisation_access: Prisma.$user_organisation_accessPayload<ExtArgs>[]
      users: Prisma.$usersPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      uuid: string
      name: string
      parent_org_id: bigint | null
      path: string | null
      maps_api_key: string | null
      can_inherit_key: boolean | null
      attributes: Prisma.JsonValue
      created_at: Date
      updated_at: Date
    }, ExtArgs["result"]["organisations"]>
    composites: {}
  }

  type organisationsGetPayload<S extends boolean | null | undefined | organisationsDefaultArgs> = $Result.GetResult<Prisma.$organisationsPayload, S>

  type organisationsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<organisationsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: OrganisationsCountAggregateInputType | true
    }

  export interface organisationsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['organisations'], meta: { name: 'organisations' } }
    /**
     * Find zero or one Organisations that matches the filter.
     * @param {organisationsFindUniqueArgs} args - Arguments to find a Organisations
     * @example
     * // Get one Organisations
     * const organisations = await prisma.organisations.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends organisationsFindUniqueArgs>(args: SelectSubset<T, organisationsFindUniqueArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Organisations that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {organisationsFindUniqueOrThrowArgs} args - Arguments to find a Organisations
     * @example
     * // Get one Organisations
     * const organisations = await prisma.organisations.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends organisationsFindUniqueOrThrowArgs>(args: SelectSubset<T, organisationsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Organisations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {organisationsFindFirstArgs} args - Arguments to find a Organisations
     * @example
     * // Get one Organisations
     * const organisations = await prisma.organisations.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends organisationsFindFirstArgs>(args?: SelectSubset<T, organisationsFindFirstArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Organisations that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {organisationsFindFirstOrThrowArgs} args - Arguments to find a Organisations
     * @example
     * // Get one Organisations
     * const organisations = await prisma.organisations.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends organisationsFindFirstOrThrowArgs>(args?: SelectSubset<T, organisationsFindFirstOrThrowArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Organisations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {organisationsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Organisations
     * const organisations = await prisma.organisations.findMany()
     * 
     * // Get first 10 Organisations
     * const organisations = await prisma.organisations.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const organisationsWithIdOnly = await prisma.organisations.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends organisationsFindManyArgs>(args?: SelectSubset<T, organisationsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Organisations.
     * @param {organisationsCreateArgs} args - Arguments to create a Organisations.
     * @example
     * // Create one Organisations
     * const Organisations = await prisma.organisations.create({
     *   data: {
     *     // ... data to create a Organisations
     *   }
     * })
     * 
     */
    create<T extends organisationsCreateArgs>(args: SelectSubset<T, organisationsCreateArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Organisations.
     * @param {organisationsCreateManyArgs} args - Arguments to create many Organisations.
     * @example
     * // Create many Organisations
     * const organisations = await prisma.organisations.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends organisationsCreateManyArgs>(args?: SelectSubset<T, organisationsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Organisations and returns the data saved in the database.
     * @param {organisationsCreateManyAndReturnArgs} args - Arguments to create many Organisations.
     * @example
     * // Create many Organisations
     * const organisations = await prisma.organisations.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Organisations and only return the `id`
     * const organisationsWithIdOnly = await prisma.organisations.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends organisationsCreateManyAndReturnArgs>(args?: SelectSubset<T, organisationsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Organisations.
     * @param {organisationsDeleteArgs} args - Arguments to delete one Organisations.
     * @example
     * // Delete one Organisations
     * const Organisations = await prisma.organisations.delete({
     *   where: {
     *     // ... filter to delete one Organisations
     *   }
     * })
     * 
     */
    delete<T extends organisationsDeleteArgs>(args: SelectSubset<T, organisationsDeleteArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Organisations.
     * @param {organisationsUpdateArgs} args - Arguments to update one Organisations.
     * @example
     * // Update one Organisations
     * const organisations = await prisma.organisations.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends organisationsUpdateArgs>(args: SelectSubset<T, organisationsUpdateArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Organisations.
     * @param {organisationsDeleteManyArgs} args - Arguments to filter Organisations to delete.
     * @example
     * // Delete a few Organisations
     * const { count } = await prisma.organisations.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends organisationsDeleteManyArgs>(args?: SelectSubset<T, organisationsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Organisations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {organisationsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Organisations
     * const organisations = await prisma.organisations.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends organisationsUpdateManyArgs>(args: SelectSubset<T, organisationsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Organisations and returns the data updated in the database.
     * @param {organisationsUpdateManyAndReturnArgs} args - Arguments to update many Organisations.
     * @example
     * // Update many Organisations
     * const organisations = await prisma.organisations.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Organisations and only return the `id`
     * const organisationsWithIdOnly = await prisma.organisations.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends organisationsUpdateManyAndReturnArgs>(args: SelectSubset<T, organisationsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Organisations.
     * @param {organisationsUpsertArgs} args - Arguments to update or create a Organisations.
     * @example
     * // Update or create a Organisations
     * const organisations = await prisma.organisations.upsert({
     *   create: {
     *     // ... data to create a Organisations
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Organisations we want to update
     *   }
     * })
     */
    upsert<T extends organisationsUpsertArgs>(args: SelectSubset<T, organisationsUpsertArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Organisations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {organisationsCountArgs} args - Arguments to filter Organisations to count.
     * @example
     * // Count the number of Organisations
     * const count = await prisma.organisations.count({
     *   where: {
     *     // ... the filter for the Organisations we want to count
     *   }
     * })
    **/
    count<T extends organisationsCountArgs>(
      args?: Subset<T, organisationsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], OrganisationsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Organisations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrganisationsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends OrganisationsAggregateArgs>(args: Subset<T, OrganisationsAggregateArgs>): Prisma.PrismaPromise<GetOrganisationsAggregateType<T>>

    /**
     * Group by Organisations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {organisationsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends organisationsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: organisationsGroupByArgs['orderBy'] }
        : { orderBy?: organisationsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, organisationsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOrganisationsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the organisations model
   */
  readonly fields: organisationsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for organisations.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__organisationsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    assets<T extends organisations$assetsArgs<ExtArgs> = {}>(args?: Subset<T, organisations$assetsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    devices<T extends organisations$devicesArgs<ExtArgs> = {}>(args?: Subset<T, organisations$devicesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    organisations<T extends organisations$organisationsArgs<ExtArgs> = {}>(args?: Subset<T, organisations$organisationsArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    other_organisations<T extends organisations$other_organisationsArgs<ExtArgs> = {}>(args?: Subset<T, organisations$other_organisationsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    user_organisation_access<T extends organisations$user_organisation_accessArgs<ExtArgs> = {}>(args?: Subset<T, organisations$user_organisation_accessArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    users<T extends organisations$usersArgs<ExtArgs> = {}>(args?: Subset<T, organisations$usersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the organisations model
   */
  interface organisationsFieldRefs {
    readonly id: FieldRef<"organisations", 'BigInt'>
    readonly uuid: FieldRef<"organisations", 'String'>
    readonly name: FieldRef<"organisations", 'String'>
    readonly parent_org_id: FieldRef<"organisations", 'BigInt'>
    readonly path: FieldRef<"organisations", 'String'>
    readonly maps_api_key: FieldRef<"organisations", 'String'>
    readonly can_inherit_key: FieldRef<"organisations", 'Boolean'>
    readonly attributes: FieldRef<"organisations", 'Json'>
    readonly created_at: FieldRef<"organisations", 'DateTime'>
    readonly updated_at: FieldRef<"organisations", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * organisations findUnique
   */
  export type organisationsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * Filter, which organisations to fetch.
     */
    where: organisationsWhereUniqueInput
  }

  /**
   * organisations findUniqueOrThrow
   */
  export type organisationsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * Filter, which organisations to fetch.
     */
    where: organisationsWhereUniqueInput
  }

  /**
   * organisations findFirst
   */
  export type organisationsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * Filter, which organisations to fetch.
     */
    where?: organisationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of organisations to fetch.
     */
    orderBy?: organisationsOrderByWithRelationInput | organisationsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for organisations.
     */
    cursor?: organisationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` organisations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` organisations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of organisations.
     */
    distinct?: OrganisationsScalarFieldEnum | OrganisationsScalarFieldEnum[]
  }

  /**
   * organisations findFirstOrThrow
   */
  export type organisationsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * Filter, which organisations to fetch.
     */
    where?: organisationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of organisations to fetch.
     */
    orderBy?: organisationsOrderByWithRelationInput | organisationsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for organisations.
     */
    cursor?: organisationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` organisations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` organisations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of organisations.
     */
    distinct?: OrganisationsScalarFieldEnum | OrganisationsScalarFieldEnum[]
  }

  /**
   * organisations findMany
   */
  export type organisationsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * Filter, which organisations to fetch.
     */
    where?: organisationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of organisations to fetch.
     */
    orderBy?: organisationsOrderByWithRelationInput | organisationsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing organisations.
     */
    cursor?: organisationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` organisations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` organisations.
     */
    skip?: number
    distinct?: OrganisationsScalarFieldEnum | OrganisationsScalarFieldEnum[]
  }

  /**
   * organisations create
   */
  export type organisationsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * The data needed to create a organisations.
     */
    data: XOR<organisationsCreateInput, organisationsUncheckedCreateInput>
  }

  /**
   * organisations createMany
   */
  export type organisationsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many organisations.
     */
    data: organisationsCreateManyInput | organisationsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * organisations createManyAndReturn
   */
  export type organisationsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * The data used to create many organisations.
     */
    data: organisationsCreateManyInput | organisationsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * organisations update
   */
  export type organisationsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * The data needed to update a organisations.
     */
    data: XOR<organisationsUpdateInput, organisationsUncheckedUpdateInput>
    /**
     * Choose, which organisations to update.
     */
    where: organisationsWhereUniqueInput
  }

  /**
   * organisations updateMany
   */
  export type organisationsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update organisations.
     */
    data: XOR<organisationsUpdateManyMutationInput, organisationsUncheckedUpdateManyInput>
    /**
     * Filter which organisations to update
     */
    where?: organisationsWhereInput
    /**
     * Limit how many organisations to update.
     */
    limit?: number
  }

  /**
   * organisations updateManyAndReturn
   */
  export type organisationsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * The data used to update organisations.
     */
    data: XOR<organisationsUpdateManyMutationInput, organisationsUncheckedUpdateManyInput>
    /**
     * Filter which organisations to update
     */
    where?: organisationsWhereInput
    /**
     * Limit how many organisations to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * organisations upsert
   */
  export type organisationsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * The filter to search for the organisations to update in case it exists.
     */
    where: organisationsWhereUniqueInput
    /**
     * In case the organisations found by the `where` argument doesn't exist, create a new organisations with this data.
     */
    create: XOR<organisationsCreateInput, organisationsUncheckedCreateInput>
    /**
     * In case the organisations was found with the provided `where` argument, update it with this data.
     */
    update: XOR<organisationsUpdateInput, organisationsUncheckedUpdateInput>
  }

  /**
   * organisations delete
   */
  export type organisationsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    /**
     * Filter which organisations to delete.
     */
    where: organisationsWhereUniqueInput
  }

  /**
   * organisations deleteMany
   */
  export type organisationsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which organisations to delete
     */
    where?: organisationsWhereInput
    /**
     * Limit how many organisations to delete.
     */
    limit?: number
  }

  /**
   * organisations.assets
   */
  export type organisations$assetsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the assets
     */
    select?: assetsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the assets
     */
    omit?: assetsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: assetsInclude<ExtArgs> | null
    where?: assetsWhereInput
    orderBy?: assetsOrderByWithRelationInput | assetsOrderByWithRelationInput[]
    cursor?: assetsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: AssetsScalarFieldEnum | AssetsScalarFieldEnum[]
  }

  /**
   * organisations.devices
   */
  export type organisations$devicesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the devices
     */
    select?: devicesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the devices
     */
    omit?: devicesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: devicesInclude<ExtArgs> | null
    where?: devicesWhereInput
    orderBy?: devicesOrderByWithRelationInput | devicesOrderByWithRelationInput[]
    cursor?: devicesWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DevicesScalarFieldEnum | DevicesScalarFieldEnum[]
  }

  /**
   * organisations.organisations
   */
  export type organisations$organisationsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    where?: organisationsWhereInput
  }

  /**
   * organisations.other_organisations
   */
  export type organisations$other_organisationsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
    where?: organisationsWhereInput
    orderBy?: organisationsOrderByWithRelationInput | organisationsOrderByWithRelationInput[]
    cursor?: organisationsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: OrganisationsScalarFieldEnum | OrganisationsScalarFieldEnum[]
  }

  /**
   * organisations.user_organisation_access
   */
  export type organisations$user_organisation_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    where?: user_organisation_accessWhereInput
    orderBy?: user_organisation_accessOrderByWithRelationInput | user_organisation_accessOrderByWithRelationInput[]
    cursor?: user_organisation_accessWhereUniqueInput
    take?: number
    skip?: number
    distinct?: User_organisation_accessScalarFieldEnum | User_organisation_accessScalarFieldEnum[]
  }

  /**
   * organisations.users
   */
  export type organisations$usersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    where?: usersWhereInput
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    cursor?: usersWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * organisations without action
   */
  export type organisationsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the organisations
     */
    select?: organisationsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the organisations
     */
    omit?: organisationsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: organisationsInclude<ExtArgs> | null
  }


  /**
   * Model permissions
   */

  export type AggregatePermissions = {
    _count: PermissionsCountAggregateOutputType | null
    _avg: PermissionsAvgAggregateOutputType | null
    _sum: PermissionsSumAggregateOutputType | null
    _min: PermissionsMinAggregateOutputType | null
    _max: PermissionsMaxAggregateOutputType | null
  }

  export type PermissionsAvgAggregateOutputType = {
    perm_id: number | null
  }

  export type PermissionsSumAggregateOutputType = {
    perm_id: number | null
  }

  export type PermissionsMinAggregateOutputType = {
    perm_id: number | null
    key: string | null
    description: string | null
  }

  export type PermissionsMaxAggregateOutputType = {
    perm_id: number | null
    key: string | null
    description: string | null
  }

  export type PermissionsCountAggregateOutputType = {
    perm_id: number
    key: number
    description: number
    _all: number
  }


  export type PermissionsAvgAggregateInputType = {
    perm_id?: true
  }

  export type PermissionsSumAggregateInputType = {
    perm_id?: true
  }

  export type PermissionsMinAggregateInputType = {
    perm_id?: true
    key?: true
    description?: true
  }

  export type PermissionsMaxAggregateInputType = {
    perm_id?: true
    key?: true
    description?: true
  }

  export type PermissionsCountAggregateInputType = {
    perm_id?: true
    key?: true
    description?: true
    _all?: true
  }

  export type PermissionsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which permissions to aggregate.
     */
    where?: permissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of permissions to fetch.
     */
    orderBy?: permissionsOrderByWithRelationInput | permissionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: permissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned permissions
    **/
    _count?: true | PermissionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PermissionsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PermissionsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PermissionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PermissionsMaxAggregateInputType
  }

  export type GetPermissionsAggregateType<T extends PermissionsAggregateArgs> = {
        [P in keyof T & keyof AggregatePermissions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePermissions[P]>
      : GetScalarType<T[P], AggregatePermissions[P]>
  }




  export type permissionsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: permissionsWhereInput
    orderBy?: permissionsOrderByWithAggregationInput | permissionsOrderByWithAggregationInput[]
    by: PermissionsScalarFieldEnum[] | PermissionsScalarFieldEnum
    having?: permissionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PermissionsCountAggregateInputType | true
    _avg?: PermissionsAvgAggregateInputType
    _sum?: PermissionsSumAggregateInputType
    _min?: PermissionsMinAggregateInputType
    _max?: PermissionsMaxAggregateInputType
  }

  export type PermissionsGroupByOutputType = {
    perm_id: number
    key: string
    description: string
    _count: PermissionsCountAggregateOutputType | null
    _avg: PermissionsAvgAggregateOutputType | null
    _sum: PermissionsSumAggregateOutputType | null
    _min: PermissionsMinAggregateOutputType | null
    _max: PermissionsMaxAggregateOutputType | null
  }

  type GetPermissionsGroupByPayload<T extends permissionsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PermissionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PermissionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PermissionsGroupByOutputType[P]>
            : GetScalarType<T[P], PermissionsGroupByOutputType[P]>
        }
      >
    >


  export type permissionsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    perm_id?: boolean
    key?: boolean
    description?: boolean
    role_permissions?: boolean | permissions$role_permissionsArgs<ExtArgs>
    _count?: boolean | PermissionsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["permissions"]>

  export type permissionsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    perm_id?: boolean
    key?: boolean
    description?: boolean
  }, ExtArgs["result"]["permissions"]>

  export type permissionsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    perm_id?: boolean
    key?: boolean
    description?: boolean
  }, ExtArgs["result"]["permissions"]>

  export type permissionsSelectScalar = {
    perm_id?: boolean
    key?: boolean
    description?: boolean
  }

  export type permissionsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"perm_id" | "key" | "description", ExtArgs["result"]["permissions"]>
  export type permissionsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    role_permissions?: boolean | permissions$role_permissionsArgs<ExtArgs>
    _count?: boolean | PermissionsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type permissionsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type permissionsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $permissionsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "permissions"
    objects: {
      role_permissions: Prisma.$role_permissionsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      perm_id: number
      key: string
      description: string
    }, ExtArgs["result"]["permissions"]>
    composites: {}
  }

  type permissionsGetPayload<S extends boolean | null | undefined | permissionsDefaultArgs> = $Result.GetResult<Prisma.$permissionsPayload, S>

  type permissionsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<permissionsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PermissionsCountAggregateInputType | true
    }

  export interface permissionsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['permissions'], meta: { name: 'permissions' } }
    /**
     * Find zero or one Permissions that matches the filter.
     * @param {permissionsFindUniqueArgs} args - Arguments to find a Permissions
     * @example
     * // Get one Permissions
     * const permissions = await prisma.permissions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends permissionsFindUniqueArgs>(args: SelectSubset<T, permissionsFindUniqueArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Permissions that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {permissionsFindUniqueOrThrowArgs} args - Arguments to find a Permissions
     * @example
     * // Get one Permissions
     * const permissions = await prisma.permissions.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends permissionsFindUniqueOrThrowArgs>(args: SelectSubset<T, permissionsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Permissions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {permissionsFindFirstArgs} args - Arguments to find a Permissions
     * @example
     * // Get one Permissions
     * const permissions = await prisma.permissions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends permissionsFindFirstArgs>(args?: SelectSubset<T, permissionsFindFirstArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Permissions that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {permissionsFindFirstOrThrowArgs} args - Arguments to find a Permissions
     * @example
     * // Get one Permissions
     * const permissions = await prisma.permissions.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends permissionsFindFirstOrThrowArgs>(args?: SelectSubset<T, permissionsFindFirstOrThrowArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Permissions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {permissionsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Permissions
     * const permissions = await prisma.permissions.findMany()
     * 
     * // Get first 10 Permissions
     * const permissions = await prisma.permissions.findMany({ take: 10 })
     * 
     * // Only select the `perm_id`
     * const permissionsWithPerm_idOnly = await prisma.permissions.findMany({ select: { perm_id: true } })
     * 
     */
    findMany<T extends permissionsFindManyArgs>(args?: SelectSubset<T, permissionsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Permissions.
     * @param {permissionsCreateArgs} args - Arguments to create a Permissions.
     * @example
     * // Create one Permissions
     * const Permissions = await prisma.permissions.create({
     *   data: {
     *     // ... data to create a Permissions
     *   }
     * })
     * 
     */
    create<T extends permissionsCreateArgs>(args: SelectSubset<T, permissionsCreateArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Permissions.
     * @param {permissionsCreateManyArgs} args - Arguments to create many Permissions.
     * @example
     * // Create many Permissions
     * const permissions = await prisma.permissions.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends permissionsCreateManyArgs>(args?: SelectSubset<T, permissionsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Permissions and returns the data saved in the database.
     * @param {permissionsCreateManyAndReturnArgs} args - Arguments to create many Permissions.
     * @example
     * // Create many Permissions
     * const permissions = await prisma.permissions.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Permissions and only return the `perm_id`
     * const permissionsWithPerm_idOnly = await prisma.permissions.createManyAndReturn({
     *   select: { perm_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends permissionsCreateManyAndReturnArgs>(args?: SelectSubset<T, permissionsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Permissions.
     * @param {permissionsDeleteArgs} args - Arguments to delete one Permissions.
     * @example
     * // Delete one Permissions
     * const Permissions = await prisma.permissions.delete({
     *   where: {
     *     // ... filter to delete one Permissions
     *   }
     * })
     * 
     */
    delete<T extends permissionsDeleteArgs>(args: SelectSubset<T, permissionsDeleteArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Permissions.
     * @param {permissionsUpdateArgs} args - Arguments to update one Permissions.
     * @example
     * // Update one Permissions
     * const permissions = await prisma.permissions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends permissionsUpdateArgs>(args: SelectSubset<T, permissionsUpdateArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Permissions.
     * @param {permissionsDeleteManyArgs} args - Arguments to filter Permissions to delete.
     * @example
     * // Delete a few Permissions
     * const { count } = await prisma.permissions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends permissionsDeleteManyArgs>(args?: SelectSubset<T, permissionsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {permissionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Permissions
     * const permissions = await prisma.permissions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends permissionsUpdateManyArgs>(args: SelectSubset<T, permissionsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Permissions and returns the data updated in the database.
     * @param {permissionsUpdateManyAndReturnArgs} args - Arguments to update many Permissions.
     * @example
     * // Update many Permissions
     * const permissions = await prisma.permissions.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Permissions and only return the `perm_id`
     * const permissionsWithPerm_idOnly = await prisma.permissions.updateManyAndReturn({
     *   select: { perm_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends permissionsUpdateManyAndReturnArgs>(args: SelectSubset<T, permissionsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Permissions.
     * @param {permissionsUpsertArgs} args - Arguments to update or create a Permissions.
     * @example
     * // Update or create a Permissions
     * const permissions = await prisma.permissions.upsert({
     *   create: {
     *     // ... data to create a Permissions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Permissions we want to update
     *   }
     * })
     */
    upsert<T extends permissionsUpsertArgs>(args: SelectSubset<T, permissionsUpsertArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {permissionsCountArgs} args - Arguments to filter Permissions to count.
     * @example
     * // Count the number of Permissions
     * const count = await prisma.permissions.count({
     *   where: {
     *     // ... the filter for the Permissions we want to count
     *   }
     * })
    **/
    count<T extends permissionsCountArgs>(
      args?: Subset<T, permissionsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PermissionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PermissionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PermissionsAggregateArgs>(args: Subset<T, PermissionsAggregateArgs>): Prisma.PrismaPromise<GetPermissionsAggregateType<T>>

    /**
     * Group by Permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {permissionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends permissionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: permissionsGroupByArgs['orderBy'] }
        : { orderBy?: permissionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, permissionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPermissionsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the permissions model
   */
  readonly fields: permissionsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for permissions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__permissionsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    role_permissions<T extends permissions$role_permissionsArgs<ExtArgs> = {}>(args?: Subset<T, permissions$role_permissionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the permissions model
   */
  interface permissionsFieldRefs {
    readonly perm_id: FieldRef<"permissions", 'Int'>
    readonly key: FieldRef<"permissions", 'String'>
    readonly description: FieldRef<"permissions", 'String'>
  }
    

  // Custom InputTypes
  /**
   * permissions findUnique
   */
  export type permissionsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * Filter, which permissions to fetch.
     */
    where: permissionsWhereUniqueInput
  }

  /**
   * permissions findUniqueOrThrow
   */
  export type permissionsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * Filter, which permissions to fetch.
     */
    where: permissionsWhereUniqueInput
  }

  /**
   * permissions findFirst
   */
  export type permissionsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * Filter, which permissions to fetch.
     */
    where?: permissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of permissions to fetch.
     */
    orderBy?: permissionsOrderByWithRelationInput | permissionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for permissions.
     */
    cursor?: permissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of permissions.
     */
    distinct?: PermissionsScalarFieldEnum | PermissionsScalarFieldEnum[]
  }

  /**
   * permissions findFirstOrThrow
   */
  export type permissionsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * Filter, which permissions to fetch.
     */
    where?: permissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of permissions to fetch.
     */
    orderBy?: permissionsOrderByWithRelationInput | permissionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for permissions.
     */
    cursor?: permissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of permissions.
     */
    distinct?: PermissionsScalarFieldEnum | PermissionsScalarFieldEnum[]
  }

  /**
   * permissions findMany
   */
  export type permissionsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * Filter, which permissions to fetch.
     */
    where?: permissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of permissions to fetch.
     */
    orderBy?: permissionsOrderByWithRelationInput | permissionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing permissions.
     */
    cursor?: permissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` permissions.
     */
    skip?: number
    distinct?: PermissionsScalarFieldEnum | PermissionsScalarFieldEnum[]
  }

  /**
   * permissions create
   */
  export type permissionsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * The data needed to create a permissions.
     */
    data: XOR<permissionsCreateInput, permissionsUncheckedCreateInput>
  }

  /**
   * permissions createMany
   */
  export type permissionsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many permissions.
     */
    data: permissionsCreateManyInput | permissionsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * permissions createManyAndReturn
   */
  export type permissionsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * The data used to create many permissions.
     */
    data: permissionsCreateManyInput | permissionsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * permissions update
   */
  export type permissionsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * The data needed to update a permissions.
     */
    data: XOR<permissionsUpdateInput, permissionsUncheckedUpdateInput>
    /**
     * Choose, which permissions to update.
     */
    where: permissionsWhereUniqueInput
  }

  /**
   * permissions updateMany
   */
  export type permissionsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update permissions.
     */
    data: XOR<permissionsUpdateManyMutationInput, permissionsUncheckedUpdateManyInput>
    /**
     * Filter which permissions to update
     */
    where?: permissionsWhereInput
    /**
     * Limit how many permissions to update.
     */
    limit?: number
  }

  /**
   * permissions updateManyAndReturn
   */
  export type permissionsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * The data used to update permissions.
     */
    data: XOR<permissionsUpdateManyMutationInput, permissionsUncheckedUpdateManyInput>
    /**
     * Filter which permissions to update
     */
    where?: permissionsWhereInput
    /**
     * Limit how many permissions to update.
     */
    limit?: number
  }

  /**
   * permissions upsert
   */
  export type permissionsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * The filter to search for the permissions to update in case it exists.
     */
    where: permissionsWhereUniqueInput
    /**
     * In case the permissions found by the `where` argument doesn't exist, create a new permissions with this data.
     */
    create: XOR<permissionsCreateInput, permissionsUncheckedCreateInput>
    /**
     * In case the permissions was found with the provided `where` argument, update it with this data.
     */
    update: XOR<permissionsUpdateInput, permissionsUncheckedUpdateInput>
  }

  /**
   * permissions delete
   */
  export type permissionsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
    /**
     * Filter which permissions to delete.
     */
    where: permissionsWhereUniqueInput
  }

  /**
   * permissions deleteMany
   */
  export type permissionsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which permissions to delete
     */
    where?: permissionsWhereInput
    /**
     * Limit how many permissions to delete.
     */
    limit?: number
  }

  /**
   * permissions.role_permissions
   */
  export type permissions$role_permissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    where?: role_permissionsWhereInput
    orderBy?: role_permissionsOrderByWithRelationInput | role_permissionsOrderByWithRelationInput[]
    cursor?: role_permissionsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Role_permissionsScalarFieldEnum | Role_permissionsScalarFieldEnum[]
  }

  /**
   * permissions without action
   */
  export type permissionsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the permissions
     */
    select?: permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the permissions
     */
    omit?: permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: permissionsInclude<ExtArgs> | null
  }


  /**
   * Model role_permissions
   */

  export type AggregateRole_permissions = {
    _count: Role_permissionsCountAggregateOutputType | null
    _avg: Role_permissionsAvgAggregateOutputType | null
    _sum: Role_permissionsSumAggregateOutputType | null
    _min: Role_permissionsMinAggregateOutputType | null
    _max: Role_permissionsMaxAggregateOutputType | null
  }

  export type Role_permissionsAvgAggregateOutputType = {
    role_id: number | null
    perm_id: number | null
  }

  export type Role_permissionsSumAggregateOutputType = {
    role_id: number | null
    perm_id: number | null
  }

  export type Role_permissionsMinAggregateOutputType = {
    role_id: number | null
    perm_id: number | null
  }

  export type Role_permissionsMaxAggregateOutputType = {
    role_id: number | null
    perm_id: number | null
  }

  export type Role_permissionsCountAggregateOutputType = {
    role_id: number
    perm_id: number
    _all: number
  }


  export type Role_permissionsAvgAggregateInputType = {
    role_id?: true
    perm_id?: true
  }

  export type Role_permissionsSumAggregateInputType = {
    role_id?: true
    perm_id?: true
  }

  export type Role_permissionsMinAggregateInputType = {
    role_id?: true
    perm_id?: true
  }

  export type Role_permissionsMaxAggregateInputType = {
    role_id?: true
    perm_id?: true
  }

  export type Role_permissionsCountAggregateInputType = {
    role_id?: true
    perm_id?: true
    _all?: true
  }

  export type Role_permissionsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which role_permissions to aggregate.
     */
    where?: role_permissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of role_permissions to fetch.
     */
    orderBy?: role_permissionsOrderByWithRelationInput | role_permissionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: role_permissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` role_permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` role_permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned role_permissions
    **/
    _count?: true | Role_permissionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Role_permissionsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Role_permissionsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Role_permissionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Role_permissionsMaxAggregateInputType
  }

  export type GetRole_permissionsAggregateType<T extends Role_permissionsAggregateArgs> = {
        [P in keyof T & keyof AggregateRole_permissions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRole_permissions[P]>
      : GetScalarType<T[P], AggregateRole_permissions[P]>
  }




  export type role_permissionsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: role_permissionsWhereInput
    orderBy?: role_permissionsOrderByWithAggregationInput | role_permissionsOrderByWithAggregationInput[]
    by: Role_permissionsScalarFieldEnum[] | Role_permissionsScalarFieldEnum
    having?: role_permissionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Role_permissionsCountAggregateInputType | true
    _avg?: Role_permissionsAvgAggregateInputType
    _sum?: Role_permissionsSumAggregateInputType
    _min?: Role_permissionsMinAggregateInputType
    _max?: Role_permissionsMaxAggregateInputType
  }

  export type Role_permissionsGroupByOutputType = {
    role_id: number
    perm_id: number
    _count: Role_permissionsCountAggregateOutputType | null
    _avg: Role_permissionsAvgAggregateOutputType | null
    _sum: Role_permissionsSumAggregateOutputType | null
    _min: Role_permissionsMinAggregateOutputType | null
    _max: Role_permissionsMaxAggregateOutputType | null
  }

  type GetRole_permissionsGroupByPayload<T extends role_permissionsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Role_permissionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Role_permissionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Role_permissionsGroupByOutputType[P]>
            : GetScalarType<T[P], Role_permissionsGroupByOutputType[P]>
        }
      >
    >


  export type role_permissionsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    role_id?: boolean
    perm_id?: boolean
    permissions?: boolean | permissionsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["role_permissions"]>

  export type role_permissionsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    role_id?: boolean
    perm_id?: boolean
    permissions?: boolean | permissionsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["role_permissions"]>

  export type role_permissionsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    role_id?: boolean
    perm_id?: boolean
    permissions?: boolean | permissionsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["role_permissions"]>

  export type role_permissionsSelectScalar = {
    role_id?: boolean
    perm_id?: boolean
  }

  export type role_permissionsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"role_id" | "perm_id", ExtArgs["result"]["role_permissions"]>
  export type role_permissionsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    permissions?: boolean | permissionsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }
  export type role_permissionsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    permissions?: boolean | permissionsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }
  export type role_permissionsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    permissions?: boolean | permissionsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }

  export type $role_permissionsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "role_permissions"
    objects: {
      permissions: Prisma.$permissionsPayload<ExtArgs>
      roles: Prisma.$rolesPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      role_id: number
      perm_id: number
    }, ExtArgs["result"]["role_permissions"]>
    composites: {}
  }

  type role_permissionsGetPayload<S extends boolean | null | undefined | role_permissionsDefaultArgs> = $Result.GetResult<Prisma.$role_permissionsPayload, S>

  type role_permissionsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<role_permissionsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Role_permissionsCountAggregateInputType | true
    }

  export interface role_permissionsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['role_permissions'], meta: { name: 'role_permissions' } }
    /**
     * Find zero or one Role_permissions that matches the filter.
     * @param {role_permissionsFindUniqueArgs} args - Arguments to find a Role_permissions
     * @example
     * // Get one Role_permissions
     * const role_permissions = await prisma.role_permissions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends role_permissionsFindUniqueArgs>(args: SelectSubset<T, role_permissionsFindUniqueArgs<ExtArgs>>): Prisma__role_permissionsClient<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Role_permissions that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {role_permissionsFindUniqueOrThrowArgs} args - Arguments to find a Role_permissions
     * @example
     * // Get one Role_permissions
     * const role_permissions = await prisma.role_permissions.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends role_permissionsFindUniqueOrThrowArgs>(args: SelectSubset<T, role_permissionsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__role_permissionsClient<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Role_permissions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {role_permissionsFindFirstArgs} args - Arguments to find a Role_permissions
     * @example
     * // Get one Role_permissions
     * const role_permissions = await prisma.role_permissions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends role_permissionsFindFirstArgs>(args?: SelectSubset<T, role_permissionsFindFirstArgs<ExtArgs>>): Prisma__role_permissionsClient<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Role_permissions that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {role_permissionsFindFirstOrThrowArgs} args - Arguments to find a Role_permissions
     * @example
     * // Get one Role_permissions
     * const role_permissions = await prisma.role_permissions.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends role_permissionsFindFirstOrThrowArgs>(args?: SelectSubset<T, role_permissionsFindFirstOrThrowArgs<ExtArgs>>): Prisma__role_permissionsClient<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Role_permissions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {role_permissionsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Role_permissions
     * const role_permissions = await prisma.role_permissions.findMany()
     * 
     * // Get first 10 Role_permissions
     * const role_permissions = await prisma.role_permissions.findMany({ take: 10 })
     * 
     * // Only select the `role_id`
     * const role_permissionsWithRole_idOnly = await prisma.role_permissions.findMany({ select: { role_id: true } })
     * 
     */
    findMany<T extends role_permissionsFindManyArgs>(args?: SelectSubset<T, role_permissionsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Role_permissions.
     * @param {role_permissionsCreateArgs} args - Arguments to create a Role_permissions.
     * @example
     * // Create one Role_permissions
     * const Role_permissions = await prisma.role_permissions.create({
     *   data: {
     *     // ... data to create a Role_permissions
     *   }
     * })
     * 
     */
    create<T extends role_permissionsCreateArgs>(args: SelectSubset<T, role_permissionsCreateArgs<ExtArgs>>): Prisma__role_permissionsClient<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Role_permissions.
     * @param {role_permissionsCreateManyArgs} args - Arguments to create many Role_permissions.
     * @example
     * // Create many Role_permissions
     * const role_permissions = await prisma.role_permissions.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends role_permissionsCreateManyArgs>(args?: SelectSubset<T, role_permissionsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Role_permissions and returns the data saved in the database.
     * @param {role_permissionsCreateManyAndReturnArgs} args - Arguments to create many Role_permissions.
     * @example
     * // Create many Role_permissions
     * const role_permissions = await prisma.role_permissions.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Role_permissions and only return the `role_id`
     * const role_permissionsWithRole_idOnly = await prisma.role_permissions.createManyAndReturn({
     *   select: { role_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends role_permissionsCreateManyAndReturnArgs>(args?: SelectSubset<T, role_permissionsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Role_permissions.
     * @param {role_permissionsDeleteArgs} args - Arguments to delete one Role_permissions.
     * @example
     * // Delete one Role_permissions
     * const Role_permissions = await prisma.role_permissions.delete({
     *   where: {
     *     // ... filter to delete one Role_permissions
     *   }
     * })
     * 
     */
    delete<T extends role_permissionsDeleteArgs>(args: SelectSubset<T, role_permissionsDeleteArgs<ExtArgs>>): Prisma__role_permissionsClient<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Role_permissions.
     * @param {role_permissionsUpdateArgs} args - Arguments to update one Role_permissions.
     * @example
     * // Update one Role_permissions
     * const role_permissions = await prisma.role_permissions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends role_permissionsUpdateArgs>(args: SelectSubset<T, role_permissionsUpdateArgs<ExtArgs>>): Prisma__role_permissionsClient<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Role_permissions.
     * @param {role_permissionsDeleteManyArgs} args - Arguments to filter Role_permissions to delete.
     * @example
     * // Delete a few Role_permissions
     * const { count } = await prisma.role_permissions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends role_permissionsDeleteManyArgs>(args?: SelectSubset<T, role_permissionsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Role_permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {role_permissionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Role_permissions
     * const role_permissions = await prisma.role_permissions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends role_permissionsUpdateManyArgs>(args: SelectSubset<T, role_permissionsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Role_permissions and returns the data updated in the database.
     * @param {role_permissionsUpdateManyAndReturnArgs} args - Arguments to update many Role_permissions.
     * @example
     * // Update many Role_permissions
     * const role_permissions = await prisma.role_permissions.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Role_permissions and only return the `role_id`
     * const role_permissionsWithRole_idOnly = await prisma.role_permissions.updateManyAndReturn({
     *   select: { role_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends role_permissionsUpdateManyAndReturnArgs>(args: SelectSubset<T, role_permissionsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Role_permissions.
     * @param {role_permissionsUpsertArgs} args - Arguments to update or create a Role_permissions.
     * @example
     * // Update or create a Role_permissions
     * const role_permissions = await prisma.role_permissions.upsert({
     *   create: {
     *     // ... data to create a Role_permissions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Role_permissions we want to update
     *   }
     * })
     */
    upsert<T extends role_permissionsUpsertArgs>(args: SelectSubset<T, role_permissionsUpsertArgs<ExtArgs>>): Prisma__role_permissionsClient<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Role_permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {role_permissionsCountArgs} args - Arguments to filter Role_permissions to count.
     * @example
     * // Count the number of Role_permissions
     * const count = await prisma.role_permissions.count({
     *   where: {
     *     // ... the filter for the Role_permissions we want to count
     *   }
     * })
    **/
    count<T extends role_permissionsCountArgs>(
      args?: Subset<T, role_permissionsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Role_permissionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Role_permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Role_permissionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Role_permissionsAggregateArgs>(args: Subset<T, Role_permissionsAggregateArgs>): Prisma.PrismaPromise<GetRole_permissionsAggregateType<T>>

    /**
     * Group by Role_permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {role_permissionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends role_permissionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: role_permissionsGroupByArgs['orderBy'] }
        : { orderBy?: role_permissionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, role_permissionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRole_permissionsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the role_permissions model
   */
  readonly fields: role_permissionsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for role_permissions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__role_permissionsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    permissions<T extends permissionsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, permissionsDefaultArgs<ExtArgs>>): Prisma__permissionsClient<$Result.GetResult<Prisma.$permissionsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    roles<T extends rolesDefaultArgs<ExtArgs> = {}>(args?: Subset<T, rolesDefaultArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the role_permissions model
   */
  interface role_permissionsFieldRefs {
    readonly role_id: FieldRef<"role_permissions", 'Int'>
    readonly perm_id: FieldRef<"role_permissions", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * role_permissions findUnique
   */
  export type role_permissionsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * Filter, which role_permissions to fetch.
     */
    where: role_permissionsWhereUniqueInput
  }

  /**
   * role_permissions findUniqueOrThrow
   */
  export type role_permissionsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * Filter, which role_permissions to fetch.
     */
    where: role_permissionsWhereUniqueInput
  }

  /**
   * role_permissions findFirst
   */
  export type role_permissionsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * Filter, which role_permissions to fetch.
     */
    where?: role_permissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of role_permissions to fetch.
     */
    orderBy?: role_permissionsOrderByWithRelationInput | role_permissionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for role_permissions.
     */
    cursor?: role_permissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` role_permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` role_permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of role_permissions.
     */
    distinct?: Role_permissionsScalarFieldEnum | Role_permissionsScalarFieldEnum[]
  }

  /**
   * role_permissions findFirstOrThrow
   */
  export type role_permissionsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * Filter, which role_permissions to fetch.
     */
    where?: role_permissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of role_permissions to fetch.
     */
    orderBy?: role_permissionsOrderByWithRelationInput | role_permissionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for role_permissions.
     */
    cursor?: role_permissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` role_permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` role_permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of role_permissions.
     */
    distinct?: Role_permissionsScalarFieldEnum | Role_permissionsScalarFieldEnum[]
  }

  /**
   * role_permissions findMany
   */
  export type role_permissionsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * Filter, which role_permissions to fetch.
     */
    where?: role_permissionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of role_permissions to fetch.
     */
    orderBy?: role_permissionsOrderByWithRelationInput | role_permissionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing role_permissions.
     */
    cursor?: role_permissionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` role_permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` role_permissions.
     */
    skip?: number
    distinct?: Role_permissionsScalarFieldEnum | Role_permissionsScalarFieldEnum[]
  }

  /**
   * role_permissions create
   */
  export type role_permissionsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * The data needed to create a role_permissions.
     */
    data: XOR<role_permissionsCreateInput, role_permissionsUncheckedCreateInput>
  }

  /**
   * role_permissions createMany
   */
  export type role_permissionsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many role_permissions.
     */
    data: role_permissionsCreateManyInput | role_permissionsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * role_permissions createManyAndReturn
   */
  export type role_permissionsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * The data used to create many role_permissions.
     */
    data: role_permissionsCreateManyInput | role_permissionsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * role_permissions update
   */
  export type role_permissionsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * The data needed to update a role_permissions.
     */
    data: XOR<role_permissionsUpdateInput, role_permissionsUncheckedUpdateInput>
    /**
     * Choose, which role_permissions to update.
     */
    where: role_permissionsWhereUniqueInput
  }

  /**
   * role_permissions updateMany
   */
  export type role_permissionsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update role_permissions.
     */
    data: XOR<role_permissionsUpdateManyMutationInput, role_permissionsUncheckedUpdateManyInput>
    /**
     * Filter which role_permissions to update
     */
    where?: role_permissionsWhereInput
    /**
     * Limit how many role_permissions to update.
     */
    limit?: number
  }

  /**
   * role_permissions updateManyAndReturn
   */
  export type role_permissionsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * The data used to update role_permissions.
     */
    data: XOR<role_permissionsUpdateManyMutationInput, role_permissionsUncheckedUpdateManyInput>
    /**
     * Filter which role_permissions to update
     */
    where?: role_permissionsWhereInput
    /**
     * Limit how many role_permissions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * role_permissions upsert
   */
  export type role_permissionsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * The filter to search for the role_permissions to update in case it exists.
     */
    where: role_permissionsWhereUniqueInput
    /**
     * In case the role_permissions found by the `where` argument doesn't exist, create a new role_permissions with this data.
     */
    create: XOR<role_permissionsCreateInput, role_permissionsUncheckedCreateInput>
    /**
     * In case the role_permissions was found with the provided `where` argument, update it with this data.
     */
    update: XOR<role_permissionsUpdateInput, role_permissionsUncheckedUpdateInput>
  }

  /**
   * role_permissions delete
   */
  export type role_permissionsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    /**
     * Filter which role_permissions to delete.
     */
    where: role_permissionsWhereUniqueInput
  }

  /**
   * role_permissions deleteMany
   */
  export type role_permissionsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which role_permissions to delete
     */
    where?: role_permissionsWhereInput
    /**
     * Limit how many role_permissions to delete.
     */
    limit?: number
  }

  /**
   * role_permissions without action
   */
  export type role_permissionsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
  }


  /**
   * Model roles
   */

  export type AggregateRoles = {
    _count: RolesCountAggregateOutputType | null
    _avg: RolesAvgAggregateOutputType | null
    _sum: RolesSumAggregateOutputType | null
    _min: RolesMinAggregateOutputType | null
    _max: RolesMaxAggregateOutputType | null
  }

  export type RolesAvgAggregateOutputType = {
    role_id: number | null
  }

  export type RolesSumAggregateOutputType = {
    role_id: number | null
  }

  export type RolesMinAggregateOutputType = {
    role_id: number | null
    name: string | null
  }

  export type RolesMaxAggregateOutputType = {
    role_id: number | null
    name: string | null
  }

  export type RolesCountAggregateOutputType = {
    role_id: number
    name: number
    _all: number
  }


  export type RolesAvgAggregateInputType = {
    role_id?: true
  }

  export type RolesSumAggregateInputType = {
    role_id?: true
  }

  export type RolesMinAggregateInputType = {
    role_id?: true
    name?: true
  }

  export type RolesMaxAggregateInputType = {
    role_id?: true
    name?: true
  }

  export type RolesCountAggregateInputType = {
    role_id?: true
    name?: true
    _all?: true
  }

  export type RolesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which roles to aggregate.
     */
    where?: rolesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of roles to fetch.
     */
    orderBy?: rolesOrderByWithRelationInput | rolesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: rolesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` roles from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` roles.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned roles
    **/
    _count?: true | RolesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: RolesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: RolesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: RolesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: RolesMaxAggregateInputType
  }

  export type GetRolesAggregateType<T extends RolesAggregateArgs> = {
        [P in keyof T & keyof AggregateRoles]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRoles[P]>
      : GetScalarType<T[P], AggregateRoles[P]>
  }




  export type rolesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: rolesWhereInput
    orderBy?: rolesOrderByWithAggregationInput | rolesOrderByWithAggregationInput[]
    by: RolesScalarFieldEnum[] | RolesScalarFieldEnum
    having?: rolesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: RolesCountAggregateInputType | true
    _avg?: RolesAvgAggregateInputType
    _sum?: RolesSumAggregateInputType
    _min?: RolesMinAggregateInputType
    _max?: RolesMaxAggregateInputType
  }

  export type RolesGroupByOutputType = {
    role_id: number
    name: string
    _count: RolesCountAggregateOutputType | null
    _avg: RolesAvgAggregateOutputType | null
    _sum: RolesSumAggregateOutputType | null
    _min: RolesMinAggregateOutputType | null
    _max: RolesMaxAggregateOutputType | null
  }

  type GetRolesGroupByPayload<T extends rolesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<RolesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof RolesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], RolesGroupByOutputType[P]>
            : GetScalarType<T[P], RolesGroupByOutputType[P]>
        }
      >
    >


  export type rolesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    role_id?: boolean
    name?: boolean
    role_permissions?: boolean | roles$role_permissionsArgs<ExtArgs>
    users?: boolean | roles$usersArgs<ExtArgs>
    _count?: boolean | RolesCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["roles"]>

  export type rolesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    role_id?: boolean
    name?: boolean
  }, ExtArgs["result"]["roles"]>

  export type rolesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    role_id?: boolean
    name?: boolean
  }, ExtArgs["result"]["roles"]>

  export type rolesSelectScalar = {
    role_id?: boolean
    name?: boolean
  }

  export type rolesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"role_id" | "name", ExtArgs["result"]["roles"]>
  export type rolesInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    role_permissions?: boolean | roles$role_permissionsArgs<ExtArgs>
    users?: boolean | roles$usersArgs<ExtArgs>
    _count?: boolean | RolesCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type rolesIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type rolesIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $rolesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "roles"
    objects: {
      role_permissions: Prisma.$role_permissionsPayload<ExtArgs>[]
      users: Prisma.$usersPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      role_id: number
      name: string
    }, ExtArgs["result"]["roles"]>
    composites: {}
  }

  type rolesGetPayload<S extends boolean | null | undefined | rolesDefaultArgs> = $Result.GetResult<Prisma.$rolesPayload, S>

  type rolesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<rolesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: RolesCountAggregateInputType | true
    }

  export interface rolesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['roles'], meta: { name: 'roles' } }
    /**
     * Find zero or one Roles that matches the filter.
     * @param {rolesFindUniqueArgs} args - Arguments to find a Roles
     * @example
     * // Get one Roles
     * const roles = await prisma.roles.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends rolesFindUniqueArgs>(args: SelectSubset<T, rolesFindUniqueArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Roles that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {rolesFindUniqueOrThrowArgs} args - Arguments to find a Roles
     * @example
     * // Get one Roles
     * const roles = await prisma.roles.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends rolesFindUniqueOrThrowArgs>(args: SelectSubset<T, rolesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Roles that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rolesFindFirstArgs} args - Arguments to find a Roles
     * @example
     * // Get one Roles
     * const roles = await prisma.roles.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends rolesFindFirstArgs>(args?: SelectSubset<T, rolesFindFirstArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Roles that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rolesFindFirstOrThrowArgs} args - Arguments to find a Roles
     * @example
     * // Get one Roles
     * const roles = await prisma.roles.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends rolesFindFirstOrThrowArgs>(args?: SelectSubset<T, rolesFindFirstOrThrowArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Roles that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rolesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Roles
     * const roles = await prisma.roles.findMany()
     * 
     * // Get first 10 Roles
     * const roles = await prisma.roles.findMany({ take: 10 })
     * 
     * // Only select the `role_id`
     * const rolesWithRole_idOnly = await prisma.roles.findMany({ select: { role_id: true } })
     * 
     */
    findMany<T extends rolesFindManyArgs>(args?: SelectSubset<T, rolesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Roles.
     * @param {rolesCreateArgs} args - Arguments to create a Roles.
     * @example
     * // Create one Roles
     * const Roles = await prisma.roles.create({
     *   data: {
     *     // ... data to create a Roles
     *   }
     * })
     * 
     */
    create<T extends rolesCreateArgs>(args: SelectSubset<T, rolesCreateArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Roles.
     * @param {rolesCreateManyArgs} args - Arguments to create many Roles.
     * @example
     * // Create many Roles
     * const roles = await prisma.roles.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends rolesCreateManyArgs>(args?: SelectSubset<T, rolesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Roles and returns the data saved in the database.
     * @param {rolesCreateManyAndReturnArgs} args - Arguments to create many Roles.
     * @example
     * // Create many Roles
     * const roles = await prisma.roles.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Roles and only return the `role_id`
     * const rolesWithRole_idOnly = await prisma.roles.createManyAndReturn({
     *   select: { role_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends rolesCreateManyAndReturnArgs>(args?: SelectSubset<T, rolesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Roles.
     * @param {rolesDeleteArgs} args - Arguments to delete one Roles.
     * @example
     * // Delete one Roles
     * const Roles = await prisma.roles.delete({
     *   where: {
     *     // ... filter to delete one Roles
     *   }
     * })
     * 
     */
    delete<T extends rolesDeleteArgs>(args: SelectSubset<T, rolesDeleteArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Roles.
     * @param {rolesUpdateArgs} args - Arguments to update one Roles.
     * @example
     * // Update one Roles
     * const roles = await prisma.roles.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends rolesUpdateArgs>(args: SelectSubset<T, rolesUpdateArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Roles.
     * @param {rolesDeleteManyArgs} args - Arguments to filter Roles to delete.
     * @example
     * // Delete a few Roles
     * const { count } = await prisma.roles.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends rolesDeleteManyArgs>(args?: SelectSubset<T, rolesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Roles.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rolesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Roles
     * const roles = await prisma.roles.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends rolesUpdateManyArgs>(args: SelectSubset<T, rolesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Roles and returns the data updated in the database.
     * @param {rolesUpdateManyAndReturnArgs} args - Arguments to update many Roles.
     * @example
     * // Update many Roles
     * const roles = await prisma.roles.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Roles and only return the `role_id`
     * const rolesWithRole_idOnly = await prisma.roles.updateManyAndReturn({
     *   select: { role_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends rolesUpdateManyAndReturnArgs>(args: SelectSubset<T, rolesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Roles.
     * @param {rolesUpsertArgs} args - Arguments to update or create a Roles.
     * @example
     * // Update or create a Roles
     * const roles = await prisma.roles.upsert({
     *   create: {
     *     // ... data to create a Roles
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Roles we want to update
     *   }
     * })
     */
    upsert<T extends rolesUpsertArgs>(args: SelectSubset<T, rolesUpsertArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Roles.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rolesCountArgs} args - Arguments to filter Roles to count.
     * @example
     * // Count the number of Roles
     * const count = await prisma.roles.count({
     *   where: {
     *     // ... the filter for the Roles we want to count
     *   }
     * })
    **/
    count<T extends rolesCountArgs>(
      args?: Subset<T, rolesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], RolesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Roles.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RolesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends RolesAggregateArgs>(args: Subset<T, RolesAggregateArgs>): Prisma.PrismaPromise<GetRolesAggregateType<T>>

    /**
     * Group by Roles.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rolesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends rolesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: rolesGroupByArgs['orderBy'] }
        : { orderBy?: rolesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, rolesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRolesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the roles model
   */
  readonly fields: rolesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for roles.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__rolesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    role_permissions<T extends roles$role_permissionsArgs<ExtArgs> = {}>(args?: Subset<T, roles$role_permissionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$role_permissionsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    users<T extends roles$usersArgs<ExtArgs> = {}>(args?: Subset<T, roles$usersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the roles model
   */
  interface rolesFieldRefs {
    readonly role_id: FieldRef<"roles", 'Int'>
    readonly name: FieldRef<"roles", 'String'>
  }
    

  // Custom InputTypes
  /**
   * roles findUnique
   */
  export type rolesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * Filter, which roles to fetch.
     */
    where: rolesWhereUniqueInput
  }

  /**
   * roles findUniqueOrThrow
   */
  export type rolesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * Filter, which roles to fetch.
     */
    where: rolesWhereUniqueInput
  }

  /**
   * roles findFirst
   */
  export type rolesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * Filter, which roles to fetch.
     */
    where?: rolesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of roles to fetch.
     */
    orderBy?: rolesOrderByWithRelationInput | rolesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for roles.
     */
    cursor?: rolesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` roles from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` roles.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of roles.
     */
    distinct?: RolesScalarFieldEnum | RolesScalarFieldEnum[]
  }

  /**
   * roles findFirstOrThrow
   */
  export type rolesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * Filter, which roles to fetch.
     */
    where?: rolesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of roles to fetch.
     */
    orderBy?: rolesOrderByWithRelationInput | rolesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for roles.
     */
    cursor?: rolesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` roles from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` roles.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of roles.
     */
    distinct?: RolesScalarFieldEnum | RolesScalarFieldEnum[]
  }

  /**
   * roles findMany
   */
  export type rolesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * Filter, which roles to fetch.
     */
    where?: rolesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of roles to fetch.
     */
    orderBy?: rolesOrderByWithRelationInput | rolesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing roles.
     */
    cursor?: rolesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` roles from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` roles.
     */
    skip?: number
    distinct?: RolesScalarFieldEnum | RolesScalarFieldEnum[]
  }

  /**
   * roles create
   */
  export type rolesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * The data needed to create a roles.
     */
    data: XOR<rolesCreateInput, rolesUncheckedCreateInput>
  }

  /**
   * roles createMany
   */
  export type rolesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many roles.
     */
    data: rolesCreateManyInput | rolesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * roles createManyAndReturn
   */
  export type rolesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * The data used to create many roles.
     */
    data: rolesCreateManyInput | rolesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * roles update
   */
  export type rolesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * The data needed to update a roles.
     */
    data: XOR<rolesUpdateInput, rolesUncheckedUpdateInput>
    /**
     * Choose, which roles to update.
     */
    where: rolesWhereUniqueInput
  }

  /**
   * roles updateMany
   */
  export type rolesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update roles.
     */
    data: XOR<rolesUpdateManyMutationInput, rolesUncheckedUpdateManyInput>
    /**
     * Filter which roles to update
     */
    where?: rolesWhereInput
    /**
     * Limit how many roles to update.
     */
    limit?: number
  }

  /**
   * roles updateManyAndReturn
   */
  export type rolesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * The data used to update roles.
     */
    data: XOR<rolesUpdateManyMutationInput, rolesUncheckedUpdateManyInput>
    /**
     * Filter which roles to update
     */
    where?: rolesWhereInput
    /**
     * Limit how many roles to update.
     */
    limit?: number
  }

  /**
   * roles upsert
   */
  export type rolesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * The filter to search for the roles to update in case it exists.
     */
    where: rolesWhereUniqueInput
    /**
     * In case the roles found by the `where` argument doesn't exist, create a new roles with this data.
     */
    create: XOR<rolesCreateInput, rolesUncheckedCreateInput>
    /**
     * In case the roles was found with the provided `where` argument, update it with this data.
     */
    update: XOR<rolesUpdateInput, rolesUncheckedUpdateInput>
  }

  /**
   * roles delete
   */
  export type rolesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
    /**
     * Filter which roles to delete.
     */
    where: rolesWhereUniqueInput
  }

  /**
   * roles deleteMany
   */
  export type rolesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which roles to delete
     */
    where?: rolesWhereInput
    /**
     * Limit how many roles to delete.
     */
    limit?: number
  }

  /**
   * roles.role_permissions
   */
  export type roles$role_permissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the role_permissions
     */
    select?: role_permissionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the role_permissions
     */
    omit?: role_permissionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: role_permissionsInclude<ExtArgs> | null
    where?: role_permissionsWhereInput
    orderBy?: role_permissionsOrderByWithRelationInput | role_permissionsOrderByWithRelationInput[]
    cursor?: role_permissionsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Role_permissionsScalarFieldEnum | Role_permissionsScalarFieldEnum[]
  }

  /**
   * roles.users
   */
  export type roles$usersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    where?: usersWhereInput
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    cursor?: usersWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * roles without action
   */
  export type rolesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the roles
     */
    select?: rolesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the roles
     */
    omit?: rolesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: rolesInclude<ExtArgs> | null
  }


  /**
   * Model telemetry
   */

  export type AggregateTelemetry = {
    _count: TelemetryCountAggregateOutputType | null
    _avg: TelemetryAvgAggregateOutputType | null
    _sum: TelemetrySumAggregateOutputType | null
    _min: TelemetryMinAggregateOutputType | null
    _max: TelemetryMaxAggregateOutputType | null
  }

  export type TelemetryAvgAggregateOutputType = {
    id: number | null
    device_id: number | null
    asset_id: number | null
    organisation_id: number | null
  }

  export type TelemetrySumAggregateOutputType = {
    id: bigint | null
    device_id: bigint | null
    asset_id: bigint | null
    organisation_id: bigint | null
  }

  export type TelemetryMinAggregateOutputType = {
    id: bigint | null
    device_id: bigint | null
    asset_id: bigint | null
    organisation_id: bigint | null
    happened_at: Date | null
    protocol: string | null
    vendor: string | null
    model: string | null
    created_at: Date | null
  }

  export type TelemetryMaxAggregateOutputType = {
    id: bigint | null
    device_id: bigint | null
    asset_id: bigint | null
    organisation_id: bigint | null
    happened_at: Date | null
    protocol: string | null
    vendor: string | null
    model: string | null
    created_at: Date | null
  }

  export type TelemetryCountAggregateOutputType = {
    id: number
    device_id: number
    asset_id: number
    organisation_id: number
    happened_at: number
    protocol: number
    vendor: number
    model: number
    telemetry: number
    created_at: number
    _all: number
  }


  export type TelemetryAvgAggregateInputType = {
    id?: true
    device_id?: true
    asset_id?: true
    organisation_id?: true
  }

  export type TelemetrySumAggregateInputType = {
    id?: true
    device_id?: true
    asset_id?: true
    organisation_id?: true
  }

  export type TelemetryMinAggregateInputType = {
    id?: true
    device_id?: true
    asset_id?: true
    organisation_id?: true
    happened_at?: true
    protocol?: true
    vendor?: true
    model?: true
    created_at?: true
  }

  export type TelemetryMaxAggregateInputType = {
    id?: true
    device_id?: true
    asset_id?: true
    organisation_id?: true
    happened_at?: true
    protocol?: true
    vendor?: true
    model?: true
    created_at?: true
  }

  export type TelemetryCountAggregateInputType = {
    id?: true
    device_id?: true
    asset_id?: true
    organisation_id?: true
    happened_at?: true
    protocol?: true
    vendor?: true
    model?: true
    telemetry?: true
    created_at?: true
    _all?: true
  }

  export type TelemetryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which telemetry to aggregate.
     */
    where?: telemetryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of telemetries to fetch.
     */
    orderBy?: telemetryOrderByWithRelationInput | telemetryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: telemetryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` telemetries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` telemetries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned telemetries
    **/
    _count?: true | TelemetryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TelemetryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TelemetrySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TelemetryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TelemetryMaxAggregateInputType
  }

  export type GetTelemetryAggregateType<T extends TelemetryAggregateArgs> = {
        [P in keyof T & keyof AggregateTelemetry]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTelemetry[P]>
      : GetScalarType<T[P], AggregateTelemetry[P]>
  }




  export type telemetryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: telemetryWhereInput
    orderBy?: telemetryOrderByWithAggregationInput | telemetryOrderByWithAggregationInput[]
    by: TelemetryScalarFieldEnum[] | TelemetryScalarFieldEnum
    having?: telemetryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TelemetryCountAggregateInputType | true
    _avg?: TelemetryAvgAggregateInputType
    _sum?: TelemetrySumAggregateInputType
    _min?: TelemetryMinAggregateInputType
    _max?: TelemetryMaxAggregateInputType
  }

  export type TelemetryGroupByOutputType = {
    id: bigint
    device_id: bigint
    asset_id: bigint | null
    organisation_id: bigint | null
    happened_at: Date
    protocol: string
    vendor: string | null
    model: string | null
    telemetry: JsonValue
    created_at: Date
    _count: TelemetryCountAggregateOutputType | null
    _avg: TelemetryAvgAggregateOutputType | null
    _sum: TelemetrySumAggregateOutputType | null
    _min: TelemetryMinAggregateOutputType | null
    _max: TelemetryMaxAggregateOutputType | null
  }

  type GetTelemetryGroupByPayload<T extends telemetryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TelemetryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TelemetryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TelemetryGroupByOutputType[P]>
            : GetScalarType<T[P], TelemetryGroupByOutputType[P]>
        }
      >
    >


  export type telemetrySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    device_id?: boolean
    asset_id?: boolean
    organisation_id?: boolean
    happened_at?: boolean
    protocol?: boolean
    vendor?: boolean
    model?: boolean
    telemetry?: boolean
    created_at?: boolean
  }, ExtArgs["result"]["telemetry"]>

  export type telemetrySelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    device_id?: boolean
    asset_id?: boolean
    organisation_id?: boolean
    happened_at?: boolean
    protocol?: boolean
    vendor?: boolean
    model?: boolean
    telemetry?: boolean
    created_at?: boolean
  }, ExtArgs["result"]["telemetry"]>

  export type telemetrySelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    device_id?: boolean
    asset_id?: boolean
    organisation_id?: boolean
    happened_at?: boolean
    protocol?: boolean
    vendor?: boolean
    model?: boolean
    telemetry?: boolean
    created_at?: boolean
  }, ExtArgs["result"]["telemetry"]>

  export type telemetrySelectScalar = {
    id?: boolean
    device_id?: boolean
    asset_id?: boolean
    organisation_id?: boolean
    happened_at?: boolean
    protocol?: boolean
    vendor?: boolean
    model?: boolean
    telemetry?: boolean
    created_at?: boolean
  }

  export type telemetryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "device_id" | "asset_id" | "organisation_id" | "happened_at" | "protocol" | "vendor" | "model" | "telemetry" | "created_at", ExtArgs["result"]["telemetry"]>

  export type $telemetryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "telemetry"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      device_id: bigint
      asset_id: bigint | null
      organisation_id: bigint | null
      happened_at: Date
      protocol: string
      vendor: string | null
      model: string | null
      telemetry: Prisma.JsonValue
      created_at: Date
    }, ExtArgs["result"]["telemetry"]>
    composites: {}
  }

  type telemetryGetPayload<S extends boolean | null | undefined | telemetryDefaultArgs> = $Result.GetResult<Prisma.$telemetryPayload, S>

  type telemetryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<telemetryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TelemetryCountAggregateInputType | true
    }

  export interface telemetryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['telemetry'], meta: { name: 'telemetry' } }
    /**
     * Find zero or one Telemetry that matches the filter.
     * @param {telemetryFindUniqueArgs} args - Arguments to find a Telemetry
     * @example
     * // Get one Telemetry
     * const telemetry = await prisma.telemetry.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends telemetryFindUniqueArgs>(args: SelectSubset<T, telemetryFindUniqueArgs<ExtArgs>>): Prisma__telemetryClient<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Telemetry that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {telemetryFindUniqueOrThrowArgs} args - Arguments to find a Telemetry
     * @example
     * // Get one Telemetry
     * const telemetry = await prisma.telemetry.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends telemetryFindUniqueOrThrowArgs>(args: SelectSubset<T, telemetryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__telemetryClient<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Telemetry that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {telemetryFindFirstArgs} args - Arguments to find a Telemetry
     * @example
     * // Get one Telemetry
     * const telemetry = await prisma.telemetry.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends telemetryFindFirstArgs>(args?: SelectSubset<T, telemetryFindFirstArgs<ExtArgs>>): Prisma__telemetryClient<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Telemetry that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {telemetryFindFirstOrThrowArgs} args - Arguments to find a Telemetry
     * @example
     * // Get one Telemetry
     * const telemetry = await prisma.telemetry.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends telemetryFindFirstOrThrowArgs>(args?: SelectSubset<T, telemetryFindFirstOrThrowArgs<ExtArgs>>): Prisma__telemetryClient<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Telemetries that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {telemetryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Telemetries
     * const telemetries = await prisma.telemetry.findMany()
     * 
     * // Get first 10 Telemetries
     * const telemetries = await prisma.telemetry.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const telemetryWithIdOnly = await prisma.telemetry.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends telemetryFindManyArgs>(args?: SelectSubset<T, telemetryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Telemetry.
     * @param {telemetryCreateArgs} args - Arguments to create a Telemetry.
     * @example
     * // Create one Telemetry
     * const Telemetry = await prisma.telemetry.create({
     *   data: {
     *     // ... data to create a Telemetry
     *   }
     * })
     * 
     */
    create<T extends telemetryCreateArgs>(args: SelectSubset<T, telemetryCreateArgs<ExtArgs>>): Prisma__telemetryClient<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Telemetries.
     * @param {telemetryCreateManyArgs} args - Arguments to create many Telemetries.
     * @example
     * // Create many Telemetries
     * const telemetry = await prisma.telemetry.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends telemetryCreateManyArgs>(args?: SelectSubset<T, telemetryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Telemetries and returns the data saved in the database.
     * @param {telemetryCreateManyAndReturnArgs} args - Arguments to create many Telemetries.
     * @example
     * // Create many Telemetries
     * const telemetry = await prisma.telemetry.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Telemetries and only return the `id`
     * const telemetryWithIdOnly = await prisma.telemetry.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends telemetryCreateManyAndReturnArgs>(args?: SelectSubset<T, telemetryCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Telemetry.
     * @param {telemetryDeleteArgs} args - Arguments to delete one Telemetry.
     * @example
     * // Delete one Telemetry
     * const Telemetry = await prisma.telemetry.delete({
     *   where: {
     *     // ... filter to delete one Telemetry
     *   }
     * })
     * 
     */
    delete<T extends telemetryDeleteArgs>(args: SelectSubset<T, telemetryDeleteArgs<ExtArgs>>): Prisma__telemetryClient<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Telemetry.
     * @param {telemetryUpdateArgs} args - Arguments to update one Telemetry.
     * @example
     * // Update one Telemetry
     * const telemetry = await prisma.telemetry.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends telemetryUpdateArgs>(args: SelectSubset<T, telemetryUpdateArgs<ExtArgs>>): Prisma__telemetryClient<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Telemetries.
     * @param {telemetryDeleteManyArgs} args - Arguments to filter Telemetries to delete.
     * @example
     * // Delete a few Telemetries
     * const { count } = await prisma.telemetry.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends telemetryDeleteManyArgs>(args?: SelectSubset<T, telemetryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Telemetries.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {telemetryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Telemetries
     * const telemetry = await prisma.telemetry.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends telemetryUpdateManyArgs>(args: SelectSubset<T, telemetryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Telemetries and returns the data updated in the database.
     * @param {telemetryUpdateManyAndReturnArgs} args - Arguments to update many Telemetries.
     * @example
     * // Update many Telemetries
     * const telemetry = await prisma.telemetry.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Telemetries and only return the `id`
     * const telemetryWithIdOnly = await prisma.telemetry.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends telemetryUpdateManyAndReturnArgs>(args: SelectSubset<T, telemetryUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Telemetry.
     * @param {telemetryUpsertArgs} args - Arguments to update or create a Telemetry.
     * @example
     * // Update or create a Telemetry
     * const telemetry = await prisma.telemetry.upsert({
     *   create: {
     *     // ... data to create a Telemetry
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Telemetry we want to update
     *   }
     * })
     */
    upsert<T extends telemetryUpsertArgs>(args: SelectSubset<T, telemetryUpsertArgs<ExtArgs>>): Prisma__telemetryClient<$Result.GetResult<Prisma.$telemetryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Telemetries.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {telemetryCountArgs} args - Arguments to filter Telemetries to count.
     * @example
     * // Count the number of Telemetries
     * const count = await prisma.telemetry.count({
     *   where: {
     *     // ... the filter for the Telemetries we want to count
     *   }
     * })
    **/
    count<T extends telemetryCountArgs>(
      args?: Subset<T, telemetryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TelemetryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Telemetry.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TelemetryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TelemetryAggregateArgs>(args: Subset<T, TelemetryAggregateArgs>): Prisma.PrismaPromise<GetTelemetryAggregateType<T>>

    /**
     * Group by Telemetry.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {telemetryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends telemetryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: telemetryGroupByArgs['orderBy'] }
        : { orderBy?: telemetryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, telemetryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTelemetryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the telemetry model
   */
  readonly fields: telemetryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for telemetry.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__telemetryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the telemetry model
   */
  interface telemetryFieldRefs {
    readonly id: FieldRef<"telemetry", 'BigInt'>
    readonly device_id: FieldRef<"telemetry", 'BigInt'>
    readonly asset_id: FieldRef<"telemetry", 'BigInt'>
    readonly organisation_id: FieldRef<"telemetry", 'BigInt'>
    readonly happened_at: FieldRef<"telemetry", 'DateTime'>
    readonly protocol: FieldRef<"telemetry", 'String'>
    readonly vendor: FieldRef<"telemetry", 'String'>
    readonly model: FieldRef<"telemetry", 'String'>
    readonly telemetry: FieldRef<"telemetry", 'Json'>
    readonly created_at: FieldRef<"telemetry", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * telemetry findUnique
   */
  export type telemetryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * Filter, which telemetry to fetch.
     */
    where: telemetryWhereUniqueInput
  }

  /**
   * telemetry findUniqueOrThrow
   */
  export type telemetryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * Filter, which telemetry to fetch.
     */
    where: telemetryWhereUniqueInput
  }

  /**
   * telemetry findFirst
   */
  export type telemetryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * Filter, which telemetry to fetch.
     */
    where?: telemetryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of telemetries to fetch.
     */
    orderBy?: telemetryOrderByWithRelationInput | telemetryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for telemetries.
     */
    cursor?: telemetryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` telemetries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` telemetries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of telemetries.
     */
    distinct?: TelemetryScalarFieldEnum | TelemetryScalarFieldEnum[]
  }

  /**
   * telemetry findFirstOrThrow
   */
  export type telemetryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * Filter, which telemetry to fetch.
     */
    where?: telemetryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of telemetries to fetch.
     */
    orderBy?: telemetryOrderByWithRelationInput | telemetryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for telemetries.
     */
    cursor?: telemetryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` telemetries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` telemetries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of telemetries.
     */
    distinct?: TelemetryScalarFieldEnum | TelemetryScalarFieldEnum[]
  }

  /**
   * telemetry findMany
   */
  export type telemetryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * Filter, which telemetries to fetch.
     */
    where?: telemetryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of telemetries to fetch.
     */
    orderBy?: telemetryOrderByWithRelationInput | telemetryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing telemetries.
     */
    cursor?: telemetryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` telemetries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` telemetries.
     */
    skip?: number
    distinct?: TelemetryScalarFieldEnum | TelemetryScalarFieldEnum[]
  }

  /**
   * telemetry create
   */
  export type telemetryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * The data needed to create a telemetry.
     */
    data: XOR<telemetryCreateInput, telemetryUncheckedCreateInput>
  }

  /**
   * telemetry createMany
   */
  export type telemetryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many telemetries.
     */
    data: telemetryCreateManyInput | telemetryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * telemetry createManyAndReturn
   */
  export type telemetryCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * The data used to create many telemetries.
     */
    data: telemetryCreateManyInput | telemetryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * telemetry update
   */
  export type telemetryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * The data needed to update a telemetry.
     */
    data: XOR<telemetryUpdateInput, telemetryUncheckedUpdateInput>
    /**
     * Choose, which telemetry to update.
     */
    where: telemetryWhereUniqueInput
  }

  /**
   * telemetry updateMany
   */
  export type telemetryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update telemetries.
     */
    data: XOR<telemetryUpdateManyMutationInput, telemetryUncheckedUpdateManyInput>
    /**
     * Filter which telemetries to update
     */
    where?: telemetryWhereInput
    /**
     * Limit how many telemetries to update.
     */
    limit?: number
  }

  /**
   * telemetry updateManyAndReturn
   */
  export type telemetryUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * The data used to update telemetries.
     */
    data: XOR<telemetryUpdateManyMutationInput, telemetryUncheckedUpdateManyInput>
    /**
     * Filter which telemetries to update
     */
    where?: telemetryWhereInput
    /**
     * Limit how many telemetries to update.
     */
    limit?: number
  }

  /**
   * telemetry upsert
   */
  export type telemetryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * The filter to search for the telemetry to update in case it exists.
     */
    where: telemetryWhereUniqueInput
    /**
     * In case the telemetry found by the `where` argument doesn't exist, create a new telemetry with this data.
     */
    create: XOR<telemetryCreateInput, telemetryUncheckedCreateInput>
    /**
     * In case the telemetry was found with the provided `where` argument, update it with this data.
     */
    update: XOR<telemetryUpdateInput, telemetryUncheckedUpdateInput>
  }

  /**
   * telemetry delete
   */
  export type telemetryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
    /**
     * Filter which telemetry to delete.
     */
    where: telemetryWhereUniqueInput
  }

  /**
   * telemetry deleteMany
   */
  export type telemetryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which telemetries to delete
     */
    where?: telemetryWhereInput
    /**
     * Limit how many telemetries to delete.
     */
    limit?: number
  }

  /**
   * telemetry without action
   */
  export type telemetryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the telemetry
     */
    select?: telemetrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the telemetry
     */
    omit?: telemetryOmit<ExtArgs> | null
  }


  /**
   * Model users
   */

  export type AggregateUsers = {
    _count: UsersCountAggregateOutputType | null
    _avg: UsersAvgAggregateOutputType | null
    _sum: UsersSumAggregateOutputType | null
    _min: UsersMinAggregateOutputType | null
    _max: UsersMaxAggregateOutputType | null
  }

  export type UsersAvgAggregateOutputType = {
    id: number | null
    role_id: number | null
    organisation_id: number | null
    token_version: number | null
  }

  export type UsersSumAggregateOutputType = {
    id: bigint | null
    role_id: number | null
    organisation_id: bigint | null
    token_version: number | null
  }

  export type UsersMinAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    first_name: string | null
    last_name: string | null
    email: string | null
    password_hash: string | null
    role_id: number | null
    organisation_id: bigint | null
    active: boolean | null
    last_login_at: Date | null
    created_at: Date | null
    updated_at: Date | null
    token_version: number | null
  }

  export type UsersMaxAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    first_name: string | null
    last_name: string | null
    email: string | null
    password_hash: string | null
    role_id: number | null
    organisation_id: bigint | null
    active: boolean | null
    last_login_at: Date | null
    created_at: Date | null
    updated_at: Date | null
    token_version: number | null
  }

  export type UsersCountAggregateOutputType = {
    id: number
    uuid: number
    first_name: number
    last_name: number
    email: number
    password_hash: number
    role_id: number
    organisation_id: number
    active: number
    last_login_at: number
    created_at: number
    updated_at: number
    token_version: number
    _all: number
  }


  export type UsersAvgAggregateInputType = {
    id?: true
    role_id?: true
    organisation_id?: true
    token_version?: true
  }

  export type UsersSumAggregateInputType = {
    id?: true
    role_id?: true
    organisation_id?: true
    token_version?: true
  }

  export type UsersMinAggregateInputType = {
    id?: true
    uuid?: true
    first_name?: true
    last_name?: true
    email?: true
    password_hash?: true
    role_id?: true
    organisation_id?: true
    active?: true
    last_login_at?: true
    created_at?: true
    updated_at?: true
    token_version?: true
  }

  export type UsersMaxAggregateInputType = {
    id?: true
    uuid?: true
    first_name?: true
    last_name?: true
    email?: true
    password_hash?: true
    role_id?: true
    organisation_id?: true
    active?: true
    last_login_at?: true
    created_at?: true
    updated_at?: true
    token_version?: true
  }

  export type UsersCountAggregateInputType = {
    id?: true
    uuid?: true
    first_name?: true
    last_name?: true
    email?: true
    password_hash?: true
    role_id?: true
    organisation_id?: true
    active?: true
    last_login_at?: true
    created_at?: true
    updated_at?: true
    token_version?: true
    _all?: true
  }

  export type UsersAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which users to aggregate.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned users
    **/
    _count?: true | UsersCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UsersAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UsersSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UsersMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UsersMaxAggregateInputType
  }

  export type GetUsersAggregateType<T extends UsersAggregateArgs> = {
        [P in keyof T & keyof AggregateUsers]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsers[P]>
      : GetScalarType<T[P], AggregateUsers[P]>
  }




  export type usersGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usersWhereInput
    orderBy?: usersOrderByWithAggregationInput | usersOrderByWithAggregationInput[]
    by: UsersScalarFieldEnum[] | UsersScalarFieldEnum
    having?: usersScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UsersCountAggregateInputType | true
    _avg?: UsersAvgAggregateInputType
    _sum?: UsersSumAggregateInputType
    _min?: UsersMinAggregateInputType
    _max?: UsersMaxAggregateInputType
  }

  export type UsersGroupByOutputType = {
    id: bigint
    uuid: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    role_id: number
    organisation_id: bigint
    active: boolean
    last_login_at: Date | null
    created_at: Date
    updated_at: Date
    token_version: number
    _count: UsersCountAggregateOutputType | null
    _avg: UsersAvgAggregateOutputType | null
    _sum: UsersSumAggregateOutputType | null
    _min: UsersMinAggregateOutputType | null
    _max: UsersMaxAggregateOutputType | null
  }

  type GetUsersGroupByPayload<T extends usersGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UsersGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UsersGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UsersGroupByOutputType[P]>
            : GetScalarType<T[P], UsersGroupByOutputType[P]>
        }
      >
    >


  export type usersSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    first_name?: boolean
    last_name?: boolean
    email?: boolean
    password_hash?: boolean
    role_id?: boolean
    organisation_id?: boolean
    active?: boolean
    last_login_at?: boolean
    created_at?: boolean
    updated_at?: boolean
    token_version?: boolean
    user_asset_access?: boolean | users$user_asset_accessArgs<ExtArgs>
    user_device_access?: boolean | users$user_device_accessArgs<ExtArgs>
    user_organisation_access?: boolean | users$user_organisation_accessArgs<ExtArgs>
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
    _count?: boolean | UsersCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["users"]>

  export type usersSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    first_name?: boolean
    last_name?: boolean
    email?: boolean
    password_hash?: boolean
    role_id?: boolean
    organisation_id?: boolean
    active?: boolean
    last_login_at?: boolean
    created_at?: boolean
    updated_at?: boolean
    token_version?: boolean
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["users"]>

  export type usersSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    first_name?: boolean
    last_name?: boolean
    email?: boolean
    password_hash?: boolean
    role_id?: boolean
    organisation_id?: boolean
    active?: boolean
    last_login_at?: boolean
    created_at?: boolean
    updated_at?: boolean
    token_version?: boolean
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["users"]>

  export type usersSelectScalar = {
    id?: boolean
    uuid?: boolean
    first_name?: boolean
    last_name?: boolean
    email?: boolean
    password_hash?: boolean
    role_id?: boolean
    organisation_id?: boolean
    active?: boolean
    last_login_at?: boolean
    created_at?: boolean
    updated_at?: boolean
    token_version?: boolean
  }

  export type usersOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "uuid" | "first_name" | "last_name" | "email" | "password_hash" | "role_id" | "organisation_id" | "active" | "last_login_at" | "created_at" | "updated_at" | "token_version", ExtArgs["result"]["users"]>
  export type usersInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user_asset_access?: boolean | users$user_asset_accessArgs<ExtArgs>
    user_device_access?: boolean | users$user_device_accessArgs<ExtArgs>
    user_organisation_access?: boolean | users$user_organisation_accessArgs<ExtArgs>
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
    _count?: boolean | UsersCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type usersIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }
  export type usersIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    roles?: boolean | rolesDefaultArgs<ExtArgs>
  }

  export type $usersPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "users"
    objects: {
      user_asset_access: Prisma.$user_asset_accessPayload<ExtArgs>[]
      user_device_access: Prisma.$user_device_accessPayload<ExtArgs>[]
      user_organisation_access: Prisma.$user_organisation_accessPayload<ExtArgs>[]
      organisations: Prisma.$organisationsPayload<ExtArgs>
      roles: Prisma.$rolesPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      uuid: string
      first_name: string
      last_name: string
      email: string
      password_hash: string
      role_id: number
      organisation_id: bigint
      active: boolean
      last_login_at: Date | null
      created_at: Date
      updated_at: Date
      token_version: number
    }, ExtArgs["result"]["users"]>
    composites: {}
  }

  type usersGetPayload<S extends boolean | null | undefined | usersDefaultArgs> = $Result.GetResult<Prisma.$usersPayload, S>

  type usersCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<usersFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UsersCountAggregateInputType | true
    }

  export interface usersDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['users'], meta: { name: 'users' } }
    /**
     * Find zero or one Users that matches the filter.
     * @param {usersFindUniqueArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends usersFindUniqueArgs>(args: SelectSubset<T, usersFindUniqueArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Users that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {usersFindUniqueOrThrowArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends usersFindUniqueOrThrowArgs>(args: SelectSubset<T, usersFindUniqueOrThrowArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindFirstArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends usersFindFirstArgs>(args?: SelectSubset<T, usersFindFirstArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Users that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindFirstOrThrowArgs} args - Arguments to find a Users
     * @example
     * // Get one Users
     * const users = await prisma.users.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends usersFindFirstOrThrowArgs>(args?: SelectSubset<T, usersFindFirstOrThrowArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.users.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.users.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const usersWithIdOnly = await prisma.users.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends usersFindManyArgs>(args?: SelectSubset<T, usersFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Users.
     * @param {usersCreateArgs} args - Arguments to create a Users.
     * @example
     * // Create one Users
     * const Users = await prisma.users.create({
     *   data: {
     *     // ... data to create a Users
     *   }
     * })
     * 
     */
    create<T extends usersCreateArgs>(args: SelectSubset<T, usersCreateArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {usersCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const users = await prisma.users.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends usersCreateManyArgs>(args?: SelectSubset<T, usersCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {usersCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const users = await prisma.users.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const usersWithIdOnly = await prisma.users.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends usersCreateManyAndReturnArgs>(args?: SelectSubset<T, usersCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Users.
     * @param {usersDeleteArgs} args - Arguments to delete one Users.
     * @example
     * // Delete one Users
     * const Users = await prisma.users.delete({
     *   where: {
     *     // ... filter to delete one Users
     *   }
     * })
     * 
     */
    delete<T extends usersDeleteArgs>(args: SelectSubset<T, usersDeleteArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Users.
     * @param {usersUpdateArgs} args - Arguments to update one Users.
     * @example
     * // Update one Users
     * const users = await prisma.users.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends usersUpdateArgs>(args: SelectSubset<T, usersUpdateArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {usersDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.users.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends usersDeleteManyArgs>(args?: SelectSubset<T, usersDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const users = await prisma.users.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends usersUpdateManyArgs>(args: SelectSubset<T, usersUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {usersUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const users = await prisma.users.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const usersWithIdOnly = await prisma.users.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends usersUpdateManyAndReturnArgs>(args: SelectSubset<T, usersUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Users.
     * @param {usersUpsertArgs} args - Arguments to update or create a Users.
     * @example
     * // Update or create a Users
     * const users = await prisma.users.upsert({
     *   create: {
     *     // ... data to create a Users
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Users we want to update
     *   }
     * })
     */
    upsert<T extends usersUpsertArgs>(args: SelectSubset<T, usersUpsertArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.users.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends usersCountArgs>(
      args?: Subset<T, usersCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UsersCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UsersAggregateArgs>(args: Subset<T, UsersAggregateArgs>): Prisma.PrismaPromise<GetUsersAggregateType<T>>

    /**
     * Group by Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usersGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends usersGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: usersGroupByArgs['orderBy'] }
        : { orderBy?: usersGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, usersGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsersGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the users model
   */
  readonly fields: usersFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for users.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__usersClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user_asset_access<T extends users$user_asset_accessArgs<ExtArgs> = {}>(args?: Subset<T, users$user_asset_accessArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    user_device_access<T extends users$user_device_accessArgs<ExtArgs> = {}>(args?: Subset<T, users$user_device_accessArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    user_organisation_access<T extends users$user_organisation_accessArgs<ExtArgs> = {}>(args?: Subset<T, users$user_organisation_accessArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    organisations<T extends organisationsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, organisationsDefaultArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    roles<T extends rolesDefaultArgs<ExtArgs> = {}>(args?: Subset<T, rolesDefaultArgs<ExtArgs>>): Prisma__rolesClient<$Result.GetResult<Prisma.$rolesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the users model
   */
  interface usersFieldRefs {
    readonly id: FieldRef<"users", 'BigInt'>
    readonly uuid: FieldRef<"users", 'String'>
    readonly first_name: FieldRef<"users", 'String'>
    readonly last_name: FieldRef<"users", 'String'>
    readonly email: FieldRef<"users", 'String'>
    readonly password_hash: FieldRef<"users", 'String'>
    readonly role_id: FieldRef<"users", 'Int'>
    readonly organisation_id: FieldRef<"users", 'BigInt'>
    readonly active: FieldRef<"users", 'Boolean'>
    readonly last_login_at: FieldRef<"users", 'DateTime'>
    readonly created_at: FieldRef<"users", 'DateTime'>
    readonly updated_at: FieldRef<"users", 'DateTime'>
    readonly token_version: FieldRef<"users", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * users findUnique
   */
  export type usersFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users findUniqueOrThrow
   */
  export type usersFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users findFirst
   */
  export type usersFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of users.
     */
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users findFirstOrThrow
   */
  export type usersFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of users.
     */
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users findMany
   */
  export type usersFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: usersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: usersOrderByWithRelationInput | usersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing users.
     */
    cursor?: usersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    distinct?: UsersScalarFieldEnum | UsersScalarFieldEnum[]
  }

  /**
   * users create
   */
  export type usersCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The data needed to create a users.
     */
    data: XOR<usersCreateInput, usersUncheckedCreateInput>
  }

  /**
   * users createMany
   */
  export type usersCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many users.
     */
    data: usersCreateManyInput | usersCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * users createManyAndReturn
   */
  export type usersCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * The data used to create many users.
     */
    data: usersCreateManyInput | usersCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * users update
   */
  export type usersUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The data needed to update a users.
     */
    data: XOR<usersUpdateInput, usersUncheckedUpdateInput>
    /**
     * Choose, which users to update.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users updateMany
   */
  export type usersUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update users.
     */
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyInput>
    /**
     * Filter which users to update
     */
    where?: usersWhereInput
    /**
     * Limit how many users to update.
     */
    limit?: number
  }

  /**
   * users updateManyAndReturn
   */
  export type usersUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * The data used to update users.
     */
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyInput>
    /**
     * Filter which users to update
     */
    where?: usersWhereInput
    /**
     * Limit how many users to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * users upsert
   */
  export type usersUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * The filter to search for the users to update in case it exists.
     */
    where: usersWhereUniqueInput
    /**
     * In case the users found by the `where` argument doesn't exist, create a new users with this data.
     */
    create: XOR<usersCreateInput, usersUncheckedCreateInput>
    /**
     * In case the users was found with the provided `where` argument, update it with this data.
     */
    update: XOR<usersUpdateInput, usersUncheckedUpdateInput>
  }

  /**
   * users delete
   */
  export type usersDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
    /**
     * Filter which users to delete.
     */
    where: usersWhereUniqueInput
  }

  /**
   * users deleteMany
   */
  export type usersDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which users to delete
     */
    where?: usersWhereInput
    /**
     * Limit how many users to delete.
     */
    limit?: number
  }

  /**
   * users.user_asset_access
   */
  export type users$user_asset_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    where?: user_asset_accessWhereInput
    orderBy?: user_asset_accessOrderByWithRelationInput | user_asset_accessOrderByWithRelationInput[]
    cursor?: user_asset_accessWhereUniqueInput
    take?: number
    skip?: number
    distinct?: User_asset_accessScalarFieldEnum | User_asset_accessScalarFieldEnum[]
  }

  /**
   * users.user_device_access
   */
  export type users$user_device_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    where?: user_device_accessWhereInput
    orderBy?: user_device_accessOrderByWithRelationInput | user_device_accessOrderByWithRelationInput[]
    cursor?: user_device_accessWhereUniqueInput
    take?: number
    skip?: number
    distinct?: User_device_accessScalarFieldEnum | User_device_accessScalarFieldEnum[]
  }

  /**
   * users.user_organisation_access
   */
  export type users$user_organisation_accessArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    where?: user_organisation_accessWhereInput
    orderBy?: user_organisation_accessOrderByWithRelationInput | user_organisation_accessOrderByWithRelationInput[]
    cursor?: user_organisation_accessWhereUniqueInput
    take?: number
    skip?: number
    distinct?: User_organisation_accessScalarFieldEnum | User_organisation_accessScalarFieldEnum[]
  }

  /**
   * users without action
   */
  export type usersDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the users
     */
    select?: usersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the users
     */
    omit?: usersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usersInclude<ExtArgs> | null
  }


  /**
   * Model codec12_commands
   */

  export type AggregateCodec12_commands = {
    _count: Codec12_commandsCountAggregateOutputType | null
    _avg: Codec12_commandsAvgAggregateOutputType | null
    _sum: Codec12_commandsSumAggregateOutputType | null
    _min: Codec12_commandsMinAggregateOutputType | null
    _max: Codec12_commandsMaxAggregateOutputType | null
  }

  export type Codec12_commandsAvgAggregateOutputType = {
    id: number | null
    retries: number | null
  }

  export type Codec12_commandsSumAggregateOutputType = {
    id: bigint | null
    retries: number | null
  }

  export type Codec12_commandsMinAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    imei: string | null
    command: string | null
    status: string | null
    created_at: Date | null
    updated_at: Date | null
    sent_at: Date | null
    responded_at: Date | null
    response: string | null
    retries: number | null
    comment: string | null
  }

  export type Codec12_commandsMaxAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    imei: string | null
    command: string | null
    status: string | null
    created_at: Date | null
    updated_at: Date | null
    sent_at: Date | null
    responded_at: Date | null
    response: string | null
    retries: number | null
    comment: string | null
  }

  export type Codec12_commandsCountAggregateOutputType = {
    id: number
    uuid: number
    imei: number
    command: number
    status: number
    created_at: number
    updated_at: number
    sent_at: number
    responded_at: number
    response: number
    retries: number
    comment: number
    _all: number
  }


  export type Codec12_commandsAvgAggregateInputType = {
    id?: true
    retries?: true
  }

  export type Codec12_commandsSumAggregateInputType = {
    id?: true
    retries?: true
  }

  export type Codec12_commandsMinAggregateInputType = {
    id?: true
    uuid?: true
    imei?: true
    command?: true
    status?: true
    created_at?: true
    updated_at?: true
    sent_at?: true
    responded_at?: true
    response?: true
    retries?: true
    comment?: true
  }

  export type Codec12_commandsMaxAggregateInputType = {
    id?: true
    uuid?: true
    imei?: true
    command?: true
    status?: true
    created_at?: true
    updated_at?: true
    sent_at?: true
    responded_at?: true
    response?: true
    retries?: true
    comment?: true
  }

  export type Codec12_commandsCountAggregateInputType = {
    id?: true
    uuid?: true
    imei?: true
    command?: true
    status?: true
    created_at?: true
    updated_at?: true
    sent_at?: true
    responded_at?: true
    response?: true
    retries?: true
    comment?: true
    _all?: true
  }

  export type Codec12_commandsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which codec12_commands to aggregate.
     */
    where?: codec12_commandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of codec12_commands to fetch.
     */
    orderBy?: codec12_commandsOrderByWithRelationInput | codec12_commandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: codec12_commandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` codec12_commands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` codec12_commands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned codec12_commands
    **/
    _count?: true | Codec12_commandsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Codec12_commandsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Codec12_commandsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Codec12_commandsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Codec12_commandsMaxAggregateInputType
  }

  export type GetCodec12_commandsAggregateType<T extends Codec12_commandsAggregateArgs> = {
        [P in keyof T & keyof AggregateCodec12_commands]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCodec12_commands[P]>
      : GetScalarType<T[P], AggregateCodec12_commands[P]>
  }




  export type codec12_commandsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: codec12_commandsWhereInput
    orderBy?: codec12_commandsOrderByWithAggregationInput | codec12_commandsOrderByWithAggregationInput[]
    by: Codec12_commandsScalarFieldEnum[] | Codec12_commandsScalarFieldEnum
    having?: codec12_commandsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Codec12_commandsCountAggregateInputType | true
    _avg?: Codec12_commandsAvgAggregateInputType
    _sum?: Codec12_commandsSumAggregateInputType
    _min?: Codec12_commandsMinAggregateInputType
    _max?: Codec12_commandsMaxAggregateInputType
  }

  export type Codec12_commandsGroupByOutputType = {
    id: bigint
    uuid: string | null
    imei: string
    command: string
    status: string
    created_at: Date
    updated_at: Date
    sent_at: Date | null
    responded_at: Date | null
    response: string | null
    retries: number
    comment: string | null
    _count: Codec12_commandsCountAggregateOutputType | null
    _avg: Codec12_commandsAvgAggregateOutputType | null
    _sum: Codec12_commandsSumAggregateOutputType | null
    _min: Codec12_commandsMinAggregateOutputType | null
    _max: Codec12_commandsMaxAggregateOutputType | null
  }

  type GetCodec12_commandsGroupByPayload<T extends codec12_commandsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Codec12_commandsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Codec12_commandsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Codec12_commandsGroupByOutputType[P]>
            : GetScalarType<T[P], Codec12_commandsGroupByOutputType[P]>
        }
      >
    >


  export type codec12_commandsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    imei?: boolean
    command?: boolean
    status?: boolean
    created_at?: boolean
    updated_at?: boolean
    sent_at?: boolean
    responded_at?: boolean
    response?: boolean
    retries?: boolean
    comment?: boolean
  }, ExtArgs["result"]["codec12_commands"]>

  export type codec12_commandsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    imei?: boolean
    command?: boolean
    status?: boolean
    created_at?: boolean
    updated_at?: boolean
    sent_at?: boolean
    responded_at?: boolean
    response?: boolean
    retries?: boolean
    comment?: boolean
  }, ExtArgs["result"]["codec12_commands"]>

  export type codec12_commandsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    imei?: boolean
    command?: boolean
    status?: boolean
    created_at?: boolean
    updated_at?: boolean
    sent_at?: boolean
    responded_at?: boolean
    response?: boolean
    retries?: boolean
    comment?: boolean
  }, ExtArgs["result"]["codec12_commands"]>

  export type codec12_commandsSelectScalar = {
    id?: boolean
    uuid?: boolean
    imei?: boolean
    command?: boolean
    status?: boolean
    created_at?: boolean
    updated_at?: boolean
    sent_at?: boolean
    responded_at?: boolean
    response?: boolean
    retries?: boolean
    comment?: boolean
  }

  export type codec12_commandsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "uuid" | "imei" | "command" | "status" | "created_at" | "updated_at" | "sent_at" | "responded_at" | "response" | "retries" | "comment", ExtArgs["result"]["codec12_commands"]>

  export type $codec12_commandsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "codec12_commands"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      uuid: string | null
      imei: string
      command: string
      status: string
      created_at: Date
      updated_at: Date
      sent_at: Date | null
      responded_at: Date | null
      response: string | null
      retries: number
      comment: string | null
    }, ExtArgs["result"]["codec12_commands"]>
    composites: {}
  }

  type codec12_commandsGetPayload<S extends boolean | null | undefined | codec12_commandsDefaultArgs> = $Result.GetResult<Prisma.$codec12_commandsPayload, S>

  type codec12_commandsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<codec12_commandsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Codec12_commandsCountAggregateInputType | true
    }

  export interface codec12_commandsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['codec12_commands'], meta: { name: 'codec12_commands' } }
    /**
     * Find zero or one Codec12_commands that matches the filter.
     * @param {codec12_commandsFindUniqueArgs} args - Arguments to find a Codec12_commands
     * @example
     * // Get one Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends codec12_commandsFindUniqueArgs>(args: SelectSubset<T, codec12_commandsFindUniqueArgs<ExtArgs>>): Prisma__codec12_commandsClient<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Codec12_commands that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {codec12_commandsFindUniqueOrThrowArgs} args - Arguments to find a Codec12_commands
     * @example
     * // Get one Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends codec12_commandsFindUniqueOrThrowArgs>(args: SelectSubset<T, codec12_commandsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__codec12_commandsClient<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Codec12_commands that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {codec12_commandsFindFirstArgs} args - Arguments to find a Codec12_commands
     * @example
     * // Get one Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends codec12_commandsFindFirstArgs>(args?: SelectSubset<T, codec12_commandsFindFirstArgs<ExtArgs>>): Prisma__codec12_commandsClient<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Codec12_commands that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {codec12_commandsFindFirstOrThrowArgs} args - Arguments to find a Codec12_commands
     * @example
     * // Get one Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends codec12_commandsFindFirstOrThrowArgs>(args?: SelectSubset<T, codec12_commandsFindFirstOrThrowArgs<ExtArgs>>): Prisma__codec12_commandsClient<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Codec12_commands that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {codec12_commandsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.findMany()
     * 
     * // Get first 10 Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const codec12_commandsWithIdOnly = await prisma.codec12_commands.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends codec12_commandsFindManyArgs>(args?: SelectSubset<T, codec12_commandsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Codec12_commands.
     * @param {codec12_commandsCreateArgs} args - Arguments to create a Codec12_commands.
     * @example
     * // Create one Codec12_commands
     * const Codec12_commands = await prisma.codec12_commands.create({
     *   data: {
     *     // ... data to create a Codec12_commands
     *   }
     * })
     * 
     */
    create<T extends codec12_commandsCreateArgs>(args: SelectSubset<T, codec12_commandsCreateArgs<ExtArgs>>): Prisma__codec12_commandsClient<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Codec12_commands.
     * @param {codec12_commandsCreateManyArgs} args - Arguments to create many Codec12_commands.
     * @example
     * // Create many Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends codec12_commandsCreateManyArgs>(args?: SelectSubset<T, codec12_commandsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Codec12_commands and returns the data saved in the database.
     * @param {codec12_commandsCreateManyAndReturnArgs} args - Arguments to create many Codec12_commands.
     * @example
     * // Create many Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Codec12_commands and only return the `id`
     * const codec12_commandsWithIdOnly = await prisma.codec12_commands.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends codec12_commandsCreateManyAndReturnArgs>(args?: SelectSubset<T, codec12_commandsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Codec12_commands.
     * @param {codec12_commandsDeleteArgs} args - Arguments to delete one Codec12_commands.
     * @example
     * // Delete one Codec12_commands
     * const Codec12_commands = await prisma.codec12_commands.delete({
     *   where: {
     *     // ... filter to delete one Codec12_commands
     *   }
     * })
     * 
     */
    delete<T extends codec12_commandsDeleteArgs>(args: SelectSubset<T, codec12_commandsDeleteArgs<ExtArgs>>): Prisma__codec12_commandsClient<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Codec12_commands.
     * @param {codec12_commandsUpdateArgs} args - Arguments to update one Codec12_commands.
     * @example
     * // Update one Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends codec12_commandsUpdateArgs>(args: SelectSubset<T, codec12_commandsUpdateArgs<ExtArgs>>): Prisma__codec12_commandsClient<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Codec12_commands.
     * @param {codec12_commandsDeleteManyArgs} args - Arguments to filter Codec12_commands to delete.
     * @example
     * // Delete a few Codec12_commands
     * const { count } = await prisma.codec12_commands.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends codec12_commandsDeleteManyArgs>(args?: SelectSubset<T, codec12_commandsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Codec12_commands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {codec12_commandsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends codec12_commandsUpdateManyArgs>(args: SelectSubset<T, codec12_commandsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Codec12_commands and returns the data updated in the database.
     * @param {codec12_commandsUpdateManyAndReturnArgs} args - Arguments to update many Codec12_commands.
     * @example
     * // Update many Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Codec12_commands and only return the `id`
     * const codec12_commandsWithIdOnly = await prisma.codec12_commands.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends codec12_commandsUpdateManyAndReturnArgs>(args: SelectSubset<T, codec12_commandsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Codec12_commands.
     * @param {codec12_commandsUpsertArgs} args - Arguments to update or create a Codec12_commands.
     * @example
     * // Update or create a Codec12_commands
     * const codec12_commands = await prisma.codec12_commands.upsert({
     *   create: {
     *     // ... data to create a Codec12_commands
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Codec12_commands we want to update
     *   }
     * })
     */
    upsert<T extends codec12_commandsUpsertArgs>(args: SelectSubset<T, codec12_commandsUpsertArgs<ExtArgs>>): Prisma__codec12_commandsClient<$Result.GetResult<Prisma.$codec12_commandsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Codec12_commands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {codec12_commandsCountArgs} args - Arguments to filter Codec12_commands to count.
     * @example
     * // Count the number of Codec12_commands
     * const count = await prisma.codec12_commands.count({
     *   where: {
     *     // ... the filter for the Codec12_commands we want to count
     *   }
     * })
    **/
    count<T extends codec12_commandsCountArgs>(
      args?: Subset<T, codec12_commandsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Codec12_commandsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Codec12_commands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Codec12_commandsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Codec12_commandsAggregateArgs>(args: Subset<T, Codec12_commandsAggregateArgs>): Prisma.PrismaPromise<GetCodec12_commandsAggregateType<T>>

    /**
     * Group by Codec12_commands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {codec12_commandsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends codec12_commandsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: codec12_commandsGroupByArgs['orderBy'] }
        : { orderBy?: codec12_commandsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, codec12_commandsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCodec12_commandsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the codec12_commands model
   */
  readonly fields: codec12_commandsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for codec12_commands.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__codec12_commandsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the codec12_commands model
   */
  interface codec12_commandsFieldRefs {
    readonly id: FieldRef<"codec12_commands", 'BigInt'>
    readonly uuid: FieldRef<"codec12_commands", 'String'>
    readonly imei: FieldRef<"codec12_commands", 'String'>
    readonly command: FieldRef<"codec12_commands", 'String'>
    readonly status: FieldRef<"codec12_commands", 'String'>
    readonly created_at: FieldRef<"codec12_commands", 'DateTime'>
    readonly updated_at: FieldRef<"codec12_commands", 'DateTime'>
    readonly sent_at: FieldRef<"codec12_commands", 'DateTime'>
    readonly responded_at: FieldRef<"codec12_commands", 'DateTime'>
    readonly response: FieldRef<"codec12_commands", 'String'>
    readonly retries: FieldRef<"codec12_commands", 'Int'>
    readonly comment: FieldRef<"codec12_commands", 'String'>
  }
    

  // Custom InputTypes
  /**
   * codec12_commands findUnique
   */
  export type codec12_commandsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * Filter, which codec12_commands to fetch.
     */
    where: codec12_commandsWhereUniqueInput
  }

  /**
   * codec12_commands findUniqueOrThrow
   */
  export type codec12_commandsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * Filter, which codec12_commands to fetch.
     */
    where: codec12_commandsWhereUniqueInput
  }

  /**
   * codec12_commands findFirst
   */
  export type codec12_commandsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * Filter, which codec12_commands to fetch.
     */
    where?: codec12_commandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of codec12_commands to fetch.
     */
    orderBy?: codec12_commandsOrderByWithRelationInput | codec12_commandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for codec12_commands.
     */
    cursor?: codec12_commandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` codec12_commands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` codec12_commands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of codec12_commands.
     */
    distinct?: Codec12_commandsScalarFieldEnum | Codec12_commandsScalarFieldEnum[]
  }

  /**
   * codec12_commands findFirstOrThrow
   */
  export type codec12_commandsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * Filter, which codec12_commands to fetch.
     */
    where?: codec12_commandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of codec12_commands to fetch.
     */
    orderBy?: codec12_commandsOrderByWithRelationInput | codec12_commandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for codec12_commands.
     */
    cursor?: codec12_commandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` codec12_commands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` codec12_commands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of codec12_commands.
     */
    distinct?: Codec12_commandsScalarFieldEnum | Codec12_commandsScalarFieldEnum[]
  }

  /**
   * codec12_commands findMany
   */
  export type codec12_commandsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * Filter, which codec12_commands to fetch.
     */
    where?: codec12_commandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of codec12_commands to fetch.
     */
    orderBy?: codec12_commandsOrderByWithRelationInput | codec12_commandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing codec12_commands.
     */
    cursor?: codec12_commandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` codec12_commands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` codec12_commands.
     */
    skip?: number
    distinct?: Codec12_commandsScalarFieldEnum | Codec12_commandsScalarFieldEnum[]
  }

  /**
   * codec12_commands create
   */
  export type codec12_commandsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * The data needed to create a codec12_commands.
     */
    data: XOR<codec12_commandsCreateInput, codec12_commandsUncheckedCreateInput>
  }

  /**
   * codec12_commands createMany
   */
  export type codec12_commandsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many codec12_commands.
     */
    data: codec12_commandsCreateManyInput | codec12_commandsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * codec12_commands createManyAndReturn
   */
  export type codec12_commandsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * The data used to create many codec12_commands.
     */
    data: codec12_commandsCreateManyInput | codec12_commandsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * codec12_commands update
   */
  export type codec12_commandsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * The data needed to update a codec12_commands.
     */
    data: XOR<codec12_commandsUpdateInput, codec12_commandsUncheckedUpdateInput>
    /**
     * Choose, which codec12_commands to update.
     */
    where: codec12_commandsWhereUniqueInput
  }

  /**
   * codec12_commands updateMany
   */
  export type codec12_commandsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update codec12_commands.
     */
    data: XOR<codec12_commandsUpdateManyMutationInput, codec12_commandsUncheckedUpdateManyInput>
    /**
     * Filter which codec12_commands to update
     */
    where?: codec12_commandsWhereInput
    /**
     * Limit how many codec12_commands to update.
     */
    limit?: number
  }

  /**
   * codec12_commands updateManyAndReturn
   */
  export type codec12_commandsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * The data used to update codec12_commands.
     */
    data: XOR<codec12_commandsUpdateManyMutationInput, codec12_commandsUncheckedUpdateManyInput>
    /**
     * Filter which codec12_commands to update
     */
    where?: codec12_commandsWhereInput
    /**
     * Limit how many codec12_commands to update.
     */
    limit?: number
  }

  /**
   * codec12_commands upsert
   */
  export type codec12_commandsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * The filter to search for the codec12_commands to update in case it exists.
     */
    where: codec12_commandsWhereUniqueInput
    /**
     * In case the codec12_commands found by the `where` argument doesn't exist, create a new codec12_commands with this data.
     */
    create: XOR<codec12_commandsCreateInput, codec12_commandsUncheckedCreateInput>
    /**
     * In case the codec12_commands was found with the provided `where` argument, update it with this data.
     */
    update: XOR<codec12_commandsUpdateInput, codec12_commandsUncheckedUpdateInput>
  }

  /**
   * codec12_commands delete
   */
  export type codec12_commandsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
    /**
     * Filter which codec12_commands to delete.
     */
    where: codec12_commandsWhereUniqueInput
  }

  /**
   * codec12_commands deleteMany
   */
  export type codec12_commandsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which codec12_commands to delete
     */
    where?: codec12_commandsWhereInput
    /**
     * Limit how many codec12_commands to delete.
     */
    limit?: number
  }

  /**
   * codec12_commands without action
   */
  export type codec12_commandsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the codec12_commands
     */
    select?: codec12_commandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the codec12_commands
     */
    omit?: codec12_commandsOmit<ExtArgs> | null
  }


  /**
   * Model user_organisation_access
   */

  export type AggregateUser_organisation_access = {
    _count: User_organisation_accessCountAggregateOutputType | null
    _avg: User_organisation_accessAvgAggregateOutputType | null
    _sum: User_organisation_accessSumAggregateOutputType | null
    _min: User_organisation_accessMinAggregateOutputType | null
    _max: User_organisation_accessMaxAggregateOutputType | null
  }

  export type User_organisation_accessAvgAggregateOutputType = {
    user_id: number | null
    organisation_id: number | null
  }

  export type User_organisation_accessSumAggregateOutputType = {
    user_id: bigint | null
    organisation_id: bigint | null
  }

  export type User_organisation_accessMinAggregateOutputType = {
    user_id: bigint | null
    organisation_id: bigint | null
    is_allowed: boolean | null
  }

  export type User_organisation_accessMaxAggregateOutputType = {
    user_id: bigint | null
    organisation_id: bigint | null
    is_allowed: boolean | null
  }

  export type User_organisation_accessCountAggregateOutputType = {
    user_id: number
    organisation_id: number
    is_allowed: number
    _all: number
  }


  export type User_organisation_accessAvgAggregateInputType = {
    user_id?: true
    organisation_id?: true
  }

  export type User_organisation_accessSumAggregateInputType = {
    user_id?: true
    organisation_id?: true
  }

  export type User_organisation_accessMinAggregateInputType = {
    user_id?: true
    organisation_id?: true
    is_allowed?: true
  }

  export type User_organisation_accessMaxAggregateInputType = {
    user_id?: true
    organisation_id?: true
    is_allowed?: true
  }

  export type User_organisation_accessCountAggregateInputType = {
    user_id?: true
    organisation_id?: true
    is_allowed?: true
    _all?: true
  }

  export type User_organisation_accessAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which user_organisation_access to aggregate.
     */
    where?: user_organisation_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_organisation_accesses to fetch.
     */
    orderBy?: user_organisation_accessOrderByWithRelationInput | user_organisation_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: user_organisation_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_organisation_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_organisation_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned user_organisation_accesses
    **/
    _count?: true | User_organisation_accessCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: User_organisation_accessAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: User_organisation_accessSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: User_organisation_accessMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: User_organisation_accessMaxAggregateInputType
  }

  export type GetUser_organisation_accessAggregateType<T extends User_organisation_accessAggregateArgs> = {
        [P in keyof T & keyof AggregateUser_organisation_access]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser_organisation_access[P]>
      : GetScalarType<T[P], AggregateUser_organisation_access[P]>
  }




  export type user_organisation_accessGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_organisation_accessWhereInput
    orderBy?: user_organisation_accessOrderByWithAggregationInput | user_organisation_accessOrderByWithAggregationInput[]
    by: User_organisation_accessScalarFieldEnum[] | User_organisation_accessScalarFieldEnum
    having?: user_organisation_accessScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: User_organisation_accessCountAggregateInputType | true
    _avg?: User_organisation_accessAvgAggregateInputType
    _sum?: User_organisation_accessSumAggregateInputType
    _min?: User_organisation_accessMinAggregateInputType
    _max?: User_organisation_accessMaxAggregateInputType
  }

  export type User_organisation_accessGroupByOutputType = {
    user_id: bigint
    organisation_id: bigint
    is_allowed: boolean
    _count: User_organisation_accessCountAggregateOutputType | null
    _avg: User_organisation_accessAvgAggregateOutputType | null
    _sum: User_organisation_accessSumAggregateOutputType | null
    _min: User_organisation_accessMinAggregateOutputType | null
    _max: User_organisation_accessMaxAggregateOutputType | null
  }

  type GetUser_organisation_accessGroupByPayload<T extends user_organisation_accessGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<User_organisation_accessGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof User_organisation_accessGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], User_organisation_accessGroupByOutputType[P]>
            : GetScalarType<T[P], User_organisation_accessGroupByOutputType[P]>
        }
      >
    >


  export type user_organisation_accessSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    organisation_id?: boolean
    is_allowed?: boolean
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_organisation_access"]>

  export type user_organisation_accessSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    organisation_id?: boolean
    is_allowed?: boolean
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_organisation_access"]>

  export type user_organisation_accessSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    organisation_id?: boolean
    is_allowed?: boolean
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_organisation_access"]>

  export type user_organisation_accessSelectScalar = {
    user_id?: boolean
    organisation_id?: boolean
    is_allowed?: boolean
  }

  export type user_organisation_accessOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"user_id" | "organisation_id" | "is_allowed", ExtArgs["result"]["user_organisation_access"]>
  export type user_organisation_accessInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }
  export type user_organisation_accessIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }
  export type user_organisation_accessIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    organisations?: boolean | organisationsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }

  export type $user_organisation_accessPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "user_organisation_access"
    objects: {
      organisations: Prisma.$organisationsPayload<ExtArgs>
      users: Prisma.$usersPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      user_id: bigint
      organisation_id: bigint
      is_allowed: boolean
    }, ExtArgs["result"]["user_organisation_access"]>
    composites: {}
  }

  type user_organisation_accessGetPayload<S extends boolean | null | undefined | user_organisation_accessDefaultArgs> = $Result.GetResult<Prisma.$user_organisation_accessPayload, S>

  type user_organisation_accessCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<user_organisation_accessFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: User_organisation_accessCountAggregateInputType | true
    }

  export interface user_organisation_accessDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['user_organisation_access'], meta: { name: 'user_organisation_access' } }
    /**
     * Find zero or one User_organisation_access that matches the filter.
     * @param {user_organisation_accessFindUniqueArgs} args - Arguments to find a User_organisation_access
     * @example
     * // Get one User_organisation_access
     * const user_organisation_access = await prisma.user_organisation_access.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends user_organisation_accessFindUniqueArgs>(args: SelectSubset<T, user_organisation_accessFindUniqueArgs<ExtArgs>>): Prisma__user_organisation_accessClient<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User_organisation_access that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {user_organisation_accessFindUniqueOrThrowArgs} args - Arguments to find a User_organisation_access
     * @example
     * // Get one User_organisation_access
     * const user_organisation_access = await prisma.user_organisation_access.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends user_organisation_accessFindUniqueOrThrowArgs>(args: SelectSubset<T, user_organisation_accessFindUniqueOrThrowArgs<ExtArgs>>): Prisma__user_organisation_accessClient<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User_organisation_access that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_organisation_accessFindFirstArgs} args - Arguments to find a User_organisation_access
     * @example
     * // Get one User_organisation_access
     * const user_organisation_access = await prisma.user_organisation_access.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends user_organisation_accessFindFirstArgs>(args?: SelectSubset<T, user_organisation_accessFindFirstArgs<ExtArgs>>): Prisma__user_organisation_accessClient<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User_organisation_access that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_organisation_accessFindFirstOrThrowArgs} args - Arguments to find a User_organisation_access
     * @example
     * // Get one User_organisation_access
     * const user_organisation_access = await prisma.user_organisation_access.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends user_organisation_accessFindFirstOrThrowArgs>(args?: SelectSubset<T, user_organisation_accessFindFirstOrThrowArgs<ExtArgs>>): Prisma__user_organisation_accessClient<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more User_organisation_accesses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_organisation_accessFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all User_organisation_accesses
     * const user_organisation_accesses = await prisma.user_organisation_access.findMany()
     * 
     * // Get first 10 User_organisation_accesses
     * const user_organisation_accesses = await prisma.user_organisation_access.findMany({ take: 10 })
     * 
     * // Only select the `user_id`
     * const user_organisation_accessWithUser_idOnly = await prisma.user_organisation_access.findMany({ select: { user_id: true } })
     * 
     */
    findMany<T extends user_organisation_accessFindManyArgs>(args?: SelectSubset<T, user_organisation_accessFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User_organisation_access.
     * @param {user_organisation_accessCreateArgs} args - Arguments to create a User_organisation_access.
     * @example
     * // Create one User_organisation_access
     * const User_organisation_access = await prisma.user_organisation_access.create({
     *   data: {
     *     // ... data to create a User_organisation_access
     *   }
     * })
     * 
     */
    create<T extends user_organisation_accessCreateArgs>(args: SelectSubset<T, user_organisation_accessCreateArgs<ExtArgs>>): Prisma__user_organisation_accessClient<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many User_organisation_accesses.
     * @param {user_organisation_accessCreateManyArgs} args - Arguments to create many User_organisation_accesses.
     * @example
     * // Create many User_organisation_accesses
     * const user_organisation_access = await prisma.user_organisation_access.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends user_organisation_accessCreateManyArgs>(args?: SelectSubset<T, user_organisation_accessCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many User_organisation_accesses and returns the data saved in the database.
     * @param {user_organisation_accessCreateManyAndReturnArgs} args - Arguments to create many User_organisation_accesses.
     * @example
     * // Create many User_organisation_accesses
     * const user_organisation_access = await prisma.user_organisation_access.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many User_organisation_accesses and only return the `user_id`
     * const user_organisation_accessWithUser_idOnly = await prisma.user_organisation_access.createManyAndReturn({
     *   select: { user_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends user_organisation_accessCreateManyAndReturnArgs>(args?: SelectSubset<T, user_organisation_accessCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User_organisation_access.
     * @param {user_organisation_accessDeleteArgs} args - Arguments to delete one User_organisation_access.
     * @example
     * // Delete one User_organisation_access
     * const User_organisation_access = await prisma.user_organisation_access.delete({
     *   where: {
     *     // ... filter to delete one User_organisation_access
     *   }
     * })
     * 
     */
    delete<T extends user_organisation_accessDeleteArgs>(args: SelectSubset<T, user_organisation_accessDeleteArgs<ExtArgs>>): Prisma__user_organisation_accessClient<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User_organisation_access.
     * @param {user_organisation_accessUpdateArgs} args - Arguments to update one User_organisation_access.
     * @example
     * // Update one User_organisation_access
     * const user_organisation_access = await prisma.user_organisation_access.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends user_organisation_accessUpdateArgs>(args: SelectSubset<T, user_organisation_accessUpdateArgs<ExtArgs>>): Prisma__user_organisation_accessClient<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more User_organisation_accesses.
     * @param {user_organisation_accessDeleteManyArgs} args - Arguments to filter User_organisation_accesses to delete.
     * @example
     * // Delete a few User_organisation_accesses
     * const { count } = await prisma.user_organisation_access.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends user_organisation_accessDeleteManyArgs>(args?: SelectSubset<T, user_organisation_accessDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more User_organisation_accesses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_organisation_accessUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many User_organisation_accesses
     * const user_organisation_access = await prisma.user_organisation_access.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends user_organisation_accessUpdateManyArgs>(args: SelectSubset<T, user_organisation_accessUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more User_organisation_accesses and returns the data updated in the database.
     * @param {user_organisation_accessUpdateManyAndReturnArgs} args - Arguments to update many User_organisation_accesses.
     * @example
     * // Update many User_organisation_accesses
     * const user_organisation_access = await prisma.user_organisation_access.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more User_organisation_accesses and only return the `user_id`
     * const user_organisation_accessWithUser_idOnly = await prisma.user_organisation_access.updateManyAndReturn({
     *   select: { user_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends user_organisation_accessUpdateManyAndReturnArgs>(args: SelectSubset<T, user_organisation_accessUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User_organisation_access.
     * @param {user_organisation_accessUpsertArgs} args - Arguments to update or create a User_organisation_access.
     * @example
     * // Update or create a User_organisation_access
     * const user_organisation_access = await prisma.user_organisation_access.upsert({
     *   create: {
     *     // ... data to create a User_organisation_access
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User_organisation_access we want to update
     *   }
     * })
     */
    upsert<T extends user_organisation_accessUpsertArgs>(args: SelectSubset<T, user_organisation_accessUpsertArgs<ExtArgs>>): Prisma__user_organisation_accessClient<$Result.GetResult<Prisma.$user_organisation_accessPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of User_organisation_accesses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_organisation_accessCountArgs} args - Arguments to filter User_organisation_accesses to count.
     * @example
     * // Count the number of User_organisation_accesses
     * const count = await prisma.user_organisation_access.count({
     *   where: {
     *     // ... the filter for the User_organisation_accesses we want to count
     *   }
     * })
    **/
    count<T extends user_organisation_accessCountArgs>(
      args?: Subset<T, user_organisation_accessCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], User_organisation_accessCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User_organisation_access.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {User_organisation_accessAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends User_organisation_accessAggregateArgs>(args: Subset<T, User_organisation_accessAggregateArgs>): Prisma.PrismaPromise<GetUser_organisation_accessAggregateType<T>>

    /**
     * Group by User_organisation_access.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_organisation_accessGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends user_organisation_accessGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: user_organisation_accessGroupByArgs['orderBy'] }
        : { orderBy?: user_organisation_accessGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, user_organisation_accessGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUser_organisation_accessGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the user_organisation_access model
   */
  readonly fields: user_organisation_accessFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for user_organisation_access.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__user_organisation_accessClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    organisations<T extends organisationsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, organisationsDefaultArgs<ExtArgs>>): Prisma__organisationsClient<$Result.GetResult<Prisma.$organisationsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    users<T extends usersDefaultArgs<ExtArgs> = {}>(args?: Subset<T, usersDefaultArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the user_organisation_access model
   */
  interface user_organisation_accessFieldRefs {
    readonly user_id: FieldRef<"user_organisation_access", 'BigInt'>
    readonly organisation_id: FieldRef<"user_organisation_access", 'BigInt'>
    readonly is_allowed: FieldRef<"user_organisation_access", 'Boolean'>
  }
    

  // Custom InputTypes
  /**
   * user_organisation_access findUnique
   */
  export type user_organisation_accessFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_organisation_access to fetch.
     */
    where: user_organisation_accessWhereUniqueInput
  }

  /**
   * user_organisation_access findUniqueOrThrow
   */
  export type user_organisation_accessFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_organisation_access to fetch.
     */
    where: user_organisation_accessWhereUniqueInput
  }

  /**
   * user_organisation_access findFirst
   */
  export type user_organisation_accessFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_organisation_access to fetch.
     */
    where?: user_organisation_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_organisation_accesses to fetch.
     */
    orderBy?: user_organisation_accessOrderByWithRelationInput | user_organisation_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for user_organisation_accesses.
     */
    cursor?: user_organisation_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_organisation_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_organisation_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of user_organisation_accesses.
     */
    distinct?: User_organisation_accessScalarFieldEnum | User_organisation_accessScalarFieldEnum[]
  }

  /**
   * user_organisation_access findFirstOrThrow
   */
  export type user_organisation_accessFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_organisation_access to fetch.
     */
    where?: user_organisation_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_organisation_accesses to fetch.
     */
    orderBy?: user_organisation_accessOrderByWithRelationInput | user_organisation_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for user_organisation_accesses.
     */
    cursor?: user_organisation_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_organisation_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_organisation_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of user_organisation_accesses.
     */
    distinct?: User_organisation_accessScalarFieldEnum | User_organisation_accessScalarFieldEnum[]
  }

  /**
   * user_organisation_access findMany
   */
  export type user_organisation_accessFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_organisation_accesses to fetch.
     */
    where?: user_organisation_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_organisation_accesses to fetch.
     */
    orderBy?: user_organisation_accessOrderByWithRelationInput | user_organisation_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing user_organisation_accesses.
     */
    cursor?: user_organisation_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_organisation_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_organisation_accesses.
     */
    skip?: number
    distinct?: User_organisation_accessScalarFieldEnum | User_organisation_accessScalarFieldEnum[]
  }

  /**
   * user_organisation_access create
   */
  export type user_organisation_accessCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * The data needed to create a user_organisation_access.
     */
    data: XOR<user_organisation_accessCreateInput, user_organisation_accessUncheckedCreateInput>
  }

  /**
   * user_organisation_access createMany
   */
  export type user_organisation_accessCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many user_organisation_accesses.
     */
    data: user_organisation_accessCreateManyInput | user_organisation_accessCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * user_organisation_access createManyAndReturn
   */
  export type user_organisation_accessCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * The data used to create many user_organisation_accesses.
     */
    data: user_organisation_accessCreateManyInput | user_organisation_accessCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * user_organisation_access update
   */
  export type user_organisation_accessUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * The data needed to update a user_organisation_access.
     */
    data: XOR<user_organisation_accessUpdateInput, user_organisation_accessUncheckedUpdateInput>
    /**
     * Choose, which user_organisation_access to update.
     */
    where: user_organisation_accessWhereUniqueInput
  }

  /**
   * user_organisation_access updateMany
   */
  export type user_organisation_accessUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update user_organisation_accesses.
     */
    data: XOR<user_organisation_accessUpdateManyMutationInput, user_organisation_accessUncheckedUpdateManyInput>
    /**
     * Filter which user_organisation_accesses to update
     */
    where?: user_organisation_accessWhereInput
    /**
     * Limit how many user_organisation_accesses to update.
     */
    limit?: number
  }

  /**
   * user_organisation_access updateManyAndReturn
   */
  export type user_organisation_accessUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * The data used to update user_organisation_accesses.
     */
    data: XOR<user_organisation_accessUpdateManyMutationInput, user_organisation_accessUncheckedUpdateManyInput>
    /**
     * Filter which user_organisation_accesses to update
     */
    where?: user_organisation_accessWhereInput
    /**
     * Limit how many user_organisation_accesses to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * user_organisation_access upsert
   */
  export type user_organisation_accessUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * The filter to search for the user_organisation_access to update in case it exists.
     */
    where: user_organisation_accessWhereUniqueInput
    /**
     * In case the user_organisation_access found by the `where` argument doesn't exist, create a new user_organisation_access with this data.
     */
    create: XOR<user_organisation_accessCreateInput, user_organisation_accessUncheckedCreateInput>
    /**
     * In case the user_organisation_access was found with the provided `where` argument, update it with this data.
     */
    update: XOR<user_organisation_accessUpdateInput, user_organisation_accessUncheckedUpdateInput>
  }

  /**
   * user_organisation_access delete
   */
  export type user_organisation_accessDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
    /**
     * Filter which user_organisation_access to delete.
     */
    where: user_organisation_accessWhereUniqueInput
  }

  /**
   * user_organisation_access deleteMany
   */
  export type user_organisation_accessDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which user_organisation_accesses to delete
     */
    where?: user_organisation_accessWhereInput
    /**
     * Limit how many user_organisation_accesses to delete.
     */
    limit?: number
  }

  /**
   * user_organisation_access without action
   */
  export type user_organisation_accessDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_organisation_access
     */
    select?: user_organisation_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_organisation_access
     */
    omit?: user_organisation_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_organisation_accessInclude<ExtArgs> | null
  }


  /**
   * Model user_asset_access
   */

  export type AggregateUser_asset_access = {
    _count: User_asset_accessCountAggregateOutputType | null
    _avg: User_asset_accessAvgAggregateOutputType | null
    _sum: User_asset_accessSumAggregateOutputType | null
    _min: User_asset_accessMinAggregateOutputType | null
    _max: User_asset_accessMaxAggregateOutputType | null
  }

  export type User_asset_accessAvgAggregateOutputType = {
    user_id: number | null
    asset_id: number | null
  }

  export type User_asset_accessSumAggregateOutputType = {
    user_id: bigint | null
    asset_id: bigint | null
  }

  export type User_asset_accessMinAggregateOutputType = {
    user_id: bigint | null
    asset_id: bigint | null
    is_allowed: boolean | null
  }

  export type User_asset_accessMaxAggregateOutputType = {
    user_id: bigint | null
    asset_id: bigint | null
    is_allowed: boolean | null
  }

  export type User_asset_accessCountAggregateOutputType = {
    user_id: number
    asset_id: number
    is_allowed: number
    _all: number
  }


  export type User_asset_accessAvgAggregateInputType = {
    user_id?: true
    asset_id?: true
  }

  export type User_asset_accessSumAggregateInputType = {
    user_id?: true
    asset_id?: true
  }

  export type User_asset_accessMinAggregateInputType = {
    user_id?: true
    asset_id?: true
    is_allowed?: true
  }

  export type User_asset_accessMaxAggregateInputType = {
    user_id?: true
    asset_id?: true
    is_allowed?: true
  }

  export type User_asset_accessCountAggregateInputType = {
    user_id?: true
    asset_id?: true
    is_allowed?: true
    _all?: true
  }

  export type User_asset_accessAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which user_asset_access to aggregate.
     */
    where?: user_asset_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_asset_accesses to fetch.
     */
    orderBy?: user_asset_accessOrderByWithRelationInput | user_asset_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: user_asset_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_asset_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_asset_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned user_asset_accesses
    **/
    _count?: true | User_asset_accessCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: User_asset_accessAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: User_asset_accessSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: User_asset_accessMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: User_asset_accessMaxAggregateInputType
  }

  export type GetUser_asset_accessAggregateType<T extends User_asset_accessAggregateArgs> = {
        [P in keyof T & keyof AggregateUser_asset_access]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser_asset_access[P]>
      : GetScalarType<T[P], AggregateUser_asset_access[P]>
  }




  export type user_asset_accessGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_asset_accessWhereInput
    orderBy?: user_asset_accessOrderByWithAggregationInput | user_asset_accessOrderByWithAggregationInput[]
    by: User_asset_accessScalarFieldEnum[] | User_asset_accessScalarFieldEnum
    having?: user_asset_accessScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: User_asset_accessCountAggregateInputType | true
    _avg?: User_asset_accessAvgAggregateInputType
    _sum?: User_asset_accessSumAggregateInputType
    _min?: User_asset_accessMinAggregateInputType
    _max?: User_asset_accessMaxAggregateInputType
  }

  export type User_asset_accessGroupByOutputType = {
    user_id: bigint
    asset_id: bigint
    is_allowed: boolean
    _count: User_asset_accessCountAggregateOutputType | null
    _avg: User_asset_accessAvgAggregateOutputType | null
    _sum: User_asset_accessSumAggregateOutputType | null
    _min: User_asset_accessMinAggregateOutputType | null
    _max: User_asset_accessMaxAggregateOutputType | null
  }

  type GetUser_asset_accessGroupByPayload<T extends user_asset_accessGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<User_asset_accessGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof User_asset_accessGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], User_asset_accessGroupByOutputType[P]>
            : GetScalarType<T[P], User_asset_accessGroupByOutputType[P]>
        }
      >
    >


  export type user_asset_accessSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    asset_id?: boolean
    is_allowed?: boolean
    assets?: boolean | assetsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_asset_access"]>

  export type user_asset_accessSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    asset_id?: boolean
    is_allowed?: boolean
    assets?: boolean | assetsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_asset_access"]>

  export type user_asset_accessSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    asset_id?: boolean
    is_allowed?: boolean
    assets?: boolean | assetsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_asset_access"]>

  export type user_asset_accessSelectScalar = {
    user_id?: boolean
    asset_id?: boolean
    is_allowed?: boolean
  }

  export type user_asset_accessOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"user_id" | "asset_id" | "is_allowed", ExtArgs["result"]["user_asset_access"]>
  export type user_asset_accessInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | assetsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }
  export type user_asset_accessIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | assetsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }
  export type user_asset_accessIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    assets?: boolean | assetsDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }

  export type $user_asset_accessPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "user_asset_access"
    objects: {
      assets: Prisma.$assetsPayload<ExtArgs>
      users: Prisma.$usersPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      user_id: bigint
      asset_id: bigint
      is_allowed: boolean
    }, ExtArgs["result"]["user_asset_access"]>
    composites: {}
  }

  type user_asset_accessGetPayload<S extends boolean | null | undefined | user_asset_accessDefaultArgs> = $Result.GetResult<Prisma.$user_asset_accessPayload, S>

  type user_asset_accessCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<user_asset_accessFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: User_asset_accessCountAggregateInputType | true
    }

  export interface user_asset_accessDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['user_asset_access'], meta: { name: 'user_asset_access' } }
    /**
     * Find zero or one User_asset_access that matches the filter.
     * @param {user_asset_accessFindUniqueArgs} args - Arguments to find a User_asset_access
     * @example
     * // Get one User_asset_access
     * const user_asset_access = await prisma.user_asset_access.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends user_asset_accessFindUniqueArgs>(args: SelectSubset<T, user_asset_accessFindUniqueArgs<ExtArgs>>): Prisma__user_asset_accessClient<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User_asset_access that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {user_asset_accessFindUniqueOrThrowArgs} args - Arguments to find a User_asset_access
     * @example
     * // Get one User_asset_access
     * const user_asset_access = await prisma.user_asset_access.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends user_asset_accessFindUniqueOrThrowArgs>(args: SelectSubset<T, user_asset_accessFindUniqueOrThrowArgs<ExtArgs>>): Prisma__user_asset_accessClient<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User_asset_access that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_asset_accessFindFirstArgs} args - Arguments to find a User_asset_access
     * @example
     * // Get one User_asset_access
     * const user_asset_access = await prisma.user_asset_access.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends user_asset_accessFindFirstArgs>(args?: SelectSubset<T, user_asset_accessFindFirstArgs<ExtArgs>>): Prisma__user_asset_accessClient<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User_asset_access that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_asset_accessFindFirstOrThrowArgs} args - Arguments to find a User_asset_access
     * @example
     * // Get one User_asset_access
     * const user_asset_access = await prisma.user_asset_access.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends user_asset_accessFindFirstOrThrowArgs>(args?: SelectSubset<T, user_asset_accessFindFirstOrThrowArgs<ExtArgs>>): Prisma__user_asset_accessClient<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more User_asset_accesses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_asset_accessFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all User_asset_accesses
     * const user_asset_accesses = await prisma.user_asset_access.findMany()
     * 
     * // Get first 10 User_asset_accesses
     * const user_asset_accesses = await prisma.user_asset_access.findMany({ take: 10 })
     * 
     * // Only select the `user_id`
     * const user_asset_accessWithUser_idOnly = await prisma.user_asset_access.findMany({ select: { user_id: true } })
     * 
     */
    findMany<T extends user_asset_accessFindManyArgs>(args?: SelectSubset<T, user_asset_accessFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User_asset_access.
     * @param {user_asset_accessCreateArgs} args - Arguments to create a User_asset_access.
     * @example
     * // Create one User_asset_access
     * const User_asset_access = await prisma.user_asset_access.create({
     *   data: {
     *     // ... data to create a User_asset_access
     *   }
     * })
     * 
     */
    create<T extends user_asset_accessCreateArgs>(args: SelectSubset<T, user_asset_accessCreateArgs<ExtArgs>>): Prisma__user_asset_accessClient<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many User_asset_accesses.
     * @param {user_asset_accessCreateManyArgs} args - Arguments to create many User_asset_accesses.
     * @example
     * // Create many User_asset_accesses
     * const user_asset_access = await prisma.user_asset_access.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends user_asset_accessCreateManyArgs>(args?: SelectSubset<T, user_asset_accessCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many User_asset_accesses and returns the data saved in the database.
     * @param {user_asset_accessCreateManyAndReturnArgs} args - Arguments to create many User_asset_accesses.
     * @example
     * // Create many User_asset_accesses
     * const user_asset_access = await prisma.user_asset_access.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many User_asset_accesses and only return the `user_id`
     * const user_asset_accessWithUser_idOnly = await prisma.user_asset_access.createManyAndReturn({
     *   select: { user_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends user_asset_accessCreateManyAndReturnArgs>(args?: SelectSubset<T, user_asset_accessCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User_asset_access.
     * @param {user_asset_accessDeleteArgs} args - Arguments to delete one User_asset_access.
     * @example
     * // Delete one User_asset_access
     * const User_asset_access = await prisma.user_asset_access.delete({
     *   where: {
     *     // ... filter to delete one User_asset_access
     *   }
     * })
     * 
     */
    delete<T extends user_asset_accessDeleteArgs>(args: SelectSubset<T, user_asset_accessDeleteArgs<ExtArgs>>): Prisma__user_asset_accessClient<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User_asset_access.
     * @param {user_asset_accessUpdateArgs} args - Arguments to update one User_asset_access.
     * @example
     * // Update one User_asset_access
     * const user_asset_access = await prisma.user_asset_access.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends user_asset_accessUpdateArgs>(args: SelectSubset<T, user_asset_accessUpdateArgs<ExtArgs>>): Prisma__user_asset_accessClient<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more User_asset_accesses.
     * @param {user_asset_accessDeleteManyArgs} args - Arguments to filter User_asset_accesses to delete.
     * @example
     * // Delete a few User_asset_accesses
     * const { count } = await prisma.user_asset_access.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends user_asset_accessDeleteManyArgs>(args?: SelectSubset<T, user_asset_accessDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more User_asset_accesses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_asset_accessUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many User_asset_accesses
     * const user_asset_access = await prisma.user_asset_access.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends user_asset_accessUpdateManyArgs>(args: SelectSubset<T, user_asset_accessUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more User_asset_accesses and returns the data updated in the database.
     * @param {user_asset_accessUpdateManyAndReturnArgs} args - Arguments to update many User_asset_accesses.
     * @example
     * // Update many User_asset_accesses
     * const user_asset_access = await prisma.user_asset_access.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more User_asset_accesses and only return the `user_id`
     * const user_asset_accessWithUser_idOnly = await prisma.user_asset_access.updateManyAndReturn({
     *   select: { user_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends user_asset_accessUpdateManyAndReturnArgs>(args: SelectSubset<T, user_asset_accessUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User_asset_access.
     * @param {user_asset_accessUpsertArgs} args - Arguments to update or create a User_asset_access.
     * @example
     * // Update or create a User_asset_access
     * const user_asset_access = await prisma.user_asset_access.upsert({
     *   create: {
     *     // ... data to create a User_asset_access
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User_asset_access we want to update
     *   }
     * })
     */
    upsert<T extends user_asset_accessUpsertArgs>(args: SelectSubset<T, user_asset_accessUpsertArgs<ExtArgs>>): Prisma__user_asset_accessClient<$Result.GetResult<Prisma.$user_asset_accessPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of User_asset_accesses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_asset_accessCountArgs} args - Arguments to filter User_asset_accesses to count.
     * @example
     * // Count the number of User_asset_accesses
     * const count = await prisma.user_asset_access.count({
     *   where: {
     *     // ... the filter for the User_asset_accesses we want to count
     *   }
     * })
    **/
    count<T extends user_asset_accessCountArgs>(
      args?: Subset<T, user_asset_accessCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], User_asset_accessCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User_asset_access.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {User_asset_accessAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends User_asset_accessAggregateArgs>(args: Subset<T, User_asset_accessAggregateArgs>): Prisma.PrismaPromise<GetUser_asset_accessAggregateType<T>>

    /**
     * Group by User_asset_access.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_asset_accessGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends user_asset_accessGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: user_asset_accessGroupByArgs['orderBy'] }
        : { orderBy?: user_asset_accessGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, user_asset_accessGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUser_asset_accessGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the user_asset_access model
   */
  readonly fields: user_asset_accessFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for user_asset_access.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__user_asset_accessClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    assets<T extends assetsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, assetsDefaultArgs<ExtArgs>>): Prisma__assetsClient<$Result.GetResult<Prisma.$assetsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    users<T extends usersDefaultArgs<ExtArgs> = {}>(args?: Subset<T, usersDefaultArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the user_asset_access model
   */
  interface user_asset_accessFieldRefs {
    readonly user_id: FieldRef<"user_asset_access", 'BigInt'>
    readonly asset_id: FieldRef<"user_asset_access", 'BigInt'>
    readonly is_allowed: FieldRef<"user_asset_access", 'Boolean'>
  }
    

  // Custom InputTypes
  /**
   * user_asset_access findUnique
   */
  export type user_asset_accessFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_asset_access to fetch.
     */
    where: user_asset_accessWhereUniqueInput
  }

  /**
   * user_asset_access findUniqueOrThrow
   */
  export type user_asset_accessFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_asset_access to fetch.
     */
    where: user_asset_accessWhereUniqueInput
  }

  /**
   * user_asset_access findFirst
   */
  export type user_asset_accessFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_asset_access to fetch.
     */
    where?: user_asset_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_asset_accesses to fetch.
     */
    orderBy?: user_asset_accessOrderByWithRelationInput | user_asset_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for user_asset_accesses.
     */
    cursor?: user_asset_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_asset_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_asset_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of user_asset_accesses.
     */
    distinct?: User_asset_accessScalarFieldEnum | User_asset_accessScalarFieldEnum[]
  }

  /**
   * user_asset_access findFirstOrThrow
   */
  export type user_asset_accessFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_asset_access to fetch.
     */
    where?: user_asset_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_asset_accesses to fetch.
     */
    orderBy?: user_asset_accessOrderByWithRelationInput | user_asset_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for user_asset_accesses.
     */
    cursor?: user_asset_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_asset_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_asset_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of user_asset_accesses.
     */
    distinct?: User_asset_accessScalarFieldEnum | User_asset_accessScalarFieldEnum[]
  }

  /**
   * user_asset_access findMany
   */
  export type user_asset_accessFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_asset_accesses to fetch.
     */
    where?: user_asset_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_asset_accesses to fetch.
     */
    orderBy?: user_asset_accessOrderByWithRelationInput | user_asset_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing user_asset_accesses.
     */
    cursor?: user_asset_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_asset_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_asset_accesses.
     */
    skip?: number
    distinct?: User_asset_accessScalarFieldEnum | User_asset_accessScalarFieldEnum[]
  }

  /**
   * user_asset_access create
   */
  export type user_asset_accessCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * The data needed to create a user_asset_access.
     */
    data: XOR<user_asset_accessCreateInput, user_asset_accessUncheckedCreateInput>
  }

  /**
   * user_asset_access createMany
   */
  export type user_asset_accessCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many user_asset_accesses.
     */
    data: user_asset_accessCreateManyInput | user_asset_accessCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * user_asset_access createManyAndReturn
   */
  export type user_asset_accessCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * The data used to create many user_asset_accesses.
     */
    data: user_asset_accessCreateManyInput | user_asset_accessCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * user_asset_access update
   */
  export type user_asset_accessUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * The data needed to update a user_asset_access.
     */
    data: XOR<user_asset_accessUpdateInput, user_asset_accessUncheckedUpdateInput>
    /**
     * Choose, which user_asset_access to update.
     */
    where: user_asset_accessWhereUniqueInput
  }

  /**
   * user_asset_access updateMany
   */
  export type user_asset_accessUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update user_asset_accesses.
     */
    data: XOR<user_asset_accessUpdateManyMutationInput, user_asset_accessUncheckedUpdateManyInput>
    /**
     * Filter which user_asset_accesses to update
     */
    where?: user_asset_accessWhereInput
    /**
     * Limit how many user_asset_accesses to update.
     */
    limit?: number
  }

  /**
   * user_asset_access updateManyAndReturn
   */
  export type user_asset_accessUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * The data used to update user_asset_accesses.
     */
    data: XOR<user_asset_accessUpdateManyMutationInput, user_asset_accessUncheckedUpdateManyInput>
    /**
     * Filter which user_asset_accesses to update
     */
    where?: user_asset_accessWhereInput
    /**
     * Limit how many user_asset_accesses to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * user_asset_access upsert
   */
  export type user_asset_accessUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * The filter to search for the user_asset_access to update in case it exists.
     */
    where: user_asset_accessWhereUniqueInput
    /**
     * In case the user_asset_access found by the `where` argument doesn't exist, create a new user_asset_access with this data.
     */
    create: XOR<user_asset_accessCreateInput, user_asset_accessUncheckedCreateInput>
    /**
     * In case the user_asset_access was found with the provided `where` argument, update it with this data.
     */
    update: XOR<user_asset_accessUpdateInput, user_asset_accessUncheckedUpdateInput>
  }

  /**
   * user_asset_access delete
   */
  export type user_asset_accessDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
    /**
     * Filter which user_asset_access to delete.
     */
    where: user_asset_accessWhereUniqueInput
  }

  /**
   * user_asset_access deleteMany
   */
  export type user_asset_accessDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which user_asset_accesses to delete
     */
    where?: user_asset_accessWhereInput
    /**
     * Limit how many user_asset_accesses to delete.
     */
    limit?: number
  }

  /**
   * user_asset_access without action
   */
  export type user_asset_accessDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_asset_access
     */
    select?: user_asset_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_asset_access
     */
    omit?: user_asset_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_asset_accessInclude<ExtArgs> | null
  }


  /**
   * Model user_device_access
   */

  export type AggregateUser_device_access = {
    _count: User_device_accessCountAggregateOutputType | null
    _avg: User_device_accessAvgAggregateOutputType | null
    _sum: User_device_accessSumAggregateOutputType | null
    _min: User_device_accessMinAggregateOutputType | null
    _max: User_device_accessMaxAggregateOutputType | null
  }

  export type User_device_accessAvgAggregateOutputType = {
    user_id: number | null
    device_id: number | null
  }

  export type User_device_accessSumAggregateOutputType = {
    user_id: bigint | null
    device_id: bigint | null
  }

  export type User_device_accessMinAggregateOutputType = {
    user_id: bigint | null
    device_id: bigint | null
    is_allowed: boolean | null
  }

  export type User_device_accessMaxAggregateOutputType = {
    user_id: bigint | null
    device_id: bigint | null
    is_allowed: boolean | null
  }

  export type User_device_accessCountAggregateOutputType = {
    user_id: number
    device_id: number
    is_allowed: number
    _all: number
  }


  export type User_device_accessAvgAggregateInputType = {
    user_id?: true
    device_id?: true
  }

  export type User_device_accessSumAggregateInputType = {
    user_id?: true
    device_id?: true
  }

  export type User_device_accessMinAggregateInputType = {
    user_id?: true
    device_id?: true
    is_allowed?: true
  }

  export type User_device_accessMaxAggregateInputType = {
    user_id?: true
    device_id?: true
    is_allowed?: true
  }

  export type User_device_accessCountAggregateInputType = {
    user_id?: true
    device_id?: true
    is_allowed?: true
    _all?: true
  }

  export type User_device_accessAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which user_device_access to aggregate.
     */
    where?: user_device_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_device_accesses to fetch.
     */
    orderBy?: user_device_accessOrderByWithRelationInput | user_device_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: user_device_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_device_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_device_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned user_device_accesses
    **/
    _count?: true | User_device_accessCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: User_device_accessAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: User_device_accessSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: User_device_accessMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: User_device_accessMaxAggregateInputType
  }

  export type GetUser_device_accessAggregateType<T extends User_device_accessAggregateArgs> = {
        [P in keyof T & keyof AggregateUser_device_access]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser_device_access[P]>
      : GetScalarType<T[P], AggregateUser_device_access[P]>
  }




  export type user_device_accessGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: user_device_accessWhereInput
    orderBy?: user_device_accessOrderByWithAggregationInput | user_device_accessOrderByWithAggregationInput[]
    by: User_device_accessScalarFieldEnum[] | User_device_accessScalarFieldEnum
    having?: user_device_accessScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: User_device_accessCountAggregateInputType | true
    _avg?: User_device_accessAvgAggregateInputType
    _sum?: User_device_accessSumAggregateInputType
    _min?: User_device_accessMinAggregateInputType
    _max?: User_device_accessMaxAggregateInputType
  }

  export type User_device_accessGroupByOutputType = {
    user_id: bigint
    device_id: bigint
    is_allowed: boolean
    _count: User_device_accessCountAggregateOutputType | null
    _avg: User_device_accessAvgAggregateOutputType | null
    _sum: User_device_accessSumAggregateOutputType | null
    _min: User_device_accessMinAggregateOutputType | null
    _max: User_device_accessMaxAggregateOutputType | null
  }

  type GetUser_device_accessGroupByPayload<T extends user_device_accessGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<User_device_accessGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof User_device_accessGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], User_device_accessGroupByOutputType[P]>
            : GetScalarType<T[P], User_device_accessGroupByOutputType[P]>
        }
      >
    >


  export type user_device_accessSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    device_id?: boolean
    is_allowed?: boolean
    devices?: boolean | devicesDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_device_access"]>

  export type user_device_accessSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    device_id?: boolean
    is_allowed?: boolean
    devices?: boolean | devicesDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_device_access"]>

  export type user_device_accessSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    device_id?: boolean
    is_allowed?: boolean
    devices?: boolean | devicesDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user_device_access"]>

  export type user_device_accessSelectScalar = {
    user_id?: boolean
    device_id?: boolean
    is_allowed?: boolean
  }

  export type user_device_accessOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"user_id" | "device_id" | "is_allowed", ExtArgs["result"]["user_device_access"]>
  export type user_device_accessInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    devices?: boolean | devicesDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }
  export type user_device_accessIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    devices?: boolean | devicesDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }
  export type user_device_accessIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    devices?: boolean | devicesDefaultArgs<ExtArgs>
    users?: boolean | usersDefaultArgs<ExtArgs>
  }

  export type $user_device_accessPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "user_device_access"
    objects: {
      devices: Prisma.$devicesPayload<ExtArgs>
      users: Prisma.$usersPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      user_id: bigint
      device_id: bigint
      is_allowed: boolean
    }, ExtArgs["result"]["user_device_access"]>
    composites: {}
  }

  type user_device_accessGetPayload<S extends boolean | null | undefined | user_device_accessDefaultArgs> = $Result.GetResult<Prisma.$user_device_accessPayload, S>

  type user_device_accessCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<user_device_accessFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: User_device_accessCountAggregateInputType | true
    }

  export interface user_device_accessDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['user_device_access'], meta: { name: 'user_device_access' } }
    /**
     * Find zero or one User_device_access that matches the filter.
     * @param {user_device_accessFindUniqueArgs} args - Arguments to find a User_device_access
     * @example
     * // Get one User_device_access
     * const user_device_access = await prisma.user_device_access.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends user_device_accessFindUniqueArgs>(args: SelectSubset<T, user_device_accessFindUniqueArgs<ExtArgs>>): Prisma__user_device_accessClient<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User_device_access that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {user_device_accessFindUniqueOrThrowArgs} args - Arguments to find a User_device_access
     * @example
     * // Get one User_device_access
     * const user_device_access = await prisma.user_device_access.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends user_device_accessFindUniqueOrThrowArgs>(args: SelectSubset<T, user_device_accessFindUniqueOrThrowArgs<ExtArgs>>): Prisma__user_device_accessClient<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User_device_access that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_device_accessFindFirstArgs} args - Arguments to find a User_device_access
     * @example
     * // Get one User_device_access
     * const user_device_access = await prisma.user_device_access.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends user_device_accessFindFirstArgs>(args?: SelectSubset<T, user_device_accessFindFirstArgs<ExtArgs>>): Prisma__user_device_accessClient<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User_device_access that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_device_accessFindFirstOrThrowArgs} args - Arguments to find a User_device_access
     * @example
     * // Get one User_device_access
     * const user_device_access = await prisma.user_device_access.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends user_device_accessFindFirstOrThrowArgs>(args?: SelectSubset<T, user_device_accessFindFirstOrThrowArgs<ExtArgs>>): Prisma__user_device_accessClient<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more User_device_accesses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_device_accessFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all User_device_accesses
     * const user_device_accesses = await prisma.user_device_access.findMany()
     * 
     * // Get first 10 User_device_accesses
     * const user_device_accesses = await prisma.user_device_access.findMany({ take: 10 })
     * 
     * // Only select the `user_id`
     * const user_device_accessWithUser_idOnly = await prisma.user_device_access.findMany({ select: { user_id: true } })
     * 
     */
    findMany<T extends user_device_accessFindManyArgs>(args?: SelectSubset<T, user_device_accessFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User_device_access.
     * @param {user_device_accessCreateArgs} args - Arguments to create a User_device_access.
     * @example
     * // Create one User_device_access
     * const User_device_access = await prisma.user_device_access.create({
     *   data: {
     *     // ... data to create a User_device_access
     *   }
     * })
     * 
     */
    create<T extends user_device_accessCreateArgs>(args: SelectSubset<T, user_device_accessCreateArgs<ExtArgs>>): Prisma__user_device_accessClient<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many User_device_accesses.
     * @param {user_device_accessCreateManyArgs} args - Arguments to create many User_device_accesses.
     * @example
     * // Create many User_device_accesses
     * const user_device_access = await prisma.user_device_access.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends user_device_accessCreateManyArgs>(args?: SelectSubset<T, user_device_accessCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many User_device_accesses and returns the data saved in the database.
     * @param {user_device_accessCreateManyAndReturnArgs} args - Arguments to create many User_device_accesses.
     * @example
     * // Create many User_device_accesses
     * const user_device_access = await prisma.user_device_access.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many User_device_accesses and only return the `user_id`
     * const user_device_accessWithUser_idOnly = await prisma.user_device_access.createManyAndReturn({
     *   select: { user_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends user_device_accessCreateManyAndReturnArgs>(args?: SelectSubset<T, user_device_accessCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User_device_access.
     * @param {user_device_accessDeleteArgs} args - Arguments to delete one User_device_access.
     * @example
     * // Delete one User_device_access
     * const User_device_access = await prisma.user_device_access.delete({
     *   where: {
     *     // ... filter to delete one User_device_access
     *   }
     * })
     * 
     */
    delete<T extends user_device_accessDeleteArgs>(args: SelectSubset<T, user_device_accessDeleteArgs<ExtArgs>>): Prisma__user_device_accessClient<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User_device_access.
     * @param {user_device_accessUpdateArgs} args - Arguments to update one User_device_access.
     * @example
     * // Update one User_device_access
     * const user_device_access = await prisma.user_device_access.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends user_device_accessUpdateArgs>(args: SelectSubset<T, user_device_accessUpdateArgs<ExtArgs>>): Prisma__user_device_accessClient<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more User_device_accesses.
     * @param {user_device_accessDeleteManyArgs} args - Arguments to filter User_device_accesses to delete.
     * @example
     * // Delete a few User_device_accesses
     * const { count } = await prisma.user_device_access.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends user_device_accessDeleteManyArgs>(args?: SelectSubset<T, user_device_accessDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more User_device_accesses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_device_accessUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many User_device_accesses
     * const user_device_access = await prisma.user_device_access.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends user_device_accessUpdateManyArgs>(args: SelectSubset<T, user_device_accessUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more User_device_accesses and returns the data updated in the database.
     * @param {user_device_accessUpdateManyAndReturnArgs} args - Arguments to update many User_device_accesses.
     * @example
     * // Update many User_device_accesses
     * const user_device_access = await prisma.user_device_access.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more User_device_accesses and only return the `user_id`
     * const user_device_accessWithUser_idOnly = await prisma.user_device_access.updateManyAndReturn({
     *   select: { user_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends user_device_accessUpdateManyAndReturnArgs>(args: SelectSubset<T, user_device_accessUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User_device_access.
     * @param {user_device_accessUpsertArgs} args - Arguments to update or create a User_device_access.
     * @example
     * // Update or create a User_device_access
     * const user_device_access = await prisma.user_device_access.upsert({
     *   create: {
     *     // ... data to create a User_device_access
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User_device_access we want to update
     *   }
     * })
     */
    upsert<T extends user_device_accessUpsertArgs>(args: SelectSubset<T, user_device_accessUpsertArgs<ExtArgs>>): Prisma__user_device_accessClient<$Result.GetResult<Prisma.$user_device_accessPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of User_device_accesses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_device_accessCountArgs} args - Arguments to filter User_device_accesses to count.
     * @example
     * // Count the number of User_device_accesses
     * const count = await prisma.user_device_access.count({
     *   where: {
     *     // ... the filter for the User_device_accesses we want to count
     *   }
     * })
    **/
    count<T extends user_device_accessCountArgs>(
      args?: Subset<T, user_device_accessCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], User_device_accessCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User_device_access.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {User_device_accessAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends User_device_accessAggregateArgs>(args: Subset<T, User_device_accessAggregateArgs>): Prisma.PrismaPromise<GetUser_device_accessAggregateType<T>>

    /**
     * Group by User_device_access.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {user_device_accessGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends user_device_accessGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: user_device_accessGroupByArgs['orderBy'] }
        : { orderBy?: user_device_accessGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, user_device_accessGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUser_device_accessGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the user_device_access model
   */
  readonly fields: user_device_accessFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for user_device_access.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__user_device_accessClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    devices<T extends devicesDefaultArgs<ExtArgs> = {}>(args?: Subset<T, devicesDefaultArgs<ExtArgs>>): Prisma__devicesClient<$Result.GetResult<Prisma.$devicesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    users<T extends usersDefaultArgs<ExtArgs> = {}>(args?: Subset<T, usersDefaultArgs<ExtArgs>>): Prisma__usersClient<$Result.GetResult<Prisma.$usersPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the user_device_access model
   */
  interface user_device_accessFieldRefs {
    readonly user_id: FieldRef<"user_device_access", 'BigInt'>
    readonly device_id: FieldRef<"user_device_access", 'BigInt'>
    readonly is_allowed: FieldRef<"user_device_access", 'Boolean'>
  }
    

  // Custom InputTypes
  /**
   * user_device_access findUnique
   */
  export type user_device_accessFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_device_access to fetch.
     */
    where: user_device_accessWhereUniqueInput
  }

  /**
   * user_device_access findUniqueOrThrow
   */
  export type user_device_accessFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_device_access to fetch.
     */
    where: user_device_accessWhereUniqueInput
  }

  /**
   * user_device_access findFirst
   */
  export type user_device_accessFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_device_access to fetch.
     */
    where?: user_device_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_device_accesses to fetch.
     */
    orderBy?: user_device_accessOrderByWithRelationInput | user_device_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for user_device_accesses.
     */
    cursor?: user_device_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_device_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_device_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of user_device_accesses.
     */
    distinct?: User_device_accessScalarFieldEnum | User_device_accessScalarFieldEnum[]
  }

  /**
   * user_device_access findFirstOrThrow
   */
  export type user_device_accessFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_device_access to fetch.
     */
    where?: user_device_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_device_accesses to fetch.
     */
    orderBy?: user_device_accessOrderByWithRelationInput | user_device_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for user_device_accesses.
     */
    cursor?: user_device_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_device_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_device_accesses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of user_device_accesses.
     */
    distinct?: User_device_accessScalarFieldEnum | User_device_accessScalarFieldEnum[]
  }

  /**
   * user_device_access findMany
   */
  export type user_device_accessFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * Filter, which user_device_accesses to fetch.
     */
    where?: user_device_accessWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of user_device_accesses to fetch.
     */
    orderBy?: user_device_accessOrderByWithRelationInput | user_device_accessOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing user_device_accesses.
     */
    cursor?: user_device_accessWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` user_device_accesses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` user_device_accesses.
     */
    skip?: number
    distinct?: User_device_accessScalarFieldEnum | User_device_accessScalarFieldEnum[]
  }

  /**
   * user_device_access create
   */
  export type user_device_accessCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * The data needed to create a user_device_access.
     */
    data: XOR<user_device_accessCreateInput, user_device_accessUncheckedCreateInput>
  }

  /**
   * user_device_access createMany
   */
  export type user_device_accessCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many user_device_accesses.
     */
    data: user_device_accessCreateManyInput | user_device_accessCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * user_device_access createManyAndReturn
   */
  export type user_device_accessCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * The data used to create many user_device_accesses.
     */
    data: user_device_accessCreateManyInput | user_device_accessCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * user_device_access update
   */
  export type user_device_accessUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * The data needed to update a user_device_access.
     */
    data: XOR<user_device_accessUpdateInput, user_device_accessUncheckedUpdateInput>
    /**
     * Choose, which user_device_access to update.
     */
    where: user_device_accessWhereUniqueInput
  }

  /**
   * user_device_access updateMany
   */
  export type user_device_accessUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update user_device_accesses.
     */
    data: XOR<user_device_accessUpdateManyMutationInput, user_device_accessUncheckedUpdateManyInput>
    /**
     * Filter which user_device_accesses to update
     */
    where?: user_device_accessWhereInput
    /**
     * Limit how many user_device_accesses to update.
     */
    limit?: number
  }

  /**
   * user_device_access updateManyAndReturn
   */
  export type user_device_accessUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * The data used to update user_device_accesses.
     */
    data: XOR<user_device_accessUpdateManyMutationInput, user_device_accessUncheckedUpdateManyInput>
    /**
     * Filter which user_device_accesses to update
     */
    where?: user_device_accessWhereInput
    /**
     * Limit how many user_device_accesses to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * user_device_access upsert
   */
  export type user_device_accessUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * The filter to search for the user_device_access to update in case it exists.
     */
    where: user_device_accessWhereUniqueInput
    /**
     * In case the user_device_access found by the `where` argument doesn't exist, create a new user_device_access with this data.
     */
    create: XOR<user_device_accessCreateInput, user_device_accessUncheckedCreateInput>
    /**
     * In case the user_device_access was found with the provided `where` argument, update it with this data.
     */
    update: XOR<user_device_accessUpdateInput, user_device_accessUncheckedUpdateInput>
  }

  /**
   * user_device_access delete
   */
  export type user_device_accessDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
    /**
     * Filter which user_device_access to delete.
     */
    where: user_device_accessWhereUniqueInput
  }

  /**
   * user_device_access deleteMany
   */
  export type user_device_accessDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which user_device_accesses to delete
     */
    where?: user_device_accessWhereInput
    /**
     * Limit how many user_device_accesses to delete.
     */
    limit?: number
  }

  /**
   * user_device_access without action
   */
  export type user_device_accessDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user_device_access
     */
    select?: user_device_accessSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user_device_access
     */
    omit?: user_device_accessOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: user_device_accessInclude<ExtArgs> | null
  }


  /**
   * Model files
   */

  export type AggregateFiles = {
    _count: FilesCountAggregateOutputType | null
    _avg: FilesAvgAggregateOutputType | null
    _sum: FilesSumAggregateOutputType | null
    _min: FilesMinAggregateOutputType | null
    _max: FilesMaxAggregateOutputType | null
  }

  export type FilesAvgAggregateOutputType = {
    id: number | null
    entity_id: number | null
    size_bytes: number | null
    uploaded_by: number | null
  }

  export type FilesSumAggregateOutputType = {
    id: bigint | null
    entity_id: bigint | null
    size_bytes: bigint | null
    uploaded_by: bigint | null
  }

  export type FilesMinAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    entity_type: string | null
    entity_id: bigint | null
    filename: string | null
    storage_path: string | null
    url: string | null
    mime_type: string | null
    size_bytes: bigint | null
    compressed: boolean | null
    encrypted: boolean | null
    checksum_sha256: string | null
    file_type: string | null
    created_at: Date | null
    uploaded_by: bigint | null
  }

  export type FilesMaxAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    entity_type: string | null
    entity_id: bigint | null
    filename: string | null
    storage_path: string | null
    url: string | null
    mime_type: string | null
    size_bytes: bigint | null
    compressed: boolean | null
    encrypted: boolean | null
    checksum_sha256: string | null
    file_type: string | null
    created_at: Date | null
    uploaded_by: bigint | null
  }

  export type FilesCountAggregateOutputType = {
    id: number
    uuid: number
    entity_type: number
    entity_id: number
    filename: number
    storage_path: number
    url: number
    mime_type: number
    size_bytes: number
    compressed: number
    encrypted: number
    checksum_sha256: number
    file_type: number
    attributes: number
    created_at: number
    uploaded_by: number
    _all: number
  }


  export type FilesAvgAggregateInputType = {
    id?: true
    entity_id?: true
    size_bytes?: true
    uploaded_by?: true
  }

  export type FilesSumAggregateInputType = {
    id?: true
    entity_id?: true
    size_bytes?: true
    uploaded_by?: true
  }

  export type FilesMinAggregateInputType = {
    id?: true
    uuid?: true
    entity_type?: true
    entity_id?: true
    filename?: true
    storage_path?: true
    url?: true
    mime_type?: true
    size_bytes?: true
    compressed?: true
    encrypted?: true
    checksum_sha256?: true
    file_type?: true
    created_at?: true
    uploaded_by?: true
  }

  export type FilesMaxAggregateInputType = {
    id?: true
    uuid?: true
    entity_type?: true
    entity_id?: true
    filename?: true
    storage_path?: true
    url?: true
    mime_type?: true
    size_bytes?: true
    compressed?: true
    encrypted?: true
    checksum_sha256?: true
    file_type?: true
    created_at?: true
    uploaded_by?: true
  }

  export type FilesCountAggregateInputType = {
    id?: true
    uuid?: true
    entity_type?: true
    entity_id?: true
    filename?: true
    storage_path?: true
    url?: true
    mime_type?: true
    size_bytes?: true
    compressed?: true
    encrypted?: true
    checksum_sha256?: true
    file_type?: true
    attributes?: true
    created_at?: true
    uploaded_by?: true
    _all?: true
  }

  export type FilesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which files to aggregate.
     */
    where?: filesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of files to fetch.
     */
    orderBy?: filesOrderByWithRelationInput | filesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: filesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned files
    **/
    _count?: true | FilesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: FilesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: FilesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: FilesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: FilesMaxAggregateInputType
  }

  export type GetFilesAggregateType<T extends FilesAggregateArgs> = {
        [P in keyof T & keyof AggregateFiles]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateFiles[P]>
      : GetScalarType<T[P], AggregateFiles[P]>
  }




  export type filesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: filesWhereInput
    orderBy?: filesOrderByWithAggregationInput | filesOrderByWithAggregationInput[]
    by: FilesScalarFieldEnum[] | FilesScalarFieldEnum
    having?: filesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: FilesCountAggregateInputType | true
    _avg?: FilesAvgAggregateInputType
    _sum?: FilesSumAggregateInputType
    _min?: FilesMinAggregateInputType
    _max?: FilesMaxAggregateInputType
  }

  export type FilesGroupByOutputType = {
    id: bigint
    uuid: string | null
    entity_type: string
    entity_id: bigint
    filename: string
    storage_path: string
    url: string | null
    mime_type: string
    size_bytes: bigint | null
    compressed: boolean
    encrypted: boolean
    checksum_sha256: string | null
    file_type: string | null
    attributes: JsonValue
    created_at: Date
    uploaded_by: bigint | null
    _count: FilesCountAggregateOutputType | null
    _avg: FilesAvgAggregateOutputType | null
    _sum: FilesSumAggregateOutputType | null
    _min: FilesMinAggregateOutputType | null
    _max: FilesMaxAggregateOutputType | null
  }

  type GetFilesGroupByPayload<T extends filesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<FilesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof FilesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], FilesGroupByOutputType[P]>
            : GetScalarType<T[P], FilesGroupByOutputType[P]>
        }
      >
    >


  export type filesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    entity_type?: boolean
    entity_id?: boolean
    filename?: boolean
    storage_path?: boolean
    url?: boolean
    mime_type?: boolean
    size_bytes?: boolean
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: boolean
    file_type?: boolean
    attributes?: boolean
    created_at?: boolean
    uploaded_by?: boolean
  }, ExtArgs["result"]["files"]>

  export type filesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    entity_type?: boolean
    entity_id?: boolean
    filename?: boolean
    storage_path?: boolean
    url?: boolean
    mime_type?: boolean
    size_bytes?: boolean
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: boolean
    file_type?: boolean
    attributes?: boolean
    created_at?: boolean
    uploaded_by?: boolean
  }, ExtArgs["result"]["files"]>

  export type filesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    entity_type?: boolean
    entity_id?: boolean
    filename?: boolean
    storage_path?: boolean
    url?: boolean
    mime_type?: boolean
    size_bytes?: boolean
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: boolean
    file_type?: boolean
    attributes?: boolean
    created_at?: boolean
    uploaded_by?: boolean
  }, ExtArgs["result"]["files"]>

  export type filesSelectScalar = {
    id?: boolean
    uuid?: boolean
    entity_type?: boolean
    entity_id?: boolean
    filename?: boolean
    storage_path?: boolean
    url?: boolean
    mime_type?: boolean
    size_bytes?: boolean
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: boolean
    file_type?: boolean
    attributes?: boolean
    created_at?: boolean
    uploaded_by?: boolean
  }

  export type filesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "uuid" | "entity_type" | "entity_id" | "filename" | "storage_path" | "url" | "mime_type" | "size_bytes" | "compressed" | "encrypted" | "checksum_sha256" | "file_type" | "attributes" | "created_at" | "uploaded_by", ExtArgs["result"]["files"]>

  export type $filesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "files"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      uuid: string | null
      entity_type: string
      entity_id: bigint
      filename: string
      storage_path: string
      url: string | null
      mime_type: string
      size_bytes: bigint | null
      compressed: boolean
      encrypted: boolean
      checksum_sha256: string | null
      file_type: string | null
      attributes: Prisma.JsonValue
      created_at: Date
      uploaded_by: bigint | null
    }, ExtArgs["result"]["files"]>
    composites: {}
  }

  type filesGetPayload<S extends boolean | null | undefined | filesDefaultArgs> = $Result.GetResult<Prisma.$filesPayload, S>

  type filesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<filesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: FilesCountAggregateInputType | true
    }

  export interface filesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['files'], meta: { name: 'files' } }
    /**
     * Find zero or one Files that matches the filter.
     * @param {filesFindUniqueArgs} args - Arguments to find a Files
     * @example
     * // Get one Files
     * const files = await prisma.files.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends filesFindUniqueArgs>(args: SelectSubset<T, filesFindUniqueArgs<ExtArgs>>): Prisma__filesClient<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Files that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {filesFindUniqueOrThrowArgs} args - Arguments to find a Files
     * @example
     * // Get one Files
     * const files = await prisma.files.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends filesFindUniqueOrThrowArgs>(args: SelectSubset<T, filesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__filesClient<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Files that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {filesFindFirstArgs} args - Arguments to find a Files
     * @example
     * // Get one Files
     * const files = await prisma.files.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends filesFindFirstArgs>(args?: SelectSubset<T, filesFindFirstArgs<ExtArgs>>): Prisma__filesClient<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Files that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {filesFindFirstOrThrowArgs} args - Arguments to find a Files
     * @example
     * // Get one Files
     * const files = await prisma.files.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends filesFindFirstOrThrowArgs>(args?: SelectSubset<T, filesFindFirstOrThrowArgs<ExtArgs>>): Prisma__filesClient<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Files that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {filesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Files
     * const files = await prisma.files.findMany()
     * 
     * // Get first 10 Files
     * const files = await prisma.files.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const filesWithIdOnly = await prisma.files.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends filesFindManyArgs>(args?: SelectSubset<T, filesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Files.
     * @param {filesCreateArgs} args - Arguments to create a Files.
     * @example
     * // Create one Files
     * const Files = await prisma.files.create({
     *   data: {
     *     // ... data to create a Files
     *   }
     * })
     * 
     */
    create<T extends filesCreateArgs>(args: SelectSubset<T, filesCreateArgs<ExtArgs>>): Prisma__filesClient<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Files.
     * @param {filesCreateManyArgs} args - Arguments to create many Files.
     * @example
     * // Create many Files
     * const files = await prisma.files.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends filesCreateManyArgs>(args?: SelectSubset<T, filesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Files and returns the data saved in the database.
     * @param {filesCreateManyAndReturnArgs} args - Arguments to create many Files.
     * @example
     * // Create many Files
     * const files = await prisma.files.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Files and only return the `id`
     * const filesWithIdOnly = await prisma.files.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends filesCreateManyAndReturnArgs>(args?: SelectSubset<T, filesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Files.
     * @param {filesDeleteArgs} args - Arguments to delete one Files.
     * @example
     * // Delete one Files
     * const Files = await prisma.files.delete({
     *   where: {
     *     // ... filter to delete one Files
     *   }
     * })
     * 
     */
    delete<T extends filesDeleteArgs>(args: SelectSubset<T, filesDeleteArgs<ExtArgs>>): Prisma__filesClient<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Files.
     * @param {filesUpdateArgs} args - Arguments to update one Files.
     * @example
     * // Update one Files
     * const files = await prisma.files.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends filesUpdateArgs>(args: SelectSubset<T, filesUpdateArgs<ExtArgs>>): Prisma__filesClient<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Files.
     * @param {filesDeleteManyArgs} args - Arguments to filter Files to delete.
     * @example
     * // Delete a few Files
     * const { count } = await prisma.files.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends filesDeleteManyArgs>(args?: SelectSubset<T, filesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Files.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {filesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Files
     * const files = await prisma.files.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends filesUpdateManyArgs>(args: SelectSubset<T, filesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Files and returns the data updated in the database.
     * @param {filesUpdateManyAndReturnArgs} args - Arguments to update many Files.
     * @example
     * // Update many Files
     * const files = await prisma.files.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Files and only return the `id`
     * const filesWithIdOnly = await prisma.files.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends filesUpdateManyAndReturnArgs>(args: SelectSubset<T, filesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Files.
     * @param {filesUpsertArgs} args - Arguments to update or create a Files.
     * @example
     * // Update or create a Files
     * const files = await prisma.files.upsert({
     *   create: {
     *     // ... data to create a Files
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Files we want to update
     *   }
     * })
     */
    upsert<T extends filesUpsertArgs>(args: SelectSubset<T, filesUpsertArgs<ExtArgs>>): Prisma__filesClient<$Result.GetResult<Prisma.$filesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Files.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {filesCountArgs} args - Arguments to filter Files to count.
     * @example
     * // Count the number of Files
     * const count = await prisma.files.count({
     *   where: {
     *     // ... the filter for the Files we want to count
     *   }
     * })
    **/
    count<T extends filesCountArgs>(
      args?: Subset<T, filesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], FilesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Files.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FilesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends FilesAggregateArgs>(args: Subset<T, FilesAggregateArgs>): Prisma.PrismaPromise<GetFilesAggregateType<T>>

    /**
     * Group by Files.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {filesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends filesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: filesGroupByArgs['orderBy'] }
        : { orderBy?: filesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, filesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFilesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the files model
   */
  readonly fields: filesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for files.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__filesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the files model
   */
  interface filesFieldRefs {
    readonly id: FieldRef<"files", 'BigInt'>
    readonly uuid: FieldRef<"files", 'String'>
    readonly entity_type: FieldRef<"files", 'String'>
    readonly entity_id: FieldRef<"files", 'BigInt'>
    readonly filename: FieldRef<"files", 'String'>
    readonly storage_path: FieldRef<"files", 'String'>
    readonly url: FieldRef<"files", 'String'>
    readonly mime_type: FieldRef<"files", 'String'>
    readonly size_bytes: FieldRef<"files", 'BigInt'>
    readonly compressed: FieldRef<"files", 'Boolean'>
    readonly encrypted: FieldRef<"files", 'Boolean'>
    readonly checksum_sha256: FieldRef<"files", 'String'>
    readonly file_type: FieldRef<"files", 'String'>
    readonly attributes: FieldRef<"files", 'Json'>
    readonly created_at: FieldRef<"files", 'DateTime'>
    readonly uploaded_by: FieldRef<"files", 'BigInt'>
  }
    

  // Custom InputTypes
  /**
   * files findUnique
   */
  export type filesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * Filter, which files to fetch.
     */
    where: filesWhereUniqueInput
  }

  /**
   * files findUniqueOrThrow
   */
  export type filesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * Filter, which files to fetch.
     */
    where: filesWhereUniqueInput
  }

  /**
   * files findFirst
   */
  export type filesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * Filter, which files to fetch.
     */
    where?: filesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of files to fetch.
     */
    orderBy?: filesOrderByWithRelationInput | filesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for files.
     */
    cursor?: filesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of files.
     */
    distinct?: FilesScalarFieldEnum | FilesScalarFieldEnum[]
  }

  /**
   * files findFirstOrThrow
   */
  export type filesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * Filter, which files to fetch.
     */
    where?: filesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of files to fetch.
     */
    orderBy?: filesOrderByWithRelationInput | filesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for files.
     */
    cursor?: filesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of files.
     */
    distinct?: FilesScalarFieldEnum | FilesScalarFieldEnum[]
  }

  /**
   * files findMany
   */
  export type filesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * Filter, which files to fetch.
     */
    where?: filesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of files to fetch.
     */
    orderBy?: filesOrderByWithRelationInput | filesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing files.
     */
    cursor?: filesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` files.
     */
    skip?: number
    distinct?: FilesScalarFieldEnum | FilesScalarFieldEnum[]
  }

  /**
   * files create
   */
  export type filesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * The data needed to create a files.
     */
    data: XOR<filesCreateInput, filesUncheckedCreateInput>
  }

  /**
   * files createMany
   */
  export type filesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many files.
     */
    data: filesCreateManyInput | filesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * files createManyAndReturn
   */
  export type filesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * The data used to create many files.
     */
    data: filesCreateManyInput | filesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * files update
   */
  export type filesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * The data needed to update a files.
     */
    data: XOR<filesUpdateInput, filesUncheckedUpdateInput>
    /**
     * Choose, which files to update.
     */
    where: filesWhereUniqueInput
  }

  /**
   * files updateMany
   */
  export type filesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update files.
     */
    data: XOR<filesUpdateManyMutationInput, filesUncheckedUpdateManyInput>
    /**
     * Filter which files to update
     */
    where?: filesWhereInput
    /**
     * Limit how many files to update.
     */
    limit?: number
  }

  /**
   * files updateManyAndReturn
   */
  export type filesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * The data used to update files.
     */
    data: XOR<filesUpdateManyMutationInput, filesUncheckedUpdateManyInput>
    /**
     * Filter which files to update
     */
    where?: filesWhereInput
    /**
     * Limit how many files to update.
     */
    limit?: number
  }

  /**
   * files upsert
   */
  export type filesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * The filter to search for the files to update in case it exists.
     */
    where: filesWhereUniqueInput
    /**
     * In case the files found by the `where` argument doesn't exist, create a new files with this data.
     */
    create: XOR<filesCreateInput, filesUncheckedCreateInput>
    /**
     * In case the files was found with the provided `where` argument, update it with this data.
     */
    update: XOR<filesUpdateInput, filesUncheckedUpdateInput>
  }

  /**
   * files delete
   */
  export type filesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
    /**
     * Filter which files to delete.
     */
    where: filesWhereUniqueInput
  }

  /**
   * files deleteMany
   */
  export type filesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which files to delete
     */
    where?: filesWhereInput
    /**
     * Limit how many files to delete.
     */
    limit?: number
  }

  /**
   * files without action
   */
  export type filesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the files
     */
    select?: filesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the files
     */
    omit?: filesOmit<ExtArgs> | null
  }


  /**
   * Model images
   */

  export type AggregateImages = {
    _count: ImagesCountAggregateOutputType | null
    _avg: ImagesAvgAggregateOutputType | null
    _sum: ImagesSumAggregateOutputType | null
    _min: ImagesMinAggregateOutputType | null
    _max: ImagesMaxAggregateOutputType | null
  }

  export type ImagesAvgAggregateOutputType = {
    id: number | null
    entity_id: number | null
    width_px: number | null
    height_px: number | null
    size_bytes: number | null
    uploaded_by: number | null
  }

  export type ImagesSumAggregateOutputType = {
    id: bigint | null
    entity_id: bigint | null
    width_px: number | null
    height_px: number | null
    size_bytes: bigint | null
    uploaded_by: bigint | null
  }

  export type ImagesMinAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    entity_type: string | null
    entity_id: bigint | null
    filename: string | null
    storage_path: string | null
    url: string | null
    mime_type: string | null
    width_px: number | null
    height_px: number | null
    size_bytes: bigint | null
    compressed: boolean | null
    encrypted: boolean | null
    checksum_sha256: string | null
    is_primary: boolean | null
    created_at: Date | null
    uploaded_by: bigint | null
  }

  export type ImagesMaxAggregateOutputType = {
    id: bigint | null
    uuid: string | null
    entity_type: string | null
    entity_id: bigint | null
    filename: string | null
    storage_path: string | null
    url: string | null
    mime_type: string | null
    width_px: number | null
    height_px: number | null
    size_bytes: bigint | null
    compressed: boolean | null
    encrypted: boolean | null
    checksum_sha256: string | null
    is_primary: boolean | null
    created_at: Date | null
    uploaded_by: bigint | null
  }

  export type ImagesCountAggregateOutputType = {
    id: number
    uuid: number
    entity_type: number
    entity_id: number
    filename: number
    storage_path: number
    url: number
    mime_type: number
    width_px: number
    height_px: number
    size_bytes: number
    compressed: number
    encrypted: number
    checksum_sha256: number
    is_primary: number
    tags: number
    attributes: number
    created_at: number
    uploaded_by: number
    _all: number
  }


  export type ImagesAvgAggregateInputType = {
    id?: true
    entity_id?: true
    width_px?: true
    height_px?: true
    size_bytes?: true
    uploaded_by?: true
  }

  export type ImagesSumAggregateInputType = {
    id?: true
    entity_id?: true
    width_px?: true
    height_px?: true
    size_bytes?: true
    uploaded_by?: true
  }

  export type ImagesMinAggregateInputType = {
    id?: true
    uuid?: true
    entity_type?: true
    entity_id?: true
    filename?: true
    storage_path?: true
    url?: true
    mime_type?: true
    width_px?: true
    height_px?: true
    size_bytes?: true
    compressed?: true
    encrypted?: true
    checksum_sha256?: true
    is_primary?: true
    created_at?: true
    uploaded_by?: true
  }

  export type ImagesMaxAggregateInputType = {
    id?: true
    uuid?: true
    entity_type?: true
    entity_id?: true
    filename?: true
    storage_path?: true
    url?: true
    mime_type?: true
    width_px?: true
    height_px?: true
    size_bytes?: true
    compressed?: true
    encrypted?: true
    checksum_sha256?: true
    is_primary?: true
    created_at?: true
    uploaded_by?: true
  }

  export type ImagesCountAggregateInputType = {
    id?: true
    uuid?: true
    entity_type?: true
    entity_id?: true
    filename?: true
    storage_path?: true
    url?: true
    mime_type?: true
    width_px?: true
    height_px?: true
    size_bytes?: true
    compressed?: true
    encrypted?: true
    checksum_sha256?: true
    is_primary?: true
    tags?: true
    attributes?: true
    created_at?: true
    uploaded_by?: true
    _all?: true
  }

  export type ImagesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which images to aggregate.
     */
    where?: imagesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of images to fetch.
     */
    orderBy?: imagesOrderByWithRelationInput | imagesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: imagesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` images from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` images.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned images
    **/
    _count?: true | ImagesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ImagesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ImagesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ImagesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ImagesMaxAggregateInputType
  }

  export type GetImagesAggregateType<T extends ImagesAggregateArgs> = {
        [P in keyof T & keyof AggregateImages]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateImages[P]>
      : GetScalarType<T[P], AggregateImages[P]>
  }




  export type imagesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: imagesWhereInput
    orderBy?: imagesOrderByWithAggregationInput | imagesOrderByWithAggregationInput[]
    by: ImagesScalarFieldEnum[] | ImagesScalarFieldEnum
    having?: imagesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ImagesCountAggregateInputType | true
    _avg?: ImagesAvgAggregateInputType
    _sum?: ImagesSumAggregateInputType
    _min?: ImagesMinAggregateInputType
    _max?: ImagesMaxAggregateInputType
  }

  export type ImagesGroupByOutputType = {
    id: bigint
    uuid: string | null
    entity_type: string
    entity_id: bigint
    filename: string
    storage_path: string
    url: string | null
    mime_type: string
    width_px: number | null
    height_px: number | null
    size_bytes: bigint | null
    compressed: boolean
    encrypted: boolean
    checksum_sha256: string | null
    is_primary: boolean
    tags: string[]
    attributes: JsonValue
    created_at: Date
    uploaded_by: bigint | null
    _count: ImagesCountAggregateOutputType | null
    _avg: ImagesAvgAggregateOutputType | null
    _sum: ImagesSumAggregateOutputType | null
    _min: ImagesMinAggregateOutputType | null
    _max: ImagesMaxAggregateOutputType | null
  }

  type GetImagesGroupByPayload<T extends imagesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ImagesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ImagesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ImagesGroupByOutputType[P]>
            : GetScalarType<T[P], ImagesGroupByOutputType[P]>
        }
      >
    >


  export type imagesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    entity_type?: boolean
    entity_id?: boolean
    filename?: boolean
    storage_path?: boolean
    url?: boolean
    mime_type?: boolean
    width_px?: boolean
    height_px?: boolean
    size_bytes?: boolean
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: boolean
    is_primary?: boolean
    tags?: boolean
    attributes?: boolean
    created_at?: boolean
    uploaded_by?: boolean
  }, ExtArgs["result"]["images"]>

  export type imagesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    entity_type?: boolean
    entity_id?: boolean
    filename?: boolean
    storage_path?: boolean
    url?: boolean
    mime_type?: boolean
    width_px?: boolean
    height_px?: boolean
    size_bytes?: boolean
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: boolean
    is_primary?: boolean
    tags?: boolean
    attributes?: boolean
    created_at?: boolean
    uploaded_by?: boolean
  }, ExtArgs["result"]["images"]>

  export type imagesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    uuid?: boolean
    entity_type?: boolean
    entity_id?: boolean
    filename?: boolean
    storage_path?: boolean
    url?: boolean
    mime_type?: boolean
    width_px?: boolean
    height_px?: boolean
    size_bytes?: boolean
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: boolean
    is_primary?: boolean
    tags?: boolean
    attributes?: boolean
    created_at?: boolean
    uploaded_by?: boolean
  }, ExtArgs["result"]["images"]>

  export type imagesSelectScalar = {
    id?: boolean
    uuid?: boolean
    entity_type?: boolean
    entity_id?: boolean
    filename?: boolean
    storage_path?: boolean
    url?: boolean
    mime_type?: boolean
    width_px?: boolean
    height_px?: boolean
    size_bytes?: boolean
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: boolean
    is_primary?: boolean
    tags?: boolean
    attributes?: boolean
    created_at?: boolean
    uploaded_by?: boolean
  }

  export type imagesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "uuid" | "entity_type" | "entity_id" | "filename" | "storage_path" | "url" | "mime_type" | "width_px" | "height_px" | "size_bytes" | "compressed" | "encrypted" | "checksum_sha256" | "is_primary" | "tags" | "attributes" | "created_at" | "uploaded_by", ExtArgs["result"]["images"]>

  export type $imagesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "images"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: bigint
      uuid: string | null
      entity_type: string
      entity_id: bigint
      filename: string
      storage_path: string
      url: string | null
      mime_type: string
      width_px: number | null
      height_px: number | null
      size_bytes: bigint | null
      compressed: boolean
      encrypted: boolean
      checksum_sha256: string | null
      is_primary: boolean
      tags: string[]
      attributes: Prisma.JsonValue
      created_at: Date
      uploaded_by: bigint | null
    }, ExtArgs["result"]["images"]>
    composites: {}
  }

  type imagesGetPayload<S extends boolean | null | undefined | imagesDefaultArgs> = $Result.GetResult<Prisma.$imagesPayload, S>

  type imagesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<imagesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ImagesCountAggregateInputType | true
    }

  export interface imagesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['images'], meta: { name: 'images' } }
    /**
     * Find zero or one Images that matches the filter.
     * @param {imagesFindUniqueArgs} args - Arguments to find a Images
     * @example
     * // Get one Images
     * const images = await prisma.images.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends imagesFindUniqueArgs>(args: SelectSubset<T, imagesFindUniqueArgs<ExtArgs>>): Prisma__imagesClient<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Images that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {imagesFindUniqueOrThrowArgs} args - Arguments to find a Images
     * @example
     * // Get one Images
     * const images = await prisma.images.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends imagesFindUniqueOrThrowArgs>(args: SelectSubset<T, imagesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__imagesClient<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Images that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imagesFindFirstArgs} args - Arguments to find a Images
     * @example
     * // Get one Images
     * const images = await prisma.images.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends imagesFindFirstArgs>(args?: SelectSubset<T, imagesFindFirstArgs<ExtArgs>>): Prisma__imagesClient<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Images that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imagesFindFirstOrThrowArgs} args - Arguments to find a Images
     * @example
     * // Get one Images
     * const images = await prisma.images.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends imagesFindFirstOrThrowArgs>(args?: SelectSubset<T, imagesFindFirstOrThrowArgs<ExtArgs>>): Prisma__imagesClient<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Images that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imagesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Images
     * const images = await prisma.images.findMany()
     * 
     * // Get first 10 Images
     * const images = await prisma.images.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const imagesWithIdOnly = await prisma.images.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends imagesFindManyArgs>(args?: SelectSubset<T, imagesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Images.
     * @param {imagesCreateArgs} args - Arguments to create a Images.
     * @example
     * // Create one Images
     * const Images = await prisma.images.create({
     *   data: {
     *     // ... data to create a Images
     *   }
     * })
     * 
     */
    create<T extends imagesCreateArgs>(args: SelectSubset<T, imagesCreateArgs<ExtArgs>>): Prisma__imagesClient<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Images.
     * @param {imagesCreateManyArgs} args - Arguments to create many Images.
     * @example
     * // Create many Images
     * const images = await prisma.images.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends imagesCreateManyArgs>(args?: SelectSubset<T, imagesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Images and returns the data saved in the database.
     * @param {imagesCreateManyAndReturnArgs} args - Arguments to create many Images.
     * @example
     * // Create many Images
     * const images = await prisma.images.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Images and only return the `id`
     * const imagesWithIdOnly = await prisma.images.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends imagesCreateManyAndReturnArgs>(args?: SelectSubset<T, imagesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Images.
     * @param {imagesDeleteArgs} args - Arguments to delete one Images.
     * @example
     * // Delete one Images
     * const Images = await prisma.images.delete({
     *   where: {
     *     // ... filter to delete one Images
     *   }
     * })
     * 
     */
    delete<T extends imagesDeleteArgs>(args: SelectSubset<T, imagesDeleteArgs<ExtArgs>>): Prisma__imagesClient<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Images.
     * @param {imagesUpdateArgs} args - Arguments to update one Images.
     * @example
     * // Update one Images
     * const images = await prisma.images.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends imagesUpdateArgs>(args: SelectSubset<T, imagesUpdateArgs<ExtArgs>>): Prisma__imagesClient<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Images.
     * @param {imagesDeleteManyArgs} args - Arguments to filter Images to delete.
     * @example
     * // Delete a few Images
     * const { count } = await prisma.images.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends imagesDeleteManyArgs>(args?: SelectSubset<T, imagesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Images.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imagesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Images
     * const images = await prisma.images.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends imagesUpdateManyArgs>(args: SelectSubset<T, imagesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Images and returns the data updated in the database.
     * @param {imagesUpdateManyAndReturnArgs} args - Arguments to update many Images.
     * @example
     * // Update many Images
     * const images = await prisma.images.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Images and only return the `id`
     * const imagesWithIdOnly = await prisma.images.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends imagesUpdateManyAndReturnArgs>(args: SelectSubset<T, imagesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Images.
     * @param {imagesUpsertArgs} args - Arguments to update or create a Images.
     * @example
     * // Update or create a Images
     * const images = await prisma.images.upsert({
     *   create: {
     *     // ... data to create a Images
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Images we want to update
     *   }
     * })
     */
    upsert<T extends imagesUpsertArgs>(args: SelectSubset<T, imagesUpsertArgs<ExtArgs>>): Prisma__imagesClient<$Result.GetResult<Prisma.$imagesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Images.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imagesCountArgs} args - Arguments to filter Images to count.
     * @example
     * // Count the number of Images
     * const count = await prisma.images.count({
     *   where: {
     *     // ... the filter for the Images we want to count
     *   }
     * })
    **/
    count<T extends imagesCountArgs>(
      args?: Subset<T, imagesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ImagesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Images.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ImagesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ImagesAggregateArgs>(args: Subset<T, ImagesAggregateArgs>): Prisma.PrismaPromise<GetImagesAggregateType<T>>

    /**
     * Group by Images.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {imagesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends imagesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: imagesGroupByArgs['orderBy'] }
        : { orderBy?: imagesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, imagesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetImagesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the images model
   */
  readonly fields: imagesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for images.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__imagesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the images model
   */
  interface imagesFieldRefs {
    readonly id: FieldRef<"images", 'BigInt'>
    readonly uuid: FieldRef<"images", 'String'>
    readonly entity_type: FieldRef<"images", 'String'>
    readonly entity_id: FieldRef<"images", 'BigInt'>
    readonly filename: FieldRef<"images", 'String'>
    readonly storage_path: FieldRef<"images", 'String'>
    readonly url: FieldRef<"images", 'String'>
    readonly mime_type: FieldRef<"images", 'String'>
    readonly width_px: FieldRef<"images", 'Int'>
    readonly height_px: FieldRef<"images", 'Int'>
    readonly size_bytes: FieldRef<"images", 'BigInt'>
    readonly compressed: FieldRef<"images", 'Boolean'>
    readonly encrypted: FieldRef<"images", 'Boolean'>
    readonly checksum_sha256: FieldRef<"images", 'String'>
    readonly is_primary: FieldRef<"images", 'Boolean'>
    readonly tags: FieldRef<"images", 'String[]'>
    readonly attributes: FieldRef<"images", 'Json'>
    readonly created_at: FieldRef<"images", 'DateTime'>
    readonly uploaded_by: FieldRef<"images", 'BigInt'>
  }
    

  // Custom InputTypes
  /**
   * images findUnique
   */
  export type imagesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * Filter, which images to fetch.
     */
    where: imagesWhereUniqueInput
  }

  /**
   * images findUniqueOrThrow
   */
  export type imagesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * Filter, which images to fetch.
     */
    where: imagesWhereUniqueInput
  }

  /**
   * images findFirst
   */
  export type imagesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * Filter, which images to fetch.
     */
    where?: imagesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of images to fetch.
     */
    orderBy?: imagesOrderByWithRelationInput | imagesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for images.
     */
    cursor?: imagesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` images from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` images.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of images.
     */
    distinct?: ImagesScalarFieldEnum | ImagesScalarFieldEnum[]
  }

  /**
   * images findFirstOrThrow
   */
  export type imagesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * Filter, which images to fetch.
     */
    where?: imagesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of images to fetch.
     */
    orderBy?: imagesOrderByWithRelationInput | imagesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for images.
     */
    cursor?: imagesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` images from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` images.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of images.
     */
    distinct?: ImagesScalarFieldEnum | ImagesScalarFieldEnum[]
  }

  /**
   * images findMany
   */
  export type imagesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * Filter, which images to fetch.
     */
    where?: imagesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of images to fetch.
     */
    orderBy?: imagesOrderByWithRelationInput | imagesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing images.
     */
    cursor?: imagesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` images from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` images.
     */
    skip?: number
    distinct?: ImagesScalarFieldEnum | ImagesScalarFieldEnum[]
  }

  /**
   * images create
   */
  export type imagesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * The data needed to create a images.
     */
    data: XOR<imagesCreateInput, imagesUncheckedCreateInput>
  }

  /**
   * images createMany
   */
  export type imagesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many images.
     */
    data: imagesCreateManyInput | imagesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * images createManyAndReturn
   */
  export type imagesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * The data used to create many images.
     */
    data: imagesCreateManyInput | imagesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * images update
   */
  export type imagesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * The data needed to update a images.
     */
    data: XOR<imagesUpdateInput, imagesUncheckedUpdateInput>
    /**
     * Choose, which images to update.
     */
    where: imagesWhereUniqueInput
  }

  /**
   * images updateMany
   */
  export type imagesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update images.
     */
    data: XOR<imagesUpdateManyMutationInput, imagesUncheckedUpdateManyInput>
    /**
     * Filter which images to update
     */
    where?: imagesWhereInput
    /**
     * Limit how many images to update.
     */
    limit?: number
  }

  /**
   * images updateManyAndReturn
   */
  export type imagesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * The data used to update images.
     */
    data: XOR<imagesUpdateManyMutationInput, imagesUncheckedUpdateManyInput>
    /**
     * Filter which images to update
     */
    where?: imagesWhereInput
    /**
     * Limit how many images to update.
     */
    limit?: number
  }

  /**
   * images upsert
   */
  export type imagesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * The filter to search for the images to update in case it exists.
     */
    where: imagesWhereUniqueInput
    /**
     * In case the images found by the `where` argument doesn't exist, create a new images with this data.
     */
    create: XOR<imagesCreateInput, imagesUncheckedCreateInput>
    /**
     * In case the images was found with the provided `where` argument, update it with this data.
     */
    update: XOR<imagesUpdateInput, imagesUncheckedUpdateInput>
  }

  /**
   * images delete
   */
  export type imagesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
    /**
     * Filter which images to delete.
     */
    where: imagesWhereUniqueInput
  }

  /**
   * images deleteMany
   */
  export type imagesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which images to delete
     */
    where?: imagesWhereInput
    /**
     * Limit how many images to delete.
     */
    limit?: number
  }

  /**
   * images without action
   */
  export type imagesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the images
     */
    select?: imagesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the images
     */
    omit?: imagesOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const AssetsScalarFieldEnum: {
    id: 'id',
    uuid: 'uuid',
    organisation_id: 'organisation_id',
    name: 'name',
    asset_type: 'asset_type',
    attributes: 'attributes',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type AssetsScalarFieldEnum = (typeof AssetsScalarFieldEnum)[keyof typeof AssetsScalarFieldEnum]


  export const DevicesScalarFieldEnum: {
    id: 'id',
    uuid: 'uuid',
    organisation_id: 'organisation_id',
    asset_id: 'asset_id',
    external_id: 'external_id',
    external_id_type: 'external_id_type',
    protocol: 'protocol',
    vendor: 'vendor',
    model: 'model',
    status: 'status',
    attributes: 'attributes',
    last_telemetry: 'last_telemetry',
    last_telemetry_ts: 'last_telemetry_ts',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type DevicesScalarFieldEnum = (typeof DevicesScalarFieldEnum)[keyof typeof DevicesScalarFieldEnum]


  export const OrganisationsScalarFieldEnum: {
    id: 'id',
    uuid: 'uuid',
    name: 'name',
    parent_org_id: 'parent_org_id',
    path: 'path',
    maps_api_key: 'maps_api_key',
    can_inherit_key: 'can_inherit_key',
    attributes: 'attributes',
    created_at: 'created_at',
    updated_at: 'updated_at'
  };

  export type OrganisationsScalarFieldEnum = (typeof OrganisationsScalarFieldEnum)[keyof typeof OrganisationsScalarFieldEnum]


  export const PermissionsScalarFieldEnum: {
    perm_id: 'perm_id',
    key: 'key',
    description: 'description'
  };

  export type PermissionsScalarFieldEnum = (typeof PermissionsScalarFieldEnum)[keyof typeof PermissionsScalarFieldEnum]


  export const Role_permissionsScalarFieldEnum: {
    role_id: 'role_id',
    perm_id: 'perm_id'
  };

  export type Role_permissionsScalarFieldEnum = (typeof Role_permissionsScalarFieldEnum)[keyof typeof Role_permissionsScalarFieldEnum]


  export const RolesScalarFieldEnum: {
    role_id: 'role_id',
    name: 'name'
  };

  export type RolesScalarFieldEnum = (typeof RolesScalarFieldEnum)[keyof typeof RolesScalarFieldEnum]


  export const TelemetryScalarFieldEnum: {
    id: 'id',
    device_id: 'device_id',
    asset_id: 'asset_id',
    organisation_id: 'organisation_id',
    happened_at: 'happened_at',
    protocol: 'protocol',
    vendor: 'vendor',
    model: 'model',
    telemetry: 'telemetry',
    created_at: 'created_at'
  };

  export type TelemetryScalarFieldEnum = (typeof TelemetryScalarFieldEnum)[keyof typeof TelemetryScalarFieldEnum]


  export const UsersScalarFieldEnum: {
    id: 'id',
    uuid: 'uuid',
    first_name: 'first_name',
    last_name: 'last_name',
    email: 'email',
    password_hash: 'password_hash',
    role_id: 'role_id',
    organisation_id: 'organisation_id',
    active: 'active',
    last_login_at: 'last_login_at',
    created_at: 'created_at',
    updated_at: 'updated_at',
    token_version: 'token_version'
  };

  export type UsersScalarFieldEnum = (typeof UsersScalarFieldEnum)[keyof typeof UsersScalarFieldEnum]


  export const Codec12_commandsScalarFieldEnum: {
    id: 'id',
    uuid: 'uuid',
    imei: 'imei',
    command: 'command',
    status: 'status',
    created_at: 'created_at',
    updated_at: 'updated_at',
    sent_at: 'sent_at',
    responded_at: 'responded_at',
    response: 'response',
    retries: 'retries',
    comment: 'comment'
  };

  export type Codec12_commandsScalarFieldEnum = (typeof Codec12_commandsScalarFieldEnum)[keyof typeof Codec12_commandsScalarFieldEnum]


  export const User_organisation_accessScalarFieldEnum: {
    user_id: 'user_id',
    organisation_id: 'organisation_id',
    is_allowed: 'is_allowed'
  };

  export type User_organisation_accessScalarFieldEnum = (typeof User_organisation_accessScalarFieldEnum)[keyof typeof User_organisation_accessScalarFieldEnum]


  export const User_asset_accessScalarFieldEnum: {
    user_id: 'user_id',
    asset_id: 'asset_id',
    is_allowed: 'is_allowed'
  };

  export type User_asset_accessScalarFieldEnum = (typeof User_asset_accessScalarFieldEnum)[keyof typeof User_asset_accessScalarFieldEnum]


  export const User_device_accessScalarFieldEnum: {
    user_id: 'user_id',
    device_id: 'device_id',
    is_allowed: 'is_allowed'
  };

  export type User_device_accessScalarFieldEnum = (typeof User_device_accessScalarFieldEnum)[keyof typeof User_device_accessScalarFieldEnum]


  export const FilesScalarFieldEnum: {
    id: 'id',
    uuid: 'uuid',
    entity_type: 'entity_type',
    entity_id: 'entity_id',
    filename: 'filename',
    storage_path: 'storage_path',
    url: 'url',
    mime_type: 'mime_type',
    size_bytes: 'size_bytes',
    compressed: 'compressed',
    encrypted: 'encrypted',
    checksum_sha256: 'checksum_sha256',
    file_type: 'file_type',
    attributes: 'attributes',
    created_at: 'created_at',
    uploaded_by: 'uploaded_by'
  };

  export type FilesScalarFieldEnum = (typeof FilesScalarFieldEnum)[keyof typeof FilesScalarFieldEnum]


  export const ImagesScalarFieldEnum: {
    id: 'id',
    uuid: 'uuid',
    entity_type: 'entity_type',
    entity_id: 'entity_id',
    filename: 'filename',
    storage_path: 'storage_path',
    url: 'url',
    mime_type: 'mime_type',
    width_px: 'width_px',
    height_px: 'height_px',
    size_bytes: 'size_bytes',
    compressed: 'compressed',
    encrypted: 'encrypted',
    checksum_sha256: 'checksum_sha256',
    is_primary: 'is_primary',
    tags: 'tags',
    attributes: 'attributes',
    created_at: 'created_at',
    uploaded_by: 'uploaded_by'
  };

  export type ImagesScalarFieldEnum = (typeof ImagesScalarFieldEnum)[keyof typeof ImagesScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const JsonNullValueInput: {
    JsonNull: typeof JsonNull
  };

  export type JsonNullValueInput = (typeof JsonNullValueInput)[keyof typeof JsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'BigInt'
   */
  export type BigIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BigInt'>
    


  /**
   * Reference to a field of type 'BigInt[]'
   */
  export type ListBigIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BigInt[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type assetsWhereInput = {
    AND?: assetsWhereInput | assetsWhereInput[]
    OR?: assetsWhereInput[]
    NOT?: assetsWhereInput | assetsWhereInput[]
    id?: BigIntFilter<"assets"> | bigint | number
    uuid?: UuidNullableFilter<"assets"> | string | null
    organisation_id?: BigIntFilter<"assets"> | bigint | number
    name?: StringFilter<"assets"> | string
    asset_type?: StringNullableFilter<"assets"> | string | null
    attributes?: JsonFilter<"assets">
    created_at?: DateTimeFilter<"assets"> | Date | string
    updated_at?: DateTimeFilter<"assets"> | Date | string
    organisations?: XOR<OrganisationsScalarRelationFilter, organisationsWhereInput>
    devices?: DevicesListRelationFilter
    user_asset_access?: User_asset_accessListRelationFilter
  }

  export type assetsOrderByWithRelationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    organisation_id?: SortOrder
    name?: SortOrder
    asset_type?: SortOrderInput | SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    organisations?: organisationsOrderByWithRelationInput
    devices?: devicesOrderByRelationAggregateInput
    user_asset_access?: user_asset_accessOrderByRelationAggregateInput
  }

  export type assetsWhereUniqueInput = Prisma.AtLeast<{
    id?: bigint | number
    uuid?: string
    AND?: assetsWhereInput | assetsWhereInput[]
    OR?: assetsWhereInput[]
    NOT?: assetsWhereInput | assetsWhereInput[]
    organisation_id?: BigIntFilter<"assets"> | bigint | number
    name?: StringFilter<"assets"> | string
    asset_type?: StringNullableFilter<"assets"> | string | null
    attributes?: JsonFilter<"assets">
    created_at?: DateTimeFilter<"assets"> | Date | string
    updated_at?: DateTimeFilter<"assets"> | Date | string
    organisations?: XOR<OrganisationsScalarRelationFilter, organisationsWhereInput>
    devices?: DevicesListRelationFilter
    user_asset_access?: User_asset_accessListRelationFilter
  }, "id" | "uuid">

  export type assetsOrderByWithAggregationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    organisation_id?: SortOrder
    name?: SortOrder
    asset_type?: SortOrderInput | SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    _count?: assetsCountOrderByAggregateInput
    _avg?: assetsAvgOrderByAggregateInput
    _max?: assetsMaxOrderByAggregateInput
    _min?: assetsMinOrderByAggregateInput
    _sum?: assetsSumOrderByAggregateInput
  }

  export type assetsScalarWhereWithAggregatesInput = {
    AND?: assetsScalarWhereWithAggregatesInput | assetsScalarWhereWithAggregatesInput[]
    OR?: assetsScalarWhereWithAggregatesInput[]
    NOT?: assetsScalarWhereWithAggregatesInput | assetsScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"assets"> | bigint | number
    uuid?: UuidNullableWithAggregatesFilter<"assets"> | string | null
    organisation_id?: BigIntWithAggregatesFilter<"assets"> | bigint | number
    name?: StringWithAggregatesFilter<"assets"> | string
    asset_type?: StringNullableWithAggregatesFilter<"assets"> | string | null
    attributes?: JsonWithAggregatesFilter<"assets">
    created_at?: DateTimeWithAggregatesFilter<"assets"> | Date | string
    updated_at?: DateTimeWithAggregatesFilter<"assets"> | Date | string
  }

  export type devicesWhereInput = {
    AND?: devicesWhereInput | devicesWhereInput[]
    OR?: devicesWhereInput[]
    NOT?: devicesWhereInput | devicesWhereInput[]
    id?: BigIntFilter<"devices"> | bigint | number
    uuid?: UuidNullableFilter<"devices"> | string | null
    organisation_id?: BigIntFilter<"devices"> | bigint | number
    asset_id?: BigIntNullableFilter<"devices"> | bigint | number | null
    external_id?: StringFilter<"devices"> | string
    external_id_type?: StringFilter<"devices"> | string
    protocol?: StringNullableFilter<"devices"> | string | null
    vendor?: StringNullableFilter<"devices"> | string | null
    model?: StringNullableFilter<"devices"> | string | null
    status?: StringFilter<"devices"> | string
    attributes?: JsonFilter<"devices">
    last_telemetry?: JsonFilter<"devices">
    last_telemetry_ts?: DateTimeFilter<"devices"> | Date | string
    created_at?: DateTimeFilter<"devices"> | Date | string
    updated_at?: DateTimeFilter<"devices"> | Date | string
    assets?: XOR<AssetsNullableScalarRelationFilter, assetsWhereInput> | null
    organisations?: XOR<OrganisationsScalarRelationFilter, organisationsWhereInput>
    user_device_access?: User_device_accessListRelationFilter
  }

  export type devicesOrderByWithRelationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    organisation_id?: SortOrder
    asset_id?: SortOrderInput | SortOrder
    external_id?: SortOrder
    external_id_type?: SortOrder
    protocol?: SortOrderInput | SortOrder
    vendor?: SortOrderInput | SortOrder
    model?: SortOrderInput | SortOrder
    status?: SortOrder
    attributes?: SortOrder
    last_telemetry?: SortOrder
    last_telemetry_ts?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    assets?: assetsOrderByWithRelationInput
    organisations?: organisationsOrderByWithRelationInput
    user_device_access?: user_device_accessOrderByRelationAggregateInput
  }

  export type devicesWhereUniqueInput = Prisma.AtLeast<{
    id?: bigint | number
    uuid?: string
    external_id_external_id_type?: devicesExternal_idExternal_id_typeCompoundUniqueInput
    AND?: devicesWhereInput | devicesWhereInput[]
    OR?: devicesWhereInput[]
    NOT?: devicesWhereInput | devicesWhereInput[]
    organisation_id?: BigIntFilter<"devices"> | bigint | number
    asset_id?: BigIntNullableFilter<"devices"> | bigint | number | null
    external_id?: StringFilter<"devices"> | string
    external_id_type?: StringFilter<"devices"> | string
    protocol?: StringNullableFilter<"devices"> | string | null
    vendor?: StringNullableFilter<"devices"> | string | null
    model?: StringNullableFilter<"devices"> | string | null
    status?: StringFilter<"devices"> | string
    attributes?: JsonFilter<"devices">
    last_telemetry?: JsonFilter<"devices">
    last_telemetry_ts?: DateTimeFilter<"devices"> | Date | string
    created_at?: DateTimeFilter<"devices"> | Date | string
    updated_at?: DateTimeFilter<"devices"> | Date | string
    assets?: XOR<AssetsNullableScalarRelationFilter, assetsWhereInput> | null
    organisations?: XOR<OrganisationsScalarRelationFilter, organisationsWhereInput>
    user_device_access?: User_device_accessListRelationFilter
  }, "id" | "uuid" | "external_id_external_id_type">

  export type devicesOrderByWithAggregationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    organisation_id?: SortOrder
    asset_id?: SortOrderInput | SortOrder
    external_id?: SortOrder
    external_id_type?: SortOrder
    protocol?: SortOrderInput | SortOrder
    vendor?: SortOrderInput | SortOrder
    model?: SortOrderInput | SortOrder
    status?: SortOrder
    attributes?: SortOrder
    last_telemetry?: SortOrder
    last_telemetry_ts?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    _count?: devicesCountOrderByAggregateInput
    _avg?: devicesAvgOrderByAggregateInput
    _max?: devicesMaxOrderByAggregateInput
    _min?: devicesMinOrderByAggregateInput
    _sum?: devicesSumOrderByAggregateInput
  }

  export type devicesScalarWhereWithAggregatesInput = {
    AND?: devicesScalarWhereWithAggregatesInput | devicesScalarWhereWithAggregatesInput[]
    OR?: devicesScalarWhereWithAggregatesInput[]
    NOT?: devicesScalarWhereWithAggregatesInput | devicesScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"devices"> | bigint | number
    uuid?: UuidNullableWithAggregatesFilter<"devices"> | string | null
    organisation_id?: BigIntWithAggregatesFilter<"devices"> | bigint | number
    asset_id?: BigIntNullableWithAggregatesFilter<"devices"> | bigint | number | null
    external_id?: StringWithAggregatesFilter<"devices"> | string
    external_id_type?: StringWithAggregatesFilter<"devices"> | string
    protocol?: StringNullableWithAggregatesFilter<"devices"> | string | null
    vendor?: StringNullableWithAggregatesFilter<"devices"> | string | null
    model?: StringNullableWithAggregatesFilter<"devices"> | string | null
    status?: StringWithAggregatesFilter<"devices"> | string
    attributes?: JsonWithAggregatesFilter<"devices">
    last_telemetry?: JsonWithAggregatesFilter<"devices">
    last_telemetry_ts?: DateTimeWithAggregatesFilter<"devices"> | Date | string
    created_at?: DateTimeWithAggregatesFilter<"devices"> | Date | string
    updated_at?: DateTimeWithAggregatesFilter<"devices"> | Date | string
  }

  export type organisationsWhereInput = {
    AND?: organisationsWhereInput | organisationsWhereInput[]
    OR?: organisationsWhereInput[]
    NOT?: organisationsWhereInput | organisationsWhereInput[]
    id?: BigIntFilter<"organisations"> | bigint | number
    uuid?: UuidFilter<"organisations"> | string
    name?: StringFilter<"organisations"> | string
    parent_org_id?: BigIntNullableFilter<"organisations"> | bigint | number | null
    path?: StringNullableFilter<"organisations"> | string | null
    maps_api_key?: StringNullableFilter<"organisations"> | string | null
    can_inherit_key?: BoolNullableFilter<"organisations"> | boolean | null
    attributes?: JsonFilter<"organisations">
    created_at?: DateTimeFilter<"organisations"> | Date | string
    updated_at?: DateTimeFilter<"organisations"> | Date | string
    assets?: AssetsListRelationFilter
    devices?: DevicesListRelationFilter
    organisations?: XOR<OrganisationsNullableScalarRelationFilter, organisationsWhereInput> | null
    other_organisations?: OrganisationsListRelationFilter
    user_organisation_access?: User_organisation_accessListRelationFilter
    users?: UsersListRelationFilter
  }

  export type organisationsOrderByWithRelationInput = {
    id?: SortOrder
    uuid?: SortOrder
    name?: SortOrder
    parent_org_id?: SortOrderInput | SortOrder
    path?: SortOrderInput | SortOrder
    maps_api_key?: SortOrderInput | SortOrder
    can_inherit_key?: SortOrderInput | SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    assets?: assetsOrderByRelationAggregateInput
    devices?: devicesOrderByRelationAggregateInput
    organisations?: organisationsOrderByWithRelationInput
    other_organisations?: organisationsOrderByRelationAggregateInput
    user_organisation_access?: user_organisation_accessOrderByRelationAggregateInput
    users?: usersOrderByRelationAggregateInput
  }

  export type organisationsWhereUniqueInput = Prisma.AtLeast<{
    id?: bigint | number
    uuid?: string
    AND?: organisationsWhereInput | organisationsWhereInput[]
    OR?: organisationsWhereInput[]
    NOT?: organisationsWhereInput | organisationsWhereInput[]
    name?: StringFilter<"organisations"> | string
    parent_org_id?: BigIntNullableFilter<"organisations"> | bigint | number | null
    path?: StringNullableFilter<"organisations"> | string | null
    maps_api_key?: StringNullableFilter<"organisations"> | string | null
    can_inherit_key?: BoolNullableFilter<"organisations"> | boolean | null
    attributes?: JsonFilter<"organisations">
    created_at?: DateTimeFilter<"organisations"> | Date | string
    updated_at?: DateTimeFilter<"organisations"> | Date | string
    assets?: AssetsListRelationFilter
    devices?: DevicesListRelationFilter
    organisations?: XOR<OrganisationsNullableScalarRelationFilter, organisationsWhereInput> | null
    other_organisations?: OrganisationsListRelationFilter
    user_organisation_access?: User_organisation_accessListRelationFilter
    users?: UsersListRelationFilter
  }, "id" | "uuid">

  export type organisationsOrderByWithAggregationInput = {
    id?: SortOrder
    uuid?: SortOrder
    name?: SortOrder
    parent_org_id?: SortOrderInput | SortOrder
    path?: SortOrderInput | SortOrder
    maps_api_key?: SortOrderInput | SortOrder
    can_inherit_key?: SortOrderInput | SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    _count?: organisationsCountOrderByAggregateInput
    _avg?: organisationsAvgOrderByAggregateInput
    _max?: organisationsMaxOrderByAggregateInput
    _min?: organisationsMinOrderByAggregateInput
    _sum?: organisationsSumOrderByAggregateInput
  }

  export type organisationsScalarWhereWithAggregatesInput = {
    AND?: organisationsScalarWhereWithAggregatesInput | organisationsScalarWhereWithAggregatesInput[]
    OR?: organisationsScalarWhereWithAggregatesInput[]
    NOT?: organisationsScalarWhereWithAggregatesInput | organisationsScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"organisations"> | bigint | number
    uuid?: UuidWithAggregatesFilter<"organisations"> | string
    name?: StringWithAggregatesFilter<"organisations"> | string
    parent_org_id?: BigIntNullableWithAggregatesFilter<"organisations"> | bigint | number | null
    path?: StringNullableWithAggregatesFilter<"organisations"> | string | null
    maps_api_key?: StringNullableWithAggregatesFilter<"organisations"> | string | null
    can_inherit_key?: BoolNullableWithAggregatesFilter<"organisations"> | boolean | null
    attributes?: JsonWithAggregatesFilter<"organisations">
    created_at?: DateTimeWithAggregatesFilter<"organisations"> | Date | string
    updated_at?: DateTimeWithAggregatesFilter<"organisations"> | Date | string
  }

  export type permissionsWhereInput = {
    AND?: permissionsWhereInput | permissionsWhereInput[]
    OR?: permissionsWhereInput[]
    NOT?: permissionsWhereInput | permissionsWhereInput[]
    perm_id?: IntFilter<"permissions"> | number
    key?: StringFilter<"permissions"> | string
    description?: StringFilter<"permissions"> | string
    role_permissions?: Role_permissionsListRelationFilter
  }

  export type permissionsOrderByWithRelationInput = {
    perm_id?: SortOrder
    key?: SortOrder
    description?: SortOrder
    role_permissions?: role_permissionsOrderByRelationAggregateInput
  }

  export type permissionsWhereUniqueInput = Prisma.AtLeast<{
    perm_id?: number
    key?: string
    AND?: permissionsWhereInput | permissionsWhereInput[]
    OR?: permissionsWhereInput[]
    NOT?: permissionsWhereInput | permissionsWhereInput[]
    description?: StringFilter<"permissions"> | string
    role_permissions?: Role_permissionsListRelationFilter
  }, "perm_id" | "key">

  export type permissionsOrderByWithAggregationInput = {
    perm_id?: SortOrder
    key?: SortOrder
    description?: SortOrder
    _count?: permissionsCountOrderByAggregateInput
    _avg?: permissionsAvgOrderByAggregateInput
    _max?: permissionsMaxOrderByAggregateInput
    _min?: permissionsMinOrderByAggregateInput
    _sum?: permissionsSumOrderByAggregateInput
  }

  export type permissionsScalarWhereWithAggregatesInput = {
    AND?: permissionsScalarWhereWithAggregatesInput | permissionsScalarWhereWithAggregatesInput[]
    OR?: permissionsScalarWhereWithAggregatesInput[]
    NOT?: permissionsScalarWhereWithAggregatesInput | permissionsScalarWhereWithAggregatesInput[]
    perm_id?: IntWithAggregatesFilter<"permissions"> | number
    key?: StringWithAggregatesFilter<"permissions"> | string
    description?: StringWithAggregatesFilter<"permissions"> | string
  }

  export type role_permissionsWhereInput = {
    AND?: role_permissionsWhereInput | role_permissionsWhereInput[]
    OR?: role_permissionsWhereInput[]
    NOT?: role_permissionsWhereInput | role_permissionsWhereInput[]
    role_id?: IntFilter<"role_permissions"> | number
    perm_id?: IntFilter<"role_permissions"> | number
    permissions?: XOR<PermissionsScalarRelationFilter, permissionsWhereInput>
    roles?: XOR<RolesScalarRelationFilter, rolesWhereInput>
  }

  export type role_permissionsOrderByWithRelationInput = {
    role_id?: SortOrder
    perm_id?: SortOrder
    permissions?: permissionsOrderByWithRelationInput
    roles?: rolesOrderByWithRelationInput
  }

  export type role_permissionsWhereUniqueInput = Prisma.AtLeast<{
    role_id_perm_id?: role_permissionsRole_idPerm_idCompoundUniqueInput
    AND?: role_permissionsWhereInput | role_permissionsWhereInput[]
    OR?: role_permissionsWhereInput[]
    NOT?: role_permissionsWhereInput | role_permissionsWhereInput[]
    role_id?: IntFilter<"role_permissions"> | number
    perm_id?: IntFilter<"role_permissions"> | number
    permissions?: XOR<PermissionsScalarRelationFilter, permissionsWhereInput>
    roles?: XOR<RolesScalarRelationFilter, rolesWhereInput>
  }, "role_id_perm_id">

  export type role_permissionsOrderByWithAggregationInput = {
    role_id?: SortOrder
    perm_id?: SortOrder
    _count?: role_permissionsCountOrderByAggregateInput
    _avg?: role_permissionsAvgOrderByAggregateInput
    _max?: role_permissionsMaxOrderByAggregateInput
    _min?: role_permissionsMinOrderByAggregateInput
    _sum?: role_permissionsSumOrderByAggregateInput
  }

  export type role_permissionsScalarWhereWithAggregatesInput = {
    AND?: role_permissionsScalarWhereWithAggregatesInput | role_permissionsScalarWhereWithAggregatesInput[]
    OR?: role_permissionsScalarWhereWithAggregatesInput[]
    NOT?: role_permissionsScalarWhereWithAggregatesInput | role_permissionsScalarWhereWithAggregatesInput[]
    role_id?: IntWithAggregatesFilter<"role_permissions"> | number
    perm_id?: IntWithAggregatesFilter<"role_permissions"> | number
  }

  export type rolesWhereInput = {
    AND?: rolesWhereInput | rolesWhereInput[]
    OR?: rolesWhereInput[]
    NOT?: rolesWhereInput | rolesWhereInput[]
    role_id?: IntFilter<"roles"> | number
    name?: StringFilter<"roles"> | string
    role_permissions?: Role_permissionsListRelationFilter
    users?: UsersListRelationFilter
  }

  export type rolesOrderByWithRelationInput = {
    role_id?: SortOrder
    name?: SortOrder
    role_permissions?: role_permissionsOrderByRelationAggregateInput
    users?: usersOrderByRelationAggregateInput
  }

  export type rolesWhereUniqueInput = Prisma.AtLeast<{
    role_id?: number
    name?: string
    AND?: rolesWhereInput | rolesWhereInput[]
    OR?: rolesWhereInput[]
    NOT?: rolesWhereInput | rolesWhereInput[]
    role_permissions?: Role_permissionsListRelationFilter
    users?: UsersListRelationFilter
  }, "role_id" | "name">

  export type rolesOrderByWithAggregationInput = {
    role_id?: SortOrder
    name?: SortOrder
    _count?: rolesCountOrderByAggregateInput
    _avg?: rolesAvgOrderByAggregateInput
    _max?: rolesMaxOrderByAggregateInput
    _min?: rolesMinOrderByAggregateInput
    _sum?: rolesSumOrderByAggregateInput
  }

  export type rolesScalarWhereWithAggregatesInput = {
    AND?: rolesScalarWhereWithAggregatesInput | rolesScalarWhereWithAggregatesInput[]
    OR?: rolesScalarWhereWithAggregatesInput[]
    NOT?: rolesScalarWhereWithAggregatesInput | rolesScalarWhereWithAggregatesInput[]
    role_id?: IntWithAggregatesFilter<"roles"> | number
    name?: StringWithAggregatesFilter<"roles"> | string
  }

  export type telemetryWhereInput = {
    AND?: telemetryWhereInput | telemetryWhereInput[]
    OR?: telemetryWhereInput[]
    NOT?: telemetryWhereInput | telemetryWhereInput[]
    id?: BigIntFilter<"telemetry"> | bigint | number
    device_id?: BigIntFilter<"telemetry"> | bigint | number
    asset_id?: BigIntNullableFilter<"telemetry"> | bigint | number | null
    organisation_id?: BigIntNullableFilter<"telemetry"> | bigint | number | null
    happened_at?: DateTimeFilter<"telemetry"> | Date | string
    protocol?: StringFilter<"telemetry"> | string
    vendor?: StringNullableFilter<"telemetry"> | string | null
    model?: StringNullableFilter<"telemetry"> | string | null
    telemetry?: JsonFilter<"telemetry">
    created_at?: DateTimeFilter<"telemetry"> | Date | string
  }

  export type telemetryOrderByWithRelationInput = {
    id?: SortOrder
    device_id?: SortOrder
    asset_id?: SortOrderInput | SortOrder
    organisation_id?: SortOrderInput | SortOrder
    happened_at?: SortOrder
    protocol?: SortOrder
    vendor?: SortOrderInput | SortOrder
    model?: SortOrderInput | SortOrder
    telemetry?: SortOrder
    created_at?: SortOrder
  }

  export type telemetryWhereUniqueInput = Prisma.AtLeast<{
    id_happened_at?: telemetryIdHappened_atCompoundUniqueInput
    AND?: telemetryWhereInput | telemetryWhereInput[]
    OR?: telemetryWhereInput[]
    NOT?: telemetryWhereInput | telemetryWhereInput[]
    id?: BigIntFilter<"telemetry"> | bigint | number
    device_id?: BigIntFilter<"telemetry"> | bigint | number
    asset_id?: BigIntNullableFilter<"telemetry"> | bigint | number | null
    organisation_id?: BigIntNullableFilter<"telemetry"> | bigint | number | null
    happened_at?: DateTimeFilter<"telemetry"> | Date | string
    protocol?: StringFilter<"telemetry"> | string
    vendor?: StringNullableFilter<"telemetry"> | string | null
    model?: StringNullableFilter<"telemetry"> | string | null
    telemetry?: JsonFilter<"telemetry">
    created_at?: DateTimeFilter<"telemetry"> | Date | string
  }, "id_happened_at">

  export type telemetryOrderByWithAggregationInput = {
    id?: SortOrder
    device_id?: SortOrder
    asset_id?: SortOrderInput | SortOrder
    organisation_id?: SortOrderInput | SortOrder
    happened_at?: SortOrder
    protocol?: SortOrder
    vendor?: SortOrderInput | SortOrder
    model?: SortOrderInput | SortOrder
    telemetry?: SortOrder
    created_at?: SortOrder
    _count?: telemetryCountOrderByAggregateInput
    _avg?: telemetryAvgOrderByAggregateInput
    _max?: telemetryMaxOrderByAggregateInput
    _min?: telemetryMinOrderByAggregateInput
    _sum?: telemetrySumOrderByAggregateInput
  }

  export type telemetryScalarWhereWithAggregatesInput = {
    AND?: telemetryScalarWhereWithAggregatesInput | telemetryScalarWhereWithAggregatesInput[]
    OR?: telemetryScalarWhereWithAggregatesInput[]
    NOT?: telemetryScalarWhereWithAggregatesInput | telemetryScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"telemetry"> | bigint | number
    device_id?: BigIntWithAggregatesFilter<"telemetry"> | bigint | number
    asset_id?: BigIntNullableWithAggregatesFilter<"telemetry"> | bigint | number | null
    organisation_id?: BigIntNullableWithAggregatesFilter<"telemetry"> | bigint | number | null
    happened_at?: DateTimeWithAggregatesFilter<"telemetry"> | Date | string
    protocol?: StringWithAggregatesFilter<"telemetry"> | string
    vendor?: StringNullableWithAggregatesFilter<"telemetry"> | string | null
    model?: StringNullableWithAggregatesFilter<"telemetry"> | string | null
    telemetry?: JsonWithAggregatesFilter<"telemetry">
    created_at?: DateTimeWithAggregatesFilter<"telemetry"> | Date | string
  }

  export type usersWhereInput = {
    AND?: usersWhereInput | usersWhereInput[]
    OR?: usersWhereInput[]
    NOT?: usersWhereInput | usersWhereInput[]
    id?: BigIntFilter<"users"> | bigint | number
    uuid?: UuidFilter<"users"> | string
    first_name?: StringFilter<"users"> | string
    last_name?: StringFilter<"users"> | string
    email?: StringFilter<"users"> | string
    password_hash?: StringFilter<"users"> | string
    role_id?: IntFilter<"users"> | number
    organisation_id?: BigIntFilter<"users"> | bigint | number
    active?: BoolFilter<"users"> | boolean
    last_login_at?: DateTimeNullableFilter<"users"> | Date | string | null
    created_at?: DateTimeFilter<"users"> | Date | string
    updated_at?: DateTimeFilter<"users"> | Date | string
    token_version?: IntFilter<"users"> | number
    user_asset_access?: User_asset_accessListRelationFilter
    user_device_access?: User_device_accessListRelationFilter
    user_organisation_access?: User_organisation_accessListRelationFilter
    organisations?: XOR<OrganisationsScalarRelationFilter, organisationsWhereInput>
    roles?: XOR<RolesScalarRelationFilter, rolesWhereInput>
  }

  export type usersOrderByWithRelationInput = {
    id?: SortOrder
    uuid?: SortOrder
    first_name?: SortOrder
    last_name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role_id?: SortOrder
    organisation_id?: SortOrder
    active?: SortOrder
    last_login_at?: SortOrderInput | SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    token_version?: SortOrder
    user_asset_access?: user_asset_accessOrderByRelationAggregateInput
    user_device_access?: user_device_accessOrderByRelationAggregateInput
    user_organisation_access?: user_organisation_accessOrderByRelationAggregateInput
    organisations?: organisationsOrderByWithRelationInput
    roles?: rolesOrderByWithRelationInput
  }

  export type usersWhereUniqueInput = Prisma.AtLeast<{
    id?: bigint | number
    uuid?: string
    email?: string
    AND?: usersWhereInput | usersWhereInput[]
    OR?: usersWhereInput[]
    NOT?: usersWhereInput | usersWhereInput[]
    first_name?: StringFilter<"users"> | string
    last_name?: StringFilter<"users"> | string
    password_hash?: StringFilter<"users"> | string
    role_id?: IntFilter<"users"> | number
    organisation_id?: BigIntFilter<"users"> | bigint | number
    active?: BoolFilter<"users"> | boolean
    last_login_at?: DateTimeNullableFilter<"users"> | Date | string | null
    created_at?: DateTimeFilter<"users"> | Date | string
    updated_at?: DateTimeFilter<"users"> | Date | string
    token_version?: IntFilter<"users"> | number
    user_asset_access?: User_asset_accessListRelationFilter
    user_device_access?: User_device_accessListRelationFilter
    user_organisation_access?: User_organisation_accessListRelationFilter
    organisations?: XOR<OrganisationsScalarRelationFilter, organisationsWhereInput>
    roles?: XOR<RolesScalarRelationFilter, rolesWhereInput>
  }, "id" | "uuid" | "email">

  export type usersOrderByWithAggregationInput = {
    id?: SortOrder
    uuid?: SortOrder
    first_name?: SortOrder
    last_name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role_id?: SortOrder
    organisation_id?: SortOrder
    active?: SortOrder
    last_login_at?: SortOrderInput | SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    token_version?: SortOrder
    _count?: usersCountOrderByAggregateInput
    _avg?: usersAvgOrderByAggregateInput
    _max?: usersMaxOrderByAggregateInput
    _min?: usersMinOrderByAggregateInput
    _sum?: usersSumOrderByAggregateInput
  }

  export type usersScalarWhereWithAggregatesInput = {
    AND?: usersScalarWhereWithAggregatesInput | usersScalarWhereWithAggregatesInput[]
    OR?: usersScalarWhereWithAggregatesInput[]
    NOT?: usersScalarWhereWithAggregatesInput | usersScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"users"> | bigint | number
    uuid?: UuidWithAggregatesFilter<"users"> | string
    first_name?: StringWithAggregatesFilter<"users"> | string
    last_name?: StringWithAggregatesFilter<"users"> | string
    email?: StringWithAggregatesFilter<"users"> | string
    password_hash?: StringWithAggregatesFilter<"users"> | string
    role_id?: IntWithAggregatesFilter<"users"> | number
    organisation_id?: BigIntWithAggregatesFilter<"users"> | bigint | number
    active?: BoolWithAggregatesFilter<"users"> | boolean
    last_login_at?: DateTimeNullableWithAggregatesFilter<"users"> | Date | string | null
    created_at?: DateTimeWithAggregatesFilter<"users"> | Date | string
    updated_at?: DateTimeWithAggregatesFilter<"users"> | Date | string
    token_version?: IntWithAggregatesFilter<"users"> | number
  }

  export type codec12_commandsWhereInput = {
    AND?: codec12_commandsWhereInput | codec12_commandsWhereInput[]
    OR?: codec12_commandsWhereInput[]
    NOT?: codec12_commandsWhereInput | codec12_commandsWhereInput[]
    id?: BigIntFilter<"codec12_commands"> | bigint | number
    uuid?: UuidNullableFilter<"codec12_commands"> | string | null
    imei?: StringFilter<"codec12_commands"> | string
    command?: StringFilter<"codec12_commands"> | string
    status?: StringFilter<"codec12_commands"> | string
    created_at?: DateTimeFilter<"codec12_commands"> | Date | string
    updated_at?: DateTimeFilter<"codec12_commands"> | Date | string
    sent_at?: DateTimeNullableFilter<"codec12_commands"> | Date | string | null
    responded_at?: DateTimeNullableFilter<"codec12_commands"> | Date | string | null
    response?: StringNullableFilter<"codec12_commands"> | string | null
    retries?: IntFilter<"codec12_commands"> | number
    comment?: StringNullableFilter<"codec12_commands"> | string | null
  }

  export type codec12_commandsOrderByWithRelationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    imei?: SortOrder
    command?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    sent_at?: SortOrderInput | SortOrder
    responded_at?: SortOrderInput | SortOrder
    response?: SortOrderInput | SortOrder
    retries?: SortOrder
    comment?: SortOrderInput | SortOrder
  }

  export type codec12_commandsWhereUniqueInput = Prisma.AtLeast<{
    id?: bigint | number
    uuid?: string
    AND?: codec12_commandsWhereInput | codec12_commandsWhereInput[]
    OR?: codec12_commandsWhereInput[]
    NOT?: codec12_commandsWhereInput | codec12_commandsWhereInput[]
    imei?: StringFilter<"codec12_commands"> | string
    command?: StringFilter<"codec12_commands"> | string
    status?: StringFilter<"codec12_commands"> | string
    created_at?: DateTimeFilter<"codec12_commands"> | Date | string
    updated_at?: DateTimeFilter<"codec12_commands"> | Date | string
    sent_at?: DateTimeNullableFilter<"codec12_commands"> | Date | string | null
    responded_at?: DateTimeNullableFilter<"codec12_commands"> | Date | string | null
    response?: StringNullableFilter<"codec12_commands"> | string | null
    retries?: IntFilter<"codec12_commands"> | number
    comment?: StringNullableFilter<"codec12_commands"> | string | null
  }, "id" | "uuid">

  export type codec12_commandsOrderByWithAggregationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    imei?: SortOrder
    command?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    sent_at?: SortOrderInput | SortOrder
    responded_at?: SortOrderInput | SortOrder
    response?: SortOrderInput | SortOrder
    retries?: SortOrder
    comment?: SortOrderInput | SortOrder
    _count?: codec12_commandsCountOrderByAggregateInput
    _avg?: codec12_commandsAvgOrderByAggregateInput
    _max?: codec12_commandsMaxOrderByAggregateInput
    _min?: codec12_commandsMinOrderByAggregateInput
    _sum?: codec12_commandsSumOrderByAggregateInput
  }

  export type codec12_commandsScalarWhereWithAggregatesInput = {
    AND?: codec12_commandsScalarWhereWithAggregatesInput | codec12_commandsScalarWhereWithAggregatesInput[]
    OR?: codec12_commandsScalarWhereWithAggregatesInput[]
    NOT?: codec12_commandsScalarWhereWithAggregatesInput | codec12_commandsScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"codec12_commands"> | bigint | number
    uuid?: UuidNullableWithAggregatesFilter<"codec12_commands"> | string | null
    imei?: StringWithAggregatesFilter<"codec12_commands"> | string
    command?: StringWithAggregatesFilter<"codec12_commands"> | string
    status?: StringWithAggregatesFilter<"codec12_commands"> | string
    created_at?: DateTimeWithAggregatesFilter<"codec12_commands"> | Date | string
    updated_at?: DateTimeWithAggregatesFilter<"codec12_commands"> | Date | string
    sent_at?: DateTimeNullableWithAggregatesFilter<"codec12_commands"> | Date | string | null
    responded_at?: DateTimeNullableWithAggregatesFilter<"codec12_commands"> | Date | string | null
    response?: StringNullableWithAggregatesFilter<"codec12_commands"> | string | null
    retries?: IntWithAggregatesFilter<"codec12_commands"> | number
    comment?: StringNullableWithAggregatesFilter<"codec12_commands"> | string | null
  }

  export type user_organisation_accessWhereInput = {
    AND?: user_organisation_accessWhereInput | user_organisation_accessWhereInput[]
    OR?: user_organisation_accessWhereInput[]
    NOT?: user_organisation_accessWhereInput | user_organisation_accessWhereInput[]
    user_id?: BigIntFilter<"user_organisation_access"> | bigint | number
    organisation_id?: BigIntFilter<"user_organisation_access"> | bigint | number
    is_allowed?: BoolFilter<"user_organisation_access"> | boolean
    organisations?: XOR<OrganisationsScalarRelationFilter, organisationsWhereInput>
    users?: XOR<UsersScalarRelationFilter, usersWhereInput>
  }

  export type user_organisation_accessOrderByWithRelationInput = {
    user_id?: SortOrder
    organisation_id?: SortOrder
    is_allowed?: SortOrder
    organisations?: organisationsOrderByWithRelationInput
    users?: usersOrderByWithRelationInput
  }

  export type user_organisation_accessWhereUniqueInput = Prisma.AtLeast<{
    user_id_organisation_id?: user_organisation_accessUser_idOrganisation_idCompoundUniqueInput
    AND?: user_organisation_accessWhereInput | user_organisation_accessWhereInput[]
    OR?: user_organisation_accessWhereInput[]
    NOT?: user_organisation_accessWhereInput | user_organisation_accessWhereInput[]
    user_id?: BigIntFilter<"user_organisation_access"> | bigint | number
    organisation_id?: BigIntFilter<"user_organisation_access"> | bigint | number
    is_allowed?: BoolFilter<"user_organisation_access"> | boolean
    organisations?: XOR<OrganisationsScalarRelationFilter, organisationsWhereInput>
    users?: XOR<UsersScalarRelationFilter, usersWhereInput>
  }, "user_id_organisation_id">

  export type user_organisation_accessOrderByWithAggregationInput = {
    user_id?: SortOrder
    organisation_id?: SortOrder
    is_allowed?: SortOrder
    _count?: user_organisation_accessCountOrderByAggregateInput
    _avg?: user_organisation_accessAvgOrderByAggregateInput
    _max?: user_organisation_accessMaxOrderByAggregateInput
    _min?: user_organisation_accessMinOrderByAggregateInput
    _sum?: user_organisation_accessSumOrderByAggregateInput
  }

  export type user_organisation_accessScalarWhereWithAggregatesInput = {
    AND?: user_organisation_accessScalarWhereWithAggregatesInput | user_organisation_accessScalarWhereWithAggregatesInput[]
    OR?: user_organisation_accessScalarWhereWithAggregatesInput[]
    NOT?: user_organisation_accessScalarWhereWithAggregatesInput | user_organisation_accessScalarWhereWithAggregatesInput[]
    user_id?: BigIntWithAggregatesFilter<"user_organisation_access"> | bigint | number
    organisation_id?: BigIntWithAggregatesFilter<"user_organisation_access"> | bigint | number
    is_allowed?: BoolWithAggregatesFilter<"user_organisation_access"> | boolean
  }

  export type user_asset_accessWhereInput = {
    AND?: user_asset_accessWhereInput | user_asset_accessWhereInput[]
    OR?: user_asset_accessWhereInput[]
    NOT?: user_asset_accessWhereInput | user_asset_accessWhereInput[]
    user_id?: BigIntFilter<"user_asset_access"> | bigint | number
    asset_id?: BigIntFilter<"user_asset_access"> | bigint | number
    is_allowed?: BoolFilter<"user_asset_access"> | boolean
    assets?: XOR<AssetsScalarRelationFilter, assetsWhereInput>
    users?: XOR<UsersScalarRelationFilter, usersWhereInput>
  }

  export type user_asset_accessOrderByWithRelationInput = {
    user_id?: SortOrder
    asset_id?: SortOrder
    is_allowed?: SortOrder
    assets?: assetsOrderByWithRelationInput
    users?: usersOrderByWithRelationInput
  }

  export type user_asset_accessWhereUniqueInput = Prisma.AtLeast<{
    user_id_asset_id?: user_asset_accessUser_idAsset_idCompoundUniqueInput
    AND?: user_asset_accessWhereInput | user_asset_accessWhereInput[]
    OR?: user_asset_accessWhereInput[]
    NOT?: user_asset_accessWhereInput | user_asset_accessWhereInput[]
    user_id?: BigIntFilter<"user_asset_access"> | bigint | number
    asset_id?: BigIntFilter<"user_asset_access"> | bigint | number
    is_allowed?: BoolFilter<"user_asset_access"> | boolean
    assets?: XOR<AssetsScalarRelationFilter, assetsWhereInput>
    users?: XOR<UsersScalarRelationFilter, usersWhereInput>
  }, "user_id_asset_id">

  export type user_asset_accessOrderByWithAggregationInput = {
    user_id?: SortOrder
    asset_id?: SortOrder
    is_allowed?: SortOrder
    _count?: user_asset_accessCountOrderByAggregateInput
    _avg?: user_asset_accessAvgOrderByAggregateInput
    _max?: user_asset_accessMaxOrderByAggregateInput
    _min?: user_asset_accessMinOrderByAggregateInput
    _sum?: user_asset_accessSumOrderByAggregateInput
  }

  export type user_asset_accessScalarWhereWithAggregatesInput = {
    AND?: user_asset_accessScalarWhereWithAggregatesInput | user_asset_accessScalarWhereWithAggregatesInput[]
    OR?: user_asset_accessScalarWhereWithAggregatesInput[]
    NOT?: user_asset_accessScalarWhereWithAggregatesInput | user_asset_accessScalarWhereWithAggregatesInput[]
    user_id?: BigIntWithAggregatesFilter<"user_asset_access"> | bigint | number
    asset_id?: BigIntWithAggregatesFilter<"user_asset_access"> | bigint | number
    is_allowed?: BoolWithAggregatesFilter<"user_asset_access"> | boolean
  }

  export type user_device_accessWhereInput = {
    AND?: user_device_accessWhereInput | user_device_accessWhereInput[]
    OR?: user_device_accessWhereInput[]
    NOT?: user_device_accessWhereInput | user_device_accessWhereInput[]
    user_id?: BigIntFilter<"user_device_access"> | bigint | number
    device_id?: BigIntFilter<"user_device_access"> | bigint | number
    is_allowed?: BoolFilter<"user_device_access"> | boolean
    devices?: XOR<DevicesScalarRelationFilter, devicesWhereInput>
    users?: XOR<UsersScalarRelationFilter, usersWhereInput>
  }

  export type user_device_accessOrderByWithRelationInput = {
    user_id?: SortOrder
    device_id?: SortOrder
    is_allowed?: SortOrder
    devices?: devicesOrderByWithRelationInput
    users?: usersOrderByWithRelationInput
  }

  export type user_device_accessWhereUniqueInput = Prisma.AtLeast<{
    user_id_device_id?: user_device_accessUser_idDevice_idCompoundUniqueInput
    AND?: user_device_accessWhereInput | user_device_accessWhereInput[]
    OR?: user_device_accessWhereInput[]
    NOT?: user_device_accessWhereInput | user_device_accessWhereInput[]
    user_id?: BigIntFilter<"user_device_access"> | bigint | number
    device_id?: BigIntFilter<"user_device_access"> | bigint | number
    is_allowed?: BoolFilter<"user_device_access"> | boolean
    devices?: XOR<DevicesScalarRelationFilter, devicesWhereInput>
    users?: XOR<UsersScalarRelationFilter, usersWhereInput>
  }, "user_id_device_id">

  export type user_device_accessOrderByWithAggregationInput = {
    user_id?: SortOrder
    device_id?: SortOrder
    is_allowed?: SortOrder
    _count?: user_device_accessCountOrderByAggregateInput
    _avg?: user_device_accessAvgOrderByAggregateInput
    _max?: user_device_accessMaxOrderByAggregateInput
    _min?: user_device_accessMinOrderByAggregateInput
    _sum?: user_device_accessSumOrderByAggregateInput
  }

  export type user_device_accessScalarWhereWithAggregatesInput = {
    AND?: user_device_accessScalarWhereWithAggregatesInput | user_device_accessScalarWhereWithAggregatesInput[]
    OR?: user_device_accessScalarWhereWithAggregatesInput[]
    NOT?: user_device_accessScalarWhereWithAggregatesInput | user_device_accessScalarWhereWithAggregatesInput[]
    user_id?: BigIntWithAggregatesFilter<"user_device_access"> | bigint | number
    device_id?: BigIntWithAggregatesFilter<"user_device_access"> | bigint | number
    is_allowed?: BoolWithAggregatesFilter<"user_device_access"> | boolean
  }

  export type filesWhereInput = {
    AND?: filesWhereInput | filesWhereInput[]
    OR?: filesWhereInput[]
    NOT?: filesWhereInput | filesWhereInput[]
    id?: BigIntFilter<"files"> | bigint | number
    uuid?: UuidNullableFilter<"files"> | string | null
    entity_type?: StringFilter<"files"> | string
    entity_id?: BigIntFilter<"files"> | bigint | number
    filename?: StringFilter<"files"> | string
    storage_path?: StringFilter<"files"> | string
    url?: StringNullableFilter<"files"> | string | null
    mime_type?: StringFilter<"files"> | string
    size_bytes?: BigIntNullableFilter<"files"> | bigint | number | null
    compressed?: BoolFilter<"files"> | boolean
    encrypted?: BoolFilter<"files"> | boolean
    checksum_sha256?: StringNullableFilter<"files"> | string | null
    file_type?: StringNullableFilter<"files"> | string | null
    attributes?: JsonFilter<"files">
    created_at?: DateTimeFilter<"files"> | Date | string
    uploaded_by?: BigIntNullableFilter<"files"> | bigint | number | null
  }

  export type filesOrderByWithRelationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrderInput | SortOrder
    mime_type?: SortOrder
    size_bytes?: SortOrderInput | SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrderInput | SortOrder
    file_type?: SortOrderInput | SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrderInput | SortOrder
  }

  export type filesWhereUniqueInput = Prisma.AtLeast<{
    id?: bigint | number
    uuid?: string
    AND?: filesWhereInput | filesWhereInput[]
    OR?: filesWhereInput[]
    NOT?: filesWhereInput | filesWhereInput[]
    entity_type?: StringFilter<"files"> | string
    entity_id?: BigIntFilter<"files"> | bigint | number
    filename?: StringFilter<"files"> | string
    storage_path?: StringFilter<"files"> | string
    url?: StringNullableFilter<"files"> | string | null
    mime_type?: StringFilter<"files"> | string
    size_bytes?: BigIntNullableFilter<"files"> | bigint | number | null
    compressed?: BoolFilter<"files"> | boolean
    encrypted?: BoolFilter<"files"> | boolean
    checksum_sha256?: StringNullableFilter<"files"> | string | null
    file_type?: StringNullableFilter<"files"> | string | null
    attributes?: JsonFilter<"files">
    created_at?: DateTimeFilter<"files"> | Date | string
    uploaded_by?: BigIntNullableFilter<"files"> | bigint | number | null
  }, "id" | "uuid">

  export type filesOrderByWithAggregationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrderInput | SortOrder
    mime_type?: SortOrder
    size_bytes?: SortOrderInput | SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrderInput | SortOrder
    file_type?: SortOrderInput | SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrderInput | SortOrder
    _count?: filesCountOrderByAggregateInput
    _avg?: filesAvgOrderByAggregateInput
    _max?: filesMaxOrderByAggregateInput
    _min?: filesMinOrderByAggregateInput
    _sum?: filesSumOrderByAggregateInput
  }

  export type filesScalarWhereWithAggregatesInput = {
    AND?: filesScalarWhereWithAggregatesInput | filesScalarWhereWithAggregatesInput[]
    OR?: filesScalarWhereWithAggregatesInput[]
    NOT?: filesScalarWhereWithAggregatesInput | filesScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"files"> | bigint | number
    uuid?: UuidNullableWithAggregatesFilter<"files"> | string | null
    entity_type?: StringWithAggregatesFilter<"files"> | string
    entity_id?: BigIntWithAggregatesFilter<"files"> | bigint | number
    filename?: StringWithAggregatesFilter<"files"> | string
    storage_path?: StringWithAggregatesFilter<"files"> | string
    url?: StringNullableWithAggregatesFilter<"files"> | string | null
    mime_type?: StringWithAggregatesFilter<"files"> | string
    size_bytes?: BigIntNullableWithAggregatesFilter<"files"> | bigint | number | null
    compressed?: BoolWithAggregatesFilter<"files"> | boolean
    encrypted?: BoolWithAggregatesFilter<"files"> | boolean
    checksum_sha256?: StringNullableWithAggregatesFilter<"files"> | string | null
    file_type?: StringNullableWithAggregatesFilter<"files"> | string | null
    attributes?: JsonWithAggregatesFilter<"files">
    created_at?: DateTimeWithAggregatesFilter<"files"> | Date | string
    uploaded_by?: BigIntNullableWithAggregatesFilter<"files"> | bigint | number | null
  }

  export type imagesWhereInput = {
    AND?: imagesWhereInput | imagesWhereInput[]
    OR?: imagesWhereInput[]
    NOT?: imagesWhereInput | imagesWhereInput[]
    id?: BigIntFilter<"images"> | bigint | number
    uuid?: UuidNullableFilter<"images"> | string | null
    entity_type?: StringFilter<"images"> | string
    entity_id?: BigIntFilter<"images"> | bigint | number
    filename?: StringFilter<"images"> | string
    storage_path?: StringFilter<"images"> | string
    url?: StringNullableFilter<"images"> | string | null
    mime_type?: StringFilter<"images"> | string
    width_px?: IntNullableFilter<"images"> | number | null
    height_px?: IntNullableFilter<"images"> | number | null
    size_bytes?: BigIntNullableFilter<"images"> | bigint | number | null
    compressed?: BoolFilter<"images"> | boolean
    encrypted?: BoolFilter<"images"> | boolean
    checksum_sha256?: StringNullableFilter<"images"> | string | null
    is_primary?: BoolFilter<"images"> | boolean
    tags?: StringNullableListFilter<"images">
    attributes?: JsonFilter<"images">
    created_at?: DateTimeFilter<"images"> | Date | string
    uploaded_by?: BigIntNullableFilter<"images"> | bigint | number | null
  }

  export type imagesOrderByWithRelationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrderInput | SortOrder
    mime_type?: SortOrder
    width_px?: SortOrderInput | SortOrder
    height_px?: SortOrderInput | SortOrder
    size_bytes?: SortOrderInput | SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrderInput | SortOrder
    is_primary?: SortOrder
    tags?: SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrderInput | SortOrder
  }

  export type imagesWhereUniqueInput = Prisma.AtLeast<{
    id?: bigint | number
    uuid?: string
    AND?: imagesWhereInput | imagesWhereInput[]
    OR?: imagesWhereInput[]
    NOT?: imagesWhereInput | imagesWhereInput[]
    entity_type?: StringFilter<"images"> | string
    entity_id?: BigIntFilter<"images"> | bigint | number
    filename?: StringFilter<"images"> | string
    storage_path?: StringFilter<"images"> | string
    url?: StringNullableFilter<"images"> | string | null
    mime_type?: StringFilter<"images"> | string
    width_px?: IntNullableFilter<"images"> | number | null
    height_px?: IntNullableFilter<"images"> | number | null
    size_bytes?: BigIntNullableFilter<"images"> | bigint | number | null
    compressed?: BoolFilter<"images"> | boolean
    encrypted?: BoolFilter<"images"> | boolean
    checksum_sha256?: StringNullableFilter<"images"> | string | null
    is_primary?: BoolFilter<"images"> | boolean
    tags?: StringNullableListFilter<"images">
    attributes?: JsonFilter<"images">
    created_at?: DateTimeFilter<"images"> | Date | string
    uploaded_by?: BigIntNullableFilter<"images"> | bigint | number | null
  }, "id" | "uuid">

  export type imagesOrderByWithAggregationInput = {
    id?: SortOrder
    uuid?: SortOrderInput | SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrderInput | SortOrder
    mime_type?: SortOrder
    width_px?: SortOrderInput | SortOrder
    height_px?: SortOrderInput | SortOrder
    size_bytes?: SortOrderInput | SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrderInput | SortOrder
    is_primary?: SortOrder
    tags?: SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrderInput | SortOrder
    _count?: imagesCountOrderByAggregateInput
    _avg?: imagesAvgOrderByAggregateInput
    _max?: imagesMaxOrderByAggregateInput
    _min?: imagesMinOrderByAggregateInput
    _sum?: imagesSumOrderByAggregateInput
  }

  export type imagesScalarWhereWithAggregatesInput = {
    AND?: imagesScalarWhereWithAggregatesInput | imagesScalarWhereWithAggregatesInput[]
    OR?: imagesScalarWhereWithAggregatesInput[]
    NOT?: imagesScalarWhereWithAggregatesInput | imagesScalarWhereWithAggregatesInput[]
    id?: BigIntWithAggregatesFilter<"images"> | bigint | number
    uuid?: UuidNullableWithAggregatesFilter<"images"> | string | null
    entity_type?: StringWithAggregatesFilter<"images"> | string
    entity_id?: BigIntWithAggregatesFilter<"images"> | bigint | number
    filename?: StringWithAggregatesFilter<"images"> | string
    storage_path?: StringWithAggregatesFilter<"images"> | string
    url?: StringNullableWithAggregatesFilter<"images"> | string | null
    mime_type?: StringWithAggregatesFilter<"images"> | string
    width_px?: IntNullableWithAggregatesFilter<"images"> | number | null
    height_px?: IntNullableWithAggregatesFilter<"images"> | number | null
    size_bytes?: BigIntNullableWithAggregatesFilter<"images"> | bigint | number | null
    compressed?: BoolWithAggregatesFilter<"images"> | boolean
    encrypted?: BoolWithAggregatesFilter<"images"> | boolean
    checksum_sha256?: StringNullableWithAggregatesFilter<"images"> | string | null
    is_primary?: BoolWithAggregatesFilter<"images"> | boolean
    tags?: StringNullableListFilter<"images">
    attributes?: JsonWithAggregatesFilter<"images">
    created_at?: DateTimeWithAggregatesFilter<"images"> | Date | string
    uploaded_by?: BigIntNullableWithAggregatesFilter<"images"> | bigint | number | null
  }

  export type assetsCreateInput = {
    id?: bigint | number
    uuid?: string | null
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    organisations?: organisationsCreateNestedOneWithoutAssetsInput
    devices?: devicesCreateNestedManyWithoutAssetsInput
    user_asset_access?: user_asset_accessCreateNestedManyWithoutAssetsInput
  }

  export type assetsUncheckedCreateInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    devices?: devicesUncheckedCreateNestedManyWithoutAssetsInput
    user_asset_access?: user_asset_accessUncheckedCreateNestedManyWithoutAssetsInput
  }

  export type assetsUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    organisations?: organisationsUpdateOneRequiredWithoutAssetsNestedInput
    devices?: devicesUpdateManyWithoutAssetsNestedInput
    user_asset_access?: user_asset_accessUpdateManyWithoutAssetsNestedInput
  }

  export type assetsUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    devices?: devicesUncheckedUpdateManyWithoutAssetsNestedInput
    user_asset_access?: user_asset_accessUncheckedUpdateManyWithoutAssetsNestedInput
  }

  export type assetsCreateManyInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type assetsUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type assetsUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type devicesCreateInput = {
    id?: bigint | number
    uuid?: string | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedOneWithoutDevicesInput
    organisations?: organisationsCreateNestedOneWithoutDevicesInput
    user_device_access?: user_device_accessCreateNestedManyWithoutDevicesInput
  }

  export type devicesUncheckedCreateInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    asset_id?: bigint | number | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
    user_device_access?: user_device_accessUncheckedCreateNestedManyWithoutDevicesInput
  }

  export type devicesUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateOneWithoutDevicesNestedInput
    organisations?: organisationsUpdateOneRequiredWithoutDevicesNestedInput
    user_device_access?: user_device_accessUpdateManyWithoutDevicesNestedInput
  }

  export type devicesUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    user_device_access?: user_device_accessUncheckedUpdateManyWithoutDevicesNestedInput
  }

  export type devicesCreateManyInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    asset_id?: bigint | number | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type devicesUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type devicesUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type organisationsCreateInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedManyWithoutOrganisationsInput
    devices?: devicesCreateNestedManyWithoutOrganisationsInput
    organisations?: organisationsCreateNestedOneWithoutOther_organisationsInput
    other_organisations?: organisationsCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutOrganisationsInput
    users?: usersCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsUncheckedCreateInput = {
    id?: bigint | number
    uuid?: string
    name: string
    parent_org_id?: bigint | number | null
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsUncheckedCreateNestedManyWithoutOrganisationsInput
    devices?: devicesUncheckedCreateNestedManyWithoutOrganisationsInput
    other_organisations?: organisationsUncheckedCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutOrganisationsInput
    users?: usersUncheckedCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUpdateManyWithoutOrganisationsNestedInput
    organisations?: organisationsUpdateOneWithoutOther_organisationsNestedInput
    other_organisations?: organisationsUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutOrganisationsNestedInput
    users?: usersUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    parent_org_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUncheckedUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUncheckedUpdateManyWithoutOrganisationsNestedInput
    other_organisations?: organisationsUncheckedUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutOrganisationsNestedInput
    users?: usersUncheckedUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsCreateManyInput = {
    id?: bigint | number
    uuid?: string
    name: string
    parent_org_id?: bigint | number | null
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type organisationsUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type organisationsUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    parent_org_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type permissionsCreateInput = {
    perm_id: number
    key: string
    description: string
    role_permissions?: role_permissionsCreateNestedManyWithoutPermissionsInput
  }

  export type permissionsUncheckedCreateInput = {
    perm_id: number
    key: string
    description: string
    role_permissions?: role_permissionsUncheckedCreateNestedManyWithoutPermissionsInput
  }

  export type permissionsUpdateInput = {
    perm_id?: IntFieldUpdateOperationsInput | number
    key?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    role_permissions?: role_permissionsUpdateManyWithoutPermissionsNestedInput
  }

  export type permissionsUncheckedUpdateInput = {
    perm_id?: IntFieldUpdateOperationsInput | number
    key?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    role_permissions?: role_permissionsUncheckedUpdateManyWithoutPermissionsNestedInput
  }

  export type permissionsCreateManyInput = {
    perm_id: number
    key: string
    description: string
  }

  export type permissionsUpdateManyMutationInput = {
    perm_id?: IntFieldUpdateOperationsInput | number
    key?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
  }

  export type permissionsUncheckedUpdateManyInput = {
    perm_id?: IntFieldUpdateOperationsInput | number
    key?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
  }

  export type role_permissionsCreateInput = {
    permissions: permissionsCreateNestedOneWithoutRole_permissionsInput
    roles: rolesCreateNestedOneWithoutRole_permissionsInput
  }

  export type role_permissionsUncheckedCreateInput = {
    role_id: number
    perm_id: number
  }

  export type role_permissionsUpdateInput = {
    permissions?: permissionsUpdateOneRequiredWithoutRole_permissionsNestedInput
    roles?: rolesUpdateOneRequiredWithoutRole_permissionsNestedInput
  }

  export type role_permissionsUncheckedUpdateInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    perm_id?: IntFieldUpdateOperationsInput | number
  }

  export type role_permissionsCreateManyInput = {
    role_id: number
    perm_id: number
  }

  export type role_permissionsUpdateManyMutationInput = {

  }

  export type role_permissionsUncheckedUpdateManyInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    perm_id?: IntFieldUpdateOperationsInput | number
  }

  export type rolesCreateInput = {
    role_id: number
    name: string
    role_permissions?: role_permissionsCreateNestedManyWithoutRolesInput
    users?: usersCreateNestedManyWithoutRolesInput
  }

  export type rolesUncheckedCreateInput = {
    role_id: number
    name: string
    role_permissions?: role_permissionsUncheckedCreateNestedManyWithoutRolesInput
    users?: usersUncheckedCreateNestedManyWithoutRolesInput
  }

  export type rolesUpdateInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    role_permissions?: role_permissionsUpdateManyWithoutRolesNestedInput
    users?: usersUpdateManyWithoutRolesNestedInput
  }

  export type rolesUncheckedUpdateInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    role_permissions?: role_permissionsUncheckedUpdateManyWithoutRolesNestedInput
    users?: usersUncheckedUpdateManyWithoutRolesNestedInput
  }

  export type rolesCreateManyInput = {
    role_id: number
    name: string
  }

  export type rolesUpdateManyMutationInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
  }

  export type rolesUncheckedUpdateManyInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
  }

  export type telemetryCreateInput = {
    id?: bigint | number
    device_id: bigint | number
    asset_id?: bigint | number | null
    organisation_id?: bigint | number | null
    happened_at: Date | string
    protocol: string
    vendor?: string | null
    model?: string | null
    telemetry: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
  }

  export type telemetryUncheckedCreateInput = {
    id?: bigint | number
    device_id: bigint | number
    asset_id?: bigint | number | null
    organisation_id?: bigint | number | null
    happened_at: Date | string
    protocol: string
    vendor?: string | null
    model?: string | null
    telemetry: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
  }

  export type telemetryUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    device_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    organisation_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    happened_at?: DateTimeFieldUpdateOperationsInput | Date | string
    protocol?: StringFieldUpdateOperationsInput | string
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    telemetry?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type telemetryUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    device_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    organisation_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    happened_at?: DateTimeFieldUpdateOperationsInput | Date | string
    protocol?: StringFieldUpdateOperationsInput | string
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    telemetry?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type telemetryCreateManyInput = {
    id?: bigint | number
    device_id: bigint | number
    asset_id?: bigint | number | null
    organisation_id?: bigint | number | null
    happened_at: Date | string
    protocol: string
    vendor?: string | null
    model?: string | null
    telemetry: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
  }

  export type telemetryUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    device_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    organisation_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    happened_at?: DateTimeFieldUpdateOperationsInput | Date | string
    protocol?: StringFieldUpdateOperationsInput | string
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    telemetry?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type telemetryUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    device_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    organisation_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    happened_at?: DateTimeFieldUpdateOperationsInput | Date | string
    protocol?: StringFieldUpdateOperationsInput | string
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    telemetry?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type usersCreateInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessCreateNestedManyWithoutUsersInput
    user_device_access?: user_device_accessCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutUsersInput
    organisations: organisationsCreateNestedOneWithoutUsersInput
    roles: rolesCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    role_id: number
    organisation_id: bigint | number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessUncheckedCreateNestedManyWithoutUsersInput
    user_device_access?: user_device_accessUncheckedCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutUsersInput
  }

  export type usersUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUpdateManyWithoutUsersNestedInput
    user_device_access?: user_device_accessUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutUsersNestedInput
    organisations?: organisationsUpdateOneRequiredWithoutUsersNestedInput
    roles?: rolesUpdateOneRequiredWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role_id?: IntFieldUpdateOperationsInput | number
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_device_access?: user_device_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutUsersNestedInput
  }

  export type usersCreateManyInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    role_id: number
    organisation_id: bigint | number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
  }

  export type usersUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
  }

  export type usersUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role_id?: IntFieldUpdateOperationsInput | number
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
  }

  export type codec12_commandsCreateInput = {
    id?: bigint | number
    uuid?: string | null
    imei: string
    command: string
    status?: string
    created_at?: Date | string
    updated_at?: Date | string
    sent_at?: Date | string | null
    responded_at?: Date | string | null
    response?: string | null
    retries?: number
    comment?: string | null
  }

  export type codec12_commandsUncheckedCreateInput = {
    id?: bigint | number
    uuid?: string | null
    imei: string
    command: string
    status?: string
    created_at?: Date | string
    updated_at?: Date | string
    sent_at?: Date | string | null
    responded_at?: Date | string | null
    response?: string | null
    retries?: number
    comment?: string | null
  }

  export type codec12_commandsUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    imei?: StringFieldUpdateOperationsInput | string
    command?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    responded_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    response?: NullableStringFieldUpdateOperationsInput | string | null
    retries?: IntFieldUpdateOperationsInput | number
    comment?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type codec12_commandsUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    imei?: StringFieldUpdateOperationsInput | string
    command?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    responded_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    response?: NullableStringFieldUpdateOperationsInput | string | null
    retries?: IntFieldUpdateOperationsInput | number
    comment?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type codec12_commandsCreateManyInput = {
    id?: bigint | number
    uuid?: string | null
    imei: string
    command: string
    status?: string
    created_at?: Date | string
    updated_at?: Date | string
    sent_at?: Date | string | null
    responded_at?: Date | string | null
    response?: string | null
    retries?: number
    comment?: string | null
  }

  export type codec12_commandsUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    imei?: StringFieldUpdateOperationsInput | string
    command?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    responded_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    response?: NullableStringFieldUpdateOperationsInput | string | null
    retries?: IntFieldUpdateOperationsInput | number
    comment?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type codec12_commandsUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    imei?: StringFieldUpdateOperationsInput | string
    command?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    sent_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    responded_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    response?: NullableStringFieldUpdateOperationsInput | string | null
    retries?: IntFieldUpdateOperationsInput | number
    comment?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type user_organisation_accessCreateInput = {
    is_allowed?: boolean
    organisations: organisationsCreateNestedOneWithoutUser_organisation_accessInput
    users: usersCreateNestedOneWithoutUser_organisation_accessInput
  }

  export type user_organisation_accessUncheckedCreateInput = {
    user_id: bigint | number
    organisation_id: bigint | number
    is_allowed?: boolean
  }

  export type user_organisation_accessUpdateInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    organisations?: organisationsUpdateOneRequiredWithoutUser_organisation_accessNestedInput
    users?: usersUpdateOneRequiredWithoutUser_organisation_accessNestedInput
  }

  export type user_organisation_accessUncheckedUpdateInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_organisation_accessCreateManyInput = {
    user_id: bigint | number
    organisation_id: bigint | number
    is_allowed?: boolean
  }

  export type user_organisation_accessUpdateManyMutationInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_organisation_accessUncheckedUpdateManyInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_asset_accessCreateInput = {
    is_allowed?: boolean
    assets: assetsCreateNestedOneWithoutUser_asset_accessInput
    users: usersCreateNestedOneWithoutUser_asset_accessInput
  }

  export type user_asset_accessUncheckedCreateInput = {
    user_id: bigint | number
    asset_id: bigint | number
    is_allowed?: boolean
  }

  export type user_asset_accessUpdateInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    assets?: assetsUpdateOneRequiredWithoutUser_asset_accessNestedInput
    users?: usersUpdateOneRequiredWithoutUser_asset_accessNestedInput
  }

  export type user_asset_accessUncheckedUpdateInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_asset_accessCreateManyInput = {
    user_id: bigint | number
    asset_id: bigint | number
    is_allowed?: boolean
  }

  export type user_asset_accessUpdateManyMutationInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_asset_accessUncheckedUpdateManyInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_device_accessCreateInput = {
    is_allowed?: boolean
    devices: devicesCreateNestedOneWithoutUser_device_accessInput
    users: usersCreateNestedOneWithoutUser_device_accessInput
  }

  export type user_device_accessUncheckedCreateInput = {
    user_id: bigint | number
    device_id: bigint | number
    is_allowed?: boolean
  }

  export type user_device_accessUpdateInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    devices?: devicesUpdateOneRequiredWithoutUser_device_accessNestedInput
    users?: usersUpdateOneRequiredWithoutUser_device_accessNestedInput
  }

  export type user_device_accessUncheckedUpdateInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    device_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_device_accessCreateManyInput = {
    user_id: bigint | number
    device_id: bigint | number
    is_allowed?: boolean
  }

  export type user_device_accessUpdateManyMutationInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_device_accessUncheckedUpdateManyInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    device_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type filesCreateInput = {
    id?: bigint | number
    uuid?: string | null
    entity_type: string
    entity_id: bigint | number
    filename: string
    storage_path: string
    url?: string | null
    mime_type: string
    size_bytes?: bigint | number | null
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: string | null
    file_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    uploaded_by?: bigint | number | null
  }

  export type filesUncheckedCreateInput = {
    id?: bigint | number
    uuid?: string | null
    entity_type: string
    entity_id: bigint | number
    filename: string
    storage_path: string
    url?: string | null
    mime_type: string
    size_bytes?: bigint | number | null
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: string | null
    file_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    uploaded_by?: bigint | number | null
  }

  export type filesUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    entity_type?: StringFieldUpdateOperationsInput | string
    entity_id?: BigIntFieldUpdateOperationsInput | bigint | number
    filename?: StringFieldUpdateOperationsInput | string
    storage_path?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    mime_type?: StringFieldUpdateOperationsInput | string
    size_bytes?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    compressed?: BoolFieldUpdateOperationsInput | boolean
    encrypted?: BoolFieldUpdateOperationsInput | boolean
    checksum_sha256?: NullableStringFieldUpdateOperationsInput | string | null
    file_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    uploaded_by?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
  }

  export type filesUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    entity_type?: StringFieldUpdateOperationsInput | string
    entity_id?: BigIntFieldUpdateOperationsInput | bigint | number
    filename?: StringFieldUpdateOperationsInput | string
    storage_path?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    mime_type?: StringFieldUpdateOperationsInput | string
    size_bytes?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    compressed?: BoolFieldUpdateOperationsInput | boolean
    encrypted?: BoolFieldUpdateOperationsInput | boolean
    checksum_sha256?: NullableStringFieldUpdateOperationsInput | string | null
    file_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    uploaded_by?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
  }

  export type filesCreateManyInput = {
    id?: bigint | number
    uuid?: string | null
    entity_type: string
    entity_id: bigint | number
    filename: string
    storage_path: string
    url?: string | null
    mime_type: string
    size_bytes?: bigint | number | null
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: string | null
    file_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    uploaded_by?: bigint | number | null
  }

  export type filesUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    entity_type?: StringFieldUpdateOperationsInput | string
    entity_id?: BigIntFieldUpdateOperationsInput | bigint | number
    filename?: StringFieldUpdateOperationsInput | string
    storage_path?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    mime_type?: StringFieldUpdateOperationsInput | string
    size_bytes?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    compressed?: BoolFieldUpdateOperationsInput | boolean
    encrypted?: BoolFieldUpdateOperationsInput | boolean
    checksum_sha256?: NullableStringFieldUpdateOperationsInput | string | null
    file_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    uploaded_by?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
  }

  export type filesUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    entity_type?: StringFieldUpdateOperationsInput | string
    entity_id?: BigIntFieldUpdateOperationsInput | bigint | number
    filename?: StringFieldUpdateOperationsInput | string
    storage_path?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    mime_type?: StringFieldUpdateOperationsInput | string
    size_bytes?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    compressed?: BoolFieldUpdateOperationsInput | boolean
    encrypted?: BoolFieldUpdateOperationsInput | boolean
    checksum_sha256?: NullableStringFieldUpdateOperationsInput | string | null
    file_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    uploaded_by?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
  }

  export type imagesCreateInput = {
    id?: bigint | number
    uuid?: string | null
    entity_type: string
    entity_id: bigint | number
    filename: string
    storage_path: string
    url?: string | null
    mime_type?: string
    width_px?: number | null
    height_px?: number | null
    size_bytes?: bigint | number | null
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: string | null
    is_primary?: boolean
    tags?: imagesCreatetagsInput | string[]
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    uploaded_by?: bigint | number | null
  }

  export type imagesUncheckedCreateInput = {
    id?: bigint | number
    uuid?: string | null
    entity_type: string
    entity_id: bigint | number
    filename: string
    storage_path: string
    url?: string | null
    mime_type?: string
    width_px?: number | null
    height_px?: number | null
    size_bytes?: bigint | number | null
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: string | null
    is_primary?: boolean
    tags?: imagesCreatetagsInput | string[]
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    uploaded_by?: bigint | number | null
  }

  export type imagesUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    entity_type?: StringFieldUpdateOperationsInput | string
    entity_id?: BigIntFieldUpdateOperationsInput | bigint | number
    filename?: StringFieldUpdateOperationsInput | string
    storage_path?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    mime_type?: StringFieldUpdateOperationsInput | string
    width_px?: NullableIntFieldUpdateOperationsInput | number | null
    height_px?: NullableIntFieldUpdateOperationsInput | number | null
    size_bytes?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    compressed?: BoolFieldUpdateOperationsInput | boolean
    encrypted?: BoolFieldUpdateOperationsInput | boolean
    checksum_sha256?: NullableStringFieldUpdateOperationsInput | string | null
    is_primary?: BoolFieldUpdateOperationsInput | boolean
    tags?: imagesUpdatetagsInput | string[]
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    uploaded_by?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
  }

  export type imagesUncheckedUpdateInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    entity_type?: StringFieldUpdateOperationsInput | string
    entity_id?: BigIntFieldUpdateOperationsInput | bigint | number
    filename?: StringFieldUpdateOperationsInput | string
    storage_path?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    mime_type?: StringFieldUpdateOperationsInput | string
    width_px?: NullableIntFieldUpdateOperationsInput | number | null
    height_px?: NullableIntFieldUpdateOperationsInput | number | null
    size_bytes?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    compressed?: BoolFieldUpdateOperationsInput | boolean
    encrypted?: BoolFieldUpdateOperationsInput | boolean
    checksum_sha256?: NullableStringFieldUpdateOperationsInput | string | null
    is_primary?: BoolFieldUpdateOperationsInput | boolean
    tags?: imagesUpdatetagsInput | string[]
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    uploaded_by?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
  }

  export type imagesCreateManyInput = {
    id?: bigint | number
    uuid?: string | null
    entity_type: string
    entity_id: bigint | number
    filename: string
    storage_path: string
    url?: string | null
    mime_type?: string
    width_px?: number | null
    height_px?: number | null
    size_bytes?: bigint | number | null
    compressed?: boolean
    encrypted?: boolean
    checksum_sha256?: string | null
    is_primary?: boolean
    tags?: imagesCreatetagsInput | string[]
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    uploaded_by?: bigint | number | null
  }

  export type imagesUpdateManyMutationInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    entity_type?: StringFieldUpdateOperationsInput | string
    entity_id?: BigIntFieldUpdateOperationsInput | bigint | number
    filename?: StringFieldUpdateOperationsInput | string
    storage_path?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    mime_type?: StringFieldUpdateOperationsInput | string
    width_px?: NullableIntFieldUpdateOperationsInput | number | null
    height_px?: NullableIntFieldUpdateOperationsInput | number | null
    size_bytes?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    compressed?: BoolFieldUpdateOperationsInput | boolean
    encrypted?: BoolFieldUpdateOperationsInput | boolean
    checksum_sha256?: NullableStringFieldUpdateOperationsInput | string | null
    is_primary?: BoolFieldUpdateOperationsInput | boolean
    tags?: imagesUpdatetagsInput | string[]
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    uploaded_by?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
  }

  export type imagesUncheckedUpdateManyInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    entity_type?: StringFieldUpdateOperationsInput | string
    entity_id?: BigIntFieldUpdateOperationsInput | bigint | number
    filename?: StringFieldUpdateOperationsInput | string
    storage_path?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    mime_type?: StringFieldUpdateOperationsInput | string
    width_px?: NullableIntFieldUpdateOperationsInput | number | null
    height_px?: NullableIntFieldUpdateOperationsInput | number | null
    size_bytes?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    compressed?: BoolFieldUpdateOperationsInput | boolean
    encrypted?: BoolFieldUpdateOperationsInput | boolean
    checksum_sha256?: NullableStringFieldUpdateOperationsInput | string | null
    is_primary?: BoolFieldUpdateOperationsInput | boolean
    tags?: imagesUpdatetagsInput | string[]
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    uploaded_by?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
  }

  export type BigIntFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntFilter<$PrismaModel> | bigint | number
  }

  export type UuidNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedUuidNullableFilter<$PrismaModel> | string | null
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }
  export type JsonFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonFilterBase<$PrismaModel>>, 'path'>>

  export type JsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type OrganisationsScalarRelationFilter = {
    is?: organisationsWhereInput
    isNot?: organisationsWhereInput
  }

  export type DevicesListRelationFilter = {
    every?: devicesWhereInput
    some?: devicesWhereInput
    none?: devicesWhereInput
  }

  export type User_asset_accessListRelationFilter = {
    every?: user_asset_accessWhereInput
    some?: user_asset_accessWhereInput
    none?: user_asset_accessWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type devicesOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type user_asset_accessOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type assetsCountOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    organisation_id?: SortOrder
    name?: SortOrder
    asset_type?: SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type assetsAvgOrderByAggregateInput = {
    id?: SortOrder
    organisation_id?: SortOrder
  }

  export type assetsMaxOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    organisation_id?: SortOrder
    name?: SortOrder
    asset_type?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type assetsMinOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    organisation_id?: SortOrder
    name?: SortOrder
    asset_type?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type assetsSumOrderByAggregateInput = {
    id?: SortOrder
    organisation_id?: SortOrder
  }

  export type BigIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntWithAggregatesFilter<$PrismaModel> | bigint | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedBigIntFilter<$PrismaModel>
    _min?: NestedBigIntFilter<$PrismaModel>
    _max?: NestedBigIntFilter<$PrismaModel>
  }

  export type UuidNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedUuidNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }
  export type JsonWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedJsonFilter<$PrismaModel>
    _max?: NestedJsonFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type BigIntNullableFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel> | null
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel> | null
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel> | null
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntNullableFilter<$PrismaModel> | bigint | number | null
  }

  export type AssetsNullableScalarRelationFilter = {
    is?: assetsWhereInput | null
    isNot?: assetsWhereInput | null
  }

  export type User_device_accessListRelationFilter = {
    every?: user_device_accessWhereInput
    some?: user_device_accessWhereInput
    none?: user_device_accessWhereInput
  }

  export type user_device_accessOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type devicesExternal_idExternal_id_typeCompoundUniqueInput = {
    external_id: string
    external_id_type: string
  }

  export type devicesCountOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    organisation_id?: SortOrder
    asset_id?: SortOrder
    external_id?: SortOrder
    external_id_type?: SortOrder
    protocol?: SortOrder
    vendor?: SortOrder
    model?: SortOrder
    status?: SortOrder
    attributes?: SortOrder
    last_telemetry?: SortOrder
    last_telemetry_ts?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type devicesAvgOrderByAggregateInput = {
    id?: SortOrder
    organisation_id?: SortOrder
    asset_id?: SortOrder
  }

  export type devicesMaxOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    organisation_id?: SortOrder
    asset_id?: SortOrder
    external_id?: SortOrder
    external_id_type?: SortOrder
    protocol?: SortOrder
    vendor?: SortOrder
    model?: SortOrder
    status?: SortOrder
    last_telemetry_ts?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type devicesMinOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    organisation_id?: SortOrder
    asset_id?: SortOrder
    external_id?: SortOrder
    external_id_type?: SortOrder
    protocol?: SortOrder
    vendor?: SortOrder
    model?: SortOrder
    status?: SortOrder
    last_telemetry_ts?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type devicesSumOrderByAggregateInput = {
    id?: SortOrder
    organisation_id?: SortOrder
    asset_id?: SortOrder
  }

  export type BigIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel> | null
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel> | null
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel> | null
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntNullableWithAggregatesFilter<$PrismaModel> | bigint | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedBigIntNullableFilter<$PrismaModel>
    _min?: NestedBigIntNullableFilter<$PrismaModel>
    _max?: NestedBigIntNullableFilter<$PrismaModel>
  }

  export type UuidFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedUuidFilter<$PrismaModel> | string
  }

  export type BoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type AssetsListRelationFilter = {
    every?: assetsWhereInput
    some?: assetsWhereInput
    none?: assetsWhereInput
  }

  export type OrganisationsNullableScalarRelationFilter = {
    is?: organisationsWhereInput | null
    isNot?: organisationsWhereInput | null
  }

  export type OrganisationsListRelationFilter = {
    every?: organisationsWhereInput
    some?: organisationsWhereInput
    none?: organisationsWhereInput
  }

  export type User_organisation_accessListRelationFilter = {
    every?: user_organisation_accessWhereInput
    some?: user_organisation_accessWhereInput
    none?: user_organisation_accessWhereInput
  }

  export type UsersListRelationFilter = {
    every?: usersWhereInput
    some?: usersWhereInput
    none?: usersWhereInput
  }

  export type assetsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type organisationsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type user_organisation_accessOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type usersOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type organisationsCountOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    name?: SortOrder
    parent_org_id?: SortOrder
    path?: SortOrder
    maps_api_key?: SortOrder
    can_inherit_key?: SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type organisationsAvgOrderByAggregateInput = {
    id?: SortOrder
    parent_org_id?: SortOrder
  }

  export type organisationsMaxOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    name?: SortOrder
    parent_org_id?: SortOrder
    path?: SortOrder
    maps_api_key?: SortOrder
    can_inherit_key?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type organisationsMinOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    name?: SortOrder
    parent_org_id?: SortOrder
    path?: SortOrder
    maps_api_key?: SortOrder
    can_inherit_key?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
  }

  export type organisationsSumOrderByAggregateInput = {
    id?: SortOrder
    parent_org_id?: SortOrder
  }

  export type UuidWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedUuidWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type BoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type Role_permissionsListRelationFilter = {
    every?: role_permissionsWhereInput
    some?: role_permissionsWhereInput
    none?: role_permissionsWhereInput
  }

  export type role_permissionsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type permissionsCountOrderByAggregateInput = {
    perm_id?: SortOrder
    key?: SortOrder
    description?: SortOrder
  }

  export type permissionsAvgOrderByAggregateInput = {
    perm_id?: SortOrder
  }

  export type permissionsMaxOrderByAggregateInput = {
    perm_id?: SortOrder
    key?: SortOrder
    description?: SortOrder
  }

  export type permissionsMinOrderByAggregateInput = {
    perm_id?: SortOrder
    key?: SortOrder
    description?: SortOrder
  }

  export type permissionsSumOrderByAggregateInput = {
    perm_id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type PermissionsScalarRelationFilter = {
    is?: permissionsWhereInput
    isNot?: permissionsWhereInput
  }

  export type RolesScalarRelationFilter = {
    is?: rolesWhereInput
    isNot?: rolesWhereInput
  }

  export type role_permissionsRole_idPerm_idCompoundUniqueInput = {
    role_id: number
    perm_id: number
  }

  export type role_permissionsCountOrderByAggregateInput = {
    role_id?: SortOrder
    perm_id?: SortOrder
  }

  export type role_permissionsAvgOrderByAggregateInput = {
    role_id?: SortOrder
    perm_id?: SortOrder
  }

  export type role_permissionsMaxOrderByAggregateInput = {
    role_id?: SortOrder
    perm_id?: SortOrder
  }

  export type role_permissionsMinOrderByAggregateInput = {
    role_id?: SortOrder
    perm_id?: SortOrder
  }

  export type role_permissionsSumOrderByAggregateInput = {
    role_id?: SortOrder
    perm_id?: SortOrder
  }

  export type rolesCountOrderByAggregateInput = {
    role_id?: SortOrder
    name?: SortOrder
  }

  export type rolesAvgOrderByAggregateInput = {
    role_id?: SortOrder
  }

  export type rolesMaxOrderByAggregateInput = {
    role_id?: SortOrder
    name?: SortOrder
  }

  export type rolesMinOrderByAggregateInput = {
    role_id?: SortOrder
    name?: SortOrder
  }

  export type rolesSumOrderByAggregateInput = {
    role_id?: SortOrder
  }

  export type telemetryIdHappened_atCompoundUniqueInput = {
    id: bigint | number
    happened_at: Date | string
  }

  export type telemetryCountOrderByAggregateInput = {
    id?: SortOrder
    device_id?: SortOrder
    asset_id?: SortOrder
    organisation_id?: SortOrder
    happened_at?: SortOrder
    protocol?: SortOrder
    vendor?: SortOrder
    model?: SortOrder
    telemetry?: SortOrder
    created_at?: SortOrder
  }

  export type telemetryAvgOrderByAggregateInput = {
    id?: SortOrder
    device_id?: SortOrder
    asset_id?: SortOrder
    organisation_id?: SortOrder
  }

  export type telemetryMaxOrderByAggregateInput = {
    id?: SortOrder
    device_id?: SortOrder
    asset_id?: SortOrder
    organisation_id?: SortOrder
    happened_at?: SortOrder
    protocol?: SortOrder
    vendor?: SortOrder
    model?: SortOrder
    created_at?: SortOrder
  }

  export type telemetryMinOrderByAggregateInput = {
    id?: SortOrder
    device_id?: SortOrder
    asset_id?: SortOrder
    organisation_id?: SortOrder
    happened_at?: SortOrder
    protocol?: SortOrder
    vendor?: SortOrder
    model?: SortOrder
    created_at?: SortOrder
  }

  export type telemetrySumOrderByAggregateInput = {
    id?: SortOrder
    device_id?: SortOrder
    asset_id?: SortOrder
    organisation_id?: SortOrder
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type usersCountOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    first_name?: SortOrder
    last_name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role_id?: SortOrder
    organisation_id?: SortOrder
    active?: SortOrder
    last_login_at?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    token_version?: SortOrder
  }

  export type usersAvgOrderByAggregateInput = {
    id?: SortOrder
    role_id?: SortOrder
    organisation_id?: SortOrder
    token_version?: SortOrder
  }

  export type usersMaxOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    first_name?: SortOrder
    last_name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role_id?: SortOrder
    organisation_id?: SortOrder
    active?: SortOrder
    last_login_at?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    token_version?: SortOrder
  }

  export type usersMinOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    first_name?: SortOrder
    last_name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role_id?: SortOrder
    organisation_id?: SortOrder
    active?: SortOrder
    last_login_at?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    token_version?: SortOrder
  }

  export type usersSumOrderByAggregateInput = {
    id?: SortOrder
    role_id?: SortOrder
    organisation_id?: SortOrder
    token_version?: SortOrder
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type codec12_commandsCountOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    imei?: SortOrder
    command?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    sent_at?: SortOrder
    responded_at?: SortOrder
    response?: SortOrder
    retries?: SortOrder
    comment?: SortOrder
  }

  export type codec12_commandsAvgOrderByAggregateInput = {
    id?: SortOrder
    retries?: SortOrder
  }

  export type codec12_commandsMaxOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    imei?: SortOrder
    command?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    sent_at?: SortOrder
    responded_at?: SortOrder
    response?: SortOrder
    retries?: SortOrder
    comment?: SortOrder
  }

  export type codec12_commandsMinOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    imei?: SortOrder
    command?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
    updated_at?: SortOrder
    sent_at?: SortOrder
    responded_at?: SortOrder
    response?: SortOrder
    retries?: SortOrder
    comment?: SortOrder
  }

  export type codec12_commandsSumOrderByAggregateInput = {
    id?: SortOrder
    retries?: SortOrder
  }

  export type UsersScalarRelationFilter = {
    is?: usersWhereInput
    isNot?: usersWhereInput
  }

  export type user_organisation_accessUser_idOrganisation_idCompoundUniqueInput = {
    user_id: bigint | number
    organisation_id: bigint | number
  }

  export type user_organisation_accessCountOrderByAggregateInput = {
    user_id?: SortOrder
    organisation_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_organisation_accessAvgOrderByAggregateInput = {
    user_id?: SortOrder
    organisation_id?: SortOrder
  }

  export type user_organisation_accessMaxOrderByAggregateInput = {
    user_id?: SortOrder
    organisation_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_organisation_accessMinOrderByAggregateInput = {
    user_id?: SortOrder
    organisation_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_organisation_accessSumOrderByAggregateInput = {
    user_id?: SortOrder
    organisation_id?: SortOrder
  }

  export type AssetsScalarRelationFilter = {
    is?: assetsWhereInput
    isNot?: assetsWhereInput
  }

  export type user_asset_accessUser_idAsset_idCompoundUniqueInput = {
    user_id: bigint | number
    asset_id: bigint | number
  }

  export type user_asset_accessCountOrderByAggregateInput = {
    user_id?: SortOrder
    asset_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_asset_accessAvgOrderByAggregateInput = {
    user_id?: SortOrder
    asset_id?: SortOrder
  }

  export type user_asset_accessMaxOrderByAggregateInput = {
    user_id?: SortOrder
    asset_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_asset_accessMinOrderByAggregateInput = {
    user_id?: SortOrder
    asset_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_asset_accessSumOrderByAggregateInput = {
    user_id?: SortOrder
    asset_id?: SortOrder
  }

  export type DevicesScalarRelationFilter = {
    is?: devicesWhereInput
    isNot?: devicesWhereInput
  }

  export type user_device_accessUser_idDevice_idCompoundUniqueInput = {
    user_id: bigint | number
    device_id: bigint | number
  }

  export type user_device_accessCountOrderByAggregateInput = {
    user_id?: SortOrder
    device_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_device_accessAvgOrderByAggregateInput = {
    user_id?: SortOrder
    device_id?: SortOrder
  }

  export type user_device_accessMaxOrderByAggregateInput = {
    user_id?: SortOrder
    device_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_device_accessMinOrderByAggregateInput = {
    user_id?: SortOrder
    device_id?: SortOrder
    is_allowed?: SortOrder
  }

  export type user_device_accessSumOrderByAggregateInput = {
    user_id?: SortOrder
    device_id?: SortOrder
  }

  export type filesCountOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrder
    mime_type?: SortOrder
    size_bytes?: SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrder
    file_type?: SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrder
  }

  export type filesAvgOrderByAggregateInput = {
    id?: SortOrder
    entity_id?: SortOrder
    size_bytes?: SortOrder
    uploaded_by?: SortOrder
  }

  export type filesMaxOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrder
    mime_type?: SortOrder
    size_bytes?: SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrder
    file_type?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrder
  }

  export type filesMinOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrder
    mime_type?: SortOrder
    size_bytes?: SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrder
    file_type?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrder
  }

  export type filesSumOrderByAggregateInput = {
    id?: SortOrder
    entity_id?: SortOrder
    size_bytes?: SortOrder
    uploaded_by?: SortOrder
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type StringNullableListFilter<$PrismaModel = never> = {
    equals?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    has?: string | StringFieldRefInput<$PrismaModel> | null
    hasEvery?: string[] | ListStringFieldRefInput<$PrismaModel>
    hasSome?: string[] | ListStringFieldRefInput<$PrismaModel>
    isEmpty?: boolean
  }

  export type imagesCountOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrder
    mime_type?: SortOrder
    width_px?: SortOrder
    height_px?: SortOrder
    size_bytes?: SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrder
    is_primary?: SortOrder
    tags?: SortOrder
    attributes?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrder
  }

  export type imagesAvgOrderByAggregateInput = {
    id?: SortOrder
    entity_id?: SortOrder
    width_px?: SortOrder
    height_px?: SortOrder
    size_bytes?: SortOrder
    uploaded_by?: SortOrder
  }

  export type imagesMaxOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrder
    mime_type?: SortOrder
    width_px?: SortOrder
    height_px?: SortOrder
    size_bytes?: SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrder
    is_primary?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrder
  }

  export type imagesMinOrderByAggregateInput = {
    id?: SortOrder
    uuid?: SortOrder
    entity_type?: SortOrder
    entity_id?: SortOrder
    filename?: SortOrder
    storage_path?: SortOrder
    url?: SortOrder
    mime_type?: SortOrder
    width_px?: SortOrder
    height_px?: SortOrder
    size_bytes?: SortOrder
    compressed?: SortOrder
    encrypted?: SortOrder
    checksum_sha256?: SortOrder
    is_primary?: SortOrder
    created_at?: SortOrder
    uploaded_by?: SortOrder
  }

  export type imagesSumOrderByAggregateInput = {
    id?: SortOrder
    entity_id?: SortOrder
    width_px?: SortOrder
    height_px?: SortOrder
    size_bytes?: SortOrder
    uploaded_by?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type organisationsCreateNestedOneWithoutAssetsInput = {
    create?: XOR<organisationsCreateWithoutAssetsInput, organisationsUncheckedCreateWithoutAssetsInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutAssetsInput
    connect?: organisationsWhereUniqueInput
  }

  export type devicesCreateNestedManyWithoutAssetsInput = {
    create?: XOR<devicesCreateWithoutAssetsInput, devicesUncheckedCreateWithoutAssetsInput> | devicesCreateWithoutAssetsInput[] | devicesUncheckedCreateWithoutAssetsInput[]
    connectOrCreate?: devicesCreateOrConnectWithoutAssetsInput | devicesCreateOrConnectWithoutAssetsInput[]
    createMany?: devicesCreateManyAssetsInputEnvelope
    connect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
  }

  export type user_asset_accessCreateNestedManyWithoutAssetsInput = {
    create?: XOR<user_asset_accessCreateWithoutAssetsInput, user_asset_accessUncheckedCreateWithoutAssetsInput> | user_asset_accessCreateWithoutAssetsInput[] | user_asset_accessUncheckedCreateWithoutAssetsInput[]
    connectOrCreate?: user_asset_accessCreateOrConnectWithoutAssetsInput | user_asset_accessCreateOrConnectWithoutAssetsInput[]
    createMany?: user_asset_accessCreateManyAssetsInputEnvelope
    connect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
  }

  export type devicesUncheckedCreateNestedManyWithoutAssetsInput = {
    create?: XOR<devicesCreateWithoutAssetsInput, devicesUncheckedCreateWithoutAssetsInput> | devicesCreateWithoutAssetsInput[] | devicesUncheckedCreateWithoutAssetsInput[]
    connectOrCreate?: devicesCreateOrConnectWithoutAssetsInput | devicesCreateOrConnectWithoutAssetsInput[]
    createMany?: devicesCreateManyAssetsInputEnvelope
    connect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
  }

  export type user_asset_accessUncheckedCreateNestedManyWithoutAssetsInput = {
    create?: XOR<user_asset_accessCreateWithoutAssetsInput, user_asset_accessUncheckedCreateWithoutAssetsInput> | user_asset_accessCreateWithoutAssetsInput[] | user_asset_accessUncheckedCreateWithoutAssetsInput[]
    connectOrCreate?: user_asset_accessCreateOrConnectWithoutAssetsInput | user_asset_accessCreateOrConnectWithoutAssetsInput[]
    createMany?: user_asset_accessCreateManyAssetsInputEnvelope
    connect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
  }

  export type BigIntFieldUpdateOperationsInput = {
    set?: bigint | number
    increment?: bigint | number
    decrement?: bigint | number
    multiply?: bigint | number
    divide?: bigint | number
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type organisationsUpdateOneRequiredWithoutAssetsNestedInput = {
    create?: XOR<organisationsCreateWithoutAssetsInput, organisationsUncheckedCreateWithoutAssetsInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutAssetsInput
    upsert?: organisationsUpsertWithoutAssetsInput
    connect?: organisationsWhereUniqueInput
    update?: XOR<XOR<organisationsUpdateToOneWithWhereWithoutAssetsInput, organisationsUpdateWithoutAssetsInput>, organisationsUncheckedUpdateWithoutAssetsInput>
  }

  export type devicesUpdateManyWithoutAssetsNestedInput = {
    create?: XOR<devicesCreateWithoutAssetsInput, devicesUncheckedCreateWithoutAssetsInput> | devicesCreateWithoutAssetsInput[] | devicesUncheckedCreateWithoutAssetsInput[]
    connectOrCreate?: devicesCreateOrConnectWithoutAssetsInput | devicesCreateOrConnectWithoutAssetsInput[]
    upsert?: devicesUpsertWithWhereUniqueWithoutAssetsInput | devicesUpsertWithWhereUniqueWithoutAssetsInput[]
    createMany?: devicesCreateManyAssetsInputEnvelope
    set?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    disconnect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    delete?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    connect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    update?: devicesUpdateWithWhereUniqueWithoutAssetsInput | devicesUpdateWithWhereUniqueWithoutAssetsInput[]
    updateMany?: devicesUpdateManyWithWhereWithoutAssetsInput | devicesUpdateManyWithWhereWithoutAssetsInput[]
    deleteMany?: devicesScalarWhereInput | devicesScalarWhereInput[]
  }

  export type user_asset_accessUpdateManyWithoutAssetsNestedInput = {
    create?: XOR<user_asset_accessCreateWithoutAssetsInput, user_asset_accessUncheckedCreateWithoutAssetsInput> | user_asset_accessCreateWithoutAssetsInput[] | user_asset_accessUncheckedCreateWithoutAssetsInput[]
    connectOrCreate?: user_asset_accessCreateOrConnectWithoutAssetsInput | user_asset_accessCreateOrConnectWithoutAssetsInput[]
    upsert?: user_asset_accessUpsertWithWhereUniqueWithoutAssetsInput | user_asset_accessUpsertWithWhereUniqueWithoutAssetsInput[]
    createMany?: user_asset_accessCreateManyAssetsInputEnvelope
    set?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    disconnect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    delete?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    connect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    update?: user_asset_accessUpdateWithWhereUniqueWithoutAssetsInput | user_asset_accessUpdateWithWhereUniqueWithoutAssetsInput[]
    updateMany?: user_asset_accessUpdateManyWithWhereWithoutAssetsInput | user_asset_accessUpdateManyWithWhereWithoutAssetsInput[]
    deleteMany?: user_asset_accessScalarWhereInput | user_asset_accessScalarWhereInput[]
  }

  export type devicesUncheckedUpdateManyWithoutAssetsNestedInput = {
    create?: XOR<devicesCreateWithoutAssetsInput, devicesUncheckedCreateWithoutAssetsInput> | devicesCreateWithoutAssetsInput[] | devicesUncheckedCreateWithoutAssetsInput[]
    connectOrCreate?: devicesCreateOrConnectWithoutAssetsInput | devicesCreateOrConnectWithoutAssetsInput[]
    upsert?: devicesUpsertWithWhereUniqueWithoutAssetsInput | devicesUpsertWithWhereUniqueWithoutAssetsInput[]
    createMany?: devicesCreateManyAssetsInputEnvelope
    set?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    disconnect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    delete?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    connect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    update?: devicesUpdateWithWhereUniqueWithoutAssetsInput | devicesUpdateWithWhereUniqueWithoutAssetsInput[]
    updateMany?: devicesUpdateManyWithWhereWithoutAssetsInput | devicesUpdateManyWithWhereWithoutAssetsInput[]
    deleteMany?: devicesScalarWhereInput | devicesScalarWhereInput[]
  }

  export type user_asset_accessUncheckedUpdateManyWithoutAssetsNestedInput = {
    create?: XOR<user_asset_accessCreateWithoutAssetsInput, user_asset_accessUncheckedCreateWithoutAssetsInput> | user_asset_accessCreateWithoutAssetsInput[] | user_asset_accessUncheckedCreateWithoutAssetsInput[]
    connectOrCreate?: user_asset_accessCreateOrConnectWithoutAssetsInput | user_asset_accessCreateOrConnectWithoutAssetsInput[]
    upsert?: user_asset_accessUpsertWithWhereUniqueWithoutAssetsInput | user_asset_accessUpsertWithWhereUniqueWithoutAssetsInput[]
    createMany?: user_asset_accessCreateManyAssetsInputEnvelope
    set?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    disconnect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    delete?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    connect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    update?: user_asset_accessUpdateWithWhereUniqueWithoutAssetsInput | user_asset_accessUpdateWithWhereUniqueWithoutAssetsInput[]
    updateMany?: user_asset_accessUpdateManyWithWhereWithoutAssetsInput | user_asset_accessUpdateManyWithWhereWithoutAssetsInput[]
    deleteMany?: user_asset_accessScalarWhereInput | user_asset_accessScalarWhereInput[]
  }

  export type assetsCreateNestedOneWithoutDevicesInput = {
    create?: XOR<assetsCreateWithoutDevicesInput, assetsUncheckedCreateWithoutDevicesInput>
    connectOrCreate?: assetsCreateOrConnectWithoutDevicesInput
    connect?: assetsWhereUniqueInput
  }

  export type organisationsCreateNestedOneWithoutDevicesInput = {
    create?: XOR<organisationsCreateWithoutDevicesInput, organisationsUncheckedCreateWithoutDevicesInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutDevicesInput
    connect?: organisationsWhereUniqueInput
  }

  export type user_device_accessCreateNestedManyWithoutDevicesInput = {
    create?: XOR<user_device_accessCreateWithoutDevicesInput, user_device_accessUncheckedCreateWithoutDevicesInput> | user_device_accessCreateWithoutDevicesInput[] | user_device_accessUncheckedCreateWithoutDevicesInput[]
    connectOrCreate?: user_device_accessCreateOrConnectWithoutDevicesInput | user_device_accessCreateOrConnectWithoutDevicesInput[]
    createMany?: user_device_accessCreateManyDevicesInputEnvelope
    connect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
  }

  export type user_device_accessUncheckedCreateNestedManyWithoutDevicesInput = {
    create?: XOR<user_device_accessCreateWithoutDevicesInput, user_device_accessUncheckedCreateWithoutDevicesInput> | user_device_accessCreateWithoutDevicesInput[] | user_device_accessUncheckedCreateWithoutDevicesInput[]
    connectOrCreate?: user_device_accessCreateOrConnectWithoutDevicesInput | user_device_accessCreateOrConnectWithoutDevicesInput[]
    createMany?: user_device_accessCreateManyDevicesInputEnvelope
    connect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
  }

  export type assetsUpdateOneWithoutDevicesNestedInput = {
    create?: XOR<assetsCreateWithoutDevicesInput, assetsUncheckedCreateWithoutDevicesInput>
    connectOrCreate?: assetsCreateOrConnectWithoutDevicesInput
    upsert?: assetsUpsertWithoutDevicesInput
    disconnect?: assetsWhereInput | boolean
    delete?: assetsWhereInput | boolean
    connect?: assetsWhereUniqueInput
    update?: XOR<XOR<assetsUpdateToOneWithWhereWithoutDevicesInput, assetsUpdateWithoutDevicesInput>, assetsUncheckedUpdateWithoutDevicesInput>
  }

  export type organisationsUpdateOneRequiredWithoutDevicesNestedInput = {
    create?: XOR<organisationsCreateWithoutDevicesInput, organisationsUncheckedCreateWithoutDevicesInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutDevicesInput
    upsert?: organisationsUpsertWithoutDevicesInput
    connect?: organisationsWhereUniqueInput
    update?: XOR<XOR<organisationsUpdateToOneWithWhereWithoutDevicesInput, organisationsUpdateWithoutDevicesInput>, organisationsUncheckedUpdateWithoutDevicesInput>
  }

  export type user_device_accessUpdateManyWithoutDevicesNestedInput = {
    create?: XOR<user_device_accessCreateWithoutDevicesInput, user_device_accessUncheckedCreateWithoutDevicesInput> | user_device_accessCreateWithoutDevicesInput[] | user_device_accessUncheckedCreateWithoutDevicesInput[]
    connectOrCreate?: user_device_accessCreateOrConnectWithoutDevicesInput | user_device_accessCreateOrConnectWithoutDevicesInput[]
    upsert?: user_device_accessUpsertWithWhereUniqueWithoutDevicesInput | user_device_accessUpsertWithWhereUniqueWithoutDevicesInput[]
    createMany?: user_device_accessCreateManyDevicesInputEnvelope
    set?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    disconnect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    delete?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    connect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    update?: user_device_accessUpdateWithWhereUniqueWithoutDevicesInput | user_device_accessUpdateWithWhereUniqueWithoutDevicesInput[]
    updateMany?: user_device_accessUpdateManyWithWhereWithoutDevicesInput | user_device_accessUpdateManyWithWhereWithoutDevicesInput[]
    deleteMany?: user_device_accessScalarWhereInput | user_device_accessScalarWhereInput[]
  }

  export type NullableBigIntFieldUpdateOperationsInput = {
    set?: bigint | number | null
    increment?: bigint | number
    decrement?: bigint | number
    multiply?: bigint | number
    divide?: bigint | number
  }

  export type user_device_accessUncheckedUpdateManyWithoutDevicesNestedInput = {
    create?: XOR<user_device_accessCreateWithoutDevicesInput, user_device_accessUncheckedCreateWithoutDevicesInput> | user_device_accessCreateWithoutDevicesInput[] | user_device_accessUncheckedCreateWithoutDevicesInput[]
    connectOrCreate?: user_device_accessCreateOrConnectWithoutDevicesInput | user_device_accessCreateOrConnectWithoutDevicesInput[]
    upsert?: user_device_accessUpsertWithWhereUniqueWithoutDevicesInput | user_device_accessUpsertWithWhereUniqueWithoutDevicesInput[]
    createMany?: user_device_accessCreateManyDevicesInputEnvelope
    set?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    disconnect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    delete?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    connect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    update?: user_device_accessUpdateWithWhereUniqueWithoutDevicesInput | user_device_accessUpdateWithWhereUniqueWithoutDevicesInput[]
    updateMany?: user_device_accessUpdateManyWithWhereWithoutDevicesInput | user_device_accessUpdateManyWithWhereWithoutDevicesInput[]
    deleteMany?: user_device_accessScalarWhereInput | user_device_accessScalarWhereInput[]
  }

  export type assetsCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<assetsCreateWithoutOrganisationsInput, assetsUncheckedCreateWithoutOrganisationsInput> | assetsCreateWithoutOrganisationsInput[] | assetsUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: assetsCreateOrConnectWithoutOrganisationsInput | assetsCreateOrConnectWithoutOrganisationsInput[]
    createMany?: assetsCreateManyOrganisationsInputEnvelope
    connect?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
  }

  export type devicesCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<devicesCreateWithoutOrganisationsInput, devicesUncheckedCreateWithoutOrganisationsInput> | devicesCreateWithoutOrganisationsInput[] | devicesUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: devicesCreateOrConnectWithoutOrganisationsInput | devicesCreateOrConnectWithoutOrganisationsInput[]
    createMany?: devicesCreateManyOrganisationsInputEnvelope
    connect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
  }

  export type organisationsCreateNestedOneWithoutOther_organisationsInput = {
    create?: XOR<organisationsCreateWithoutOther_organisationsInput, organisationsUncheckedCreateWithoutOther_organisationsInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutOther_organisationsInput
    connect?: organisationsWhereUniqueInput
  }

  export type organisationsCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<organisationsCreateWithoutOrganisationsInput, organisationsUncheckedCreateWithoutOrganisationsInput> | organisationsCreateWithoutOrganisationsInput[] | organisationsUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: organisationsCreateOrConnectWithoutOrganisationsInput | organisationsCreateOrConnectWithoutOrganisationsInput[]
    createMany?: organisationsCreateManyOrganisationsInputEnvelope
    connect?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
  }

  export type user_organisation_accessCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<user_organisation_accessCreateWithoutOrganisationsInput, user_organisation_accessUncheckedCreateWithoutOrganisationsInput> | user_organisation_accessCreateWithoutOrganisationsInput[] | user_organisation_accessUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: user_organisation_accessCreateOrConnectWithoutOrganisationsInput | user_organisation_accessCreateOrConnectWithoutOrganisationsInput[]
    createMany?: user_organisation_accessCreateManyOrganisationsInputEnvelope
    connect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
  }

  export type usersCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<usersCreateWithoutOrganisationsInput, usersUncheckedCreateWithoutOrganisationsInput> | usersCreateWithoutOrganisationsInput[] | usersUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: usersCreateOrConnectWithoutOrganisationsInput | usersCreateOrConnectWithoutOrganisationsInput[]
    createMany?: usersCreateManyOrganisationsInputEnvelope
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
  }

  export type assetsUncheckedCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<assetsCreateWithoutOrganisationsInput, assetsUncheckedCreateWithoutOrganisationsInput> | assetsCreateWithoutOrganisationsInput[] | assetsUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: assetsCreateOrConnectWithoutOrganisationsInput | assetsCreateOrConnectWithoutOrganisationsInput[]
    createMany?: assetsCreateManyOrganisationsInputEnvelope
    connect?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
  }

  export type devicesUncheckedCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<devicesCreateWithoutOrganisationsInput, devicesUncheckedCreateWithoutOrganisationsInput> | devicesCreateWithoutOrganisationsInput[] | devicesUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: devicesCreateOrConnectWithoutOrganisationsInput | devicesCreateOrConnectWithoutOrganisationsInput[]
    createMany?: devicesCreateManyOrganisationsInputEnvelope
    connect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
  }

  export type organisationsUncheckedCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<organisationsCreateWithoutOrganisationsInput, organisationsUncheckedCreateWithoutOrganisationsInput> | organisationsCreateWithoutOrganisationsInput[] | organisationsUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: organisationsCreateOrConnectWithoutOrganisationsInput | organisationsCreateOrConnectWithoutOrganisationsInput[]
    createMany?: organisationsCreateManyOrganisationsInputEnvelope
    connect?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
  }

  export type user_organisation_accessUncheckedCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<user_organisation_accessCreateWithoutOrganisationsInput, user_organisation_accessUncheckedCreateWithoutOrganisationsInput> | user_organisation_accessCreateWithoutOrganisationsInput[] | user_organisation_accessUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: user_organisation_accessCreateOrConnectWithoutOrganisationsInput | user_organisation_accessCreateOrConnectWithoutOrganisationsInput[]
    createMany?: user_organisation_accessCreateManyOrganisationsInputEnvelope
    connect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
  }

  export type usersUncheckedCreateNestedManyWithoutOrganisationsInput = {
    create?: XOR<usersCreateWithoutOrganisationsInput, usersUncheckedCreateWithoutOrganisationsInput> | usersCreateWithoutOrganisationsInput[] | usersUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: usersCreateOrConnectWithoutOrganisationsInput | usersCreateOrConnectWithoutOrganisationsInput[]
    createMany?: usersCreateManyOrganisationsInputEnvelope
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
  }

  export type NullableBoolFieldUpdateOperationsInput = {
    set?: boolean | null
  }

  export type assetsUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<assetsCreateWithoutOrganisationsInput, assetsUncheckedCreateWithoutOrganisationsInput> | assetsCreateWithoutOrganisationsInput[] | assetsUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: assetsCreateOrConnectWithoutOrganisationsInput | assetsCreateOrConnectWithoutOrganisationsInput[]
    upsert?: assetsUpsertWithWhereUniqueWithoutOrganisationsInput | assetsUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: assetsCreateManyOrganisationsInputEnvelope
    set?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
    disconnect?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
    delete?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
    connect?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
    update?: assetsUpdateWithWhereUniqueWithoutOrganisationsInput | assetsUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: assetsUpdateManyWithWhereWithoutOrganisationsInput | assetsUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: assetsScalarWhereInput | assetsScalarWhereInput[]
  }

  export type devicesUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<devicesCreateWithoutOrganisationsInput, devicesUncheckedCreateWithoutOrganisationsInput> | devicesCreateWithoutOrganisationsInput[] | devicesUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: devicesCreateOrConnectWithoutOrganisationsInput | devicesCreateOrConnectWithoutOrganisationsInput[]
    upsert?: devicesUpsertWithWhereUniqueWithoutOrganisationsInput | devicesUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: devicesCreateManyOrganisationsInputEnvelope
    set?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    disconnect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    delete?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    connect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    update?: devicesUpdateWithWhereUniqueWithoutOrganisationsInput | devicesUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: devicesUpdateManyWithWhereWithoutOrganisationsInput | devicesUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: devicesScalarWhereInput | devicesScalarWhereInput[]
  }

  export type organisationsUpdateOneWithoutOther_organisationsNestedInput = {
    create?: XOR<organisationsCreateWithoutOther_organisationsInput, organisationsUncheckedCreateWithoutOther_organisationsInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutOther_organisationsInput
    upsert?: organisationsUpsertWithoutOther_organisationsInput
    disconnect?: organisationsWhereInput | boolean
    delete?: organisationsWhereInput | boolean
    connect?: organisationsWhereUniqueInput
    update?: XOR<XOR<organisationsUpdateToOneWithWhereWithoutOther_organisationsInput, organisationsUpdateWithoutOther_organisationsInput>, organisationsUncheckedUpdateWithoutOther_organisationsInput>
  }

  export type organisationsUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<organisationsCreateWithoutOrganisationsInput, organisationsUncheckedCreateWithoutOrganisationsInput> | organisationsCreateWithoutOrganisationsInput[] | organisationsUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: organisationsCreateOrConnectWithoutOrganisationsInput | organisationsCreateOrConnectWithoutOrganisationsInput[]
    upsert?: organisationsUpsertWithWhereUniqueWithoutOrganisationsInput | organisationsUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: organisationsCreateManyOrganisationsInputEnvelope
    set?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
    disconnect?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
    delete?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
    connect?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
    update?: organisationsUpdateWithWhereUniqueWithoutOrganisationsInput | organisationsUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: organisationsUpdateManyWithWhereWithoutOrganisationsInput | organisationsUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: organisationsScalarWhereInput | organisationsScalarWhereInput[]
  }

  export type user_organisation_accessUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<user_organisation_accessCreateWithoutOrganisationsInput, user_organisation_accessUncheckedCreateWithoutOrganisationsInput> | user_organisation_accessCreateWithoutOrganisationsInput[] | user_organisation_accessUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: user_organisation_accessCreateOrConnectWithoutOrganisationsInput | user_organisation_accessCreateOrConnectWithoutOrganisationsInput[]
    upsert?: user_organisation_accessUpsertWithWhereUniqueWithoutOrganisationsInput | user_organisation_accessUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: user_organisation_accessCreateManyOrganisationsInputEnvelope
    set?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    disconnect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    delete?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    connect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    update?: user_organisation_accessUpdateWithWhereUniqueWithoutOrganisationsInput | user_organisation_accessUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: user_organisation_accessUpdateManyWithWhereWithoutOrganisationsInput | user_organisation_accessUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: user_organisation_accessScalarWhereInput | user_organisation_accessScalarWhereInput[]
  }

  export type usersUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<usersCreateWithoutOrganisationsInput, usersUncheckedCreateWithoutOrganisationsInput> | usersCreateWithoutOrganisationsInput[] | usersUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: usersCreateOrConnectWithoutOrganisationsInput | usersCreateOrConnectWithoutOrganisationsInput[]
    upsert?: usersUpsertWithWhereUniqueWithoutOrganisationsInput | usersUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: usersCreateManyOrganisationsInputEnvelope
    set?: usersWhereUniqueInput | usersWhereUniqueInput[]
    disconnect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    delete?: usersWhereUniqueInput | usersWhereUniqueInput[]
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    update?: usersUpdateWithWhereUniqueWithoutOrganisationsInput | usersUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: usersUpdateManyWithWhereWithoutOrganisationsInput | usersUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: usersScalarWhereInput | usersScalarWhereInput[]
  }

  export type assetsUncheckedUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<assetsCreateWithoutOrganisationsInput, assetsUncheckedCreateWithoutOrganisationsInput> | assetsCreateWithoutOrganisationsInput[] | assetsUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: assetsCreateOrConnectWithoutOrganisationsInput | assetsCreateOrConnectWithoutOrganisationsInput[]
    upsert?: assetsUpsertWithWhereUniqueWithoutOrganisationsInput | assetsUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: assetsCreateManyOrganisationsInputEnvelope
    set?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
    disconnect?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
    delete?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
    connect?: assetsWhereUniqueInput | assetsWhereUniqueInput[]
    update?: assetsUpdateWithWhereUniqueWithoutOrganisationsInput | assetsUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: assetsUpdateManyWithWhereWithoutOrganisationsInput | assetsUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: assetsScalarWhereInput | assetsScalarWhereInput[]
  }

  export type devicesUncheckedUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<devicesCreateWithoutOrganisationsInput, devicesUncheckedCreateWithoutOrganisationsInput> | devicesCreateWithoutOrganisationsInput[] | devicesUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: devicesCreateOrConnectWithoutOrganisationsInput | devicesCreateOrConnectWithoutOrganisationsInput[]
    upsert?: devicesUpsertWithWhereUniqueWithoutOrganisationsInput | devicesUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: devicesCreateManyOrganisationsInputEnvelope
    set?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    disconnect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    delete?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    connect?: devicesWhereUniqueInput | devicesWhereUniqueInput[]
    update?: devicesUpdateWithWhereUniqueWithoutOrganisationsInput | devicesUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: devicesUpdateManyWithWhereWithoutOrganisationsInput | devicesUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: devicesScalarWhereInput | devicesScalarWhereInput[]
  }

  export type organisationsUncheckedUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<organisationsCreateWithoutOrganisationsInput, organisationsUncheckedCreateWithoutOrganisationsInput> | organisationsCreateWithoutOrganisationsInput[] | organisationsUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: organisationsCreateOrConnectWithoutOrganisationsInput | organisationsCreateOrConnectWithoutOrganisationsInput[]
    upsert?: organisationsUpsertWithWhereUniqueWithoutOrganisationsInput | organisationsUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: organisationsCreateManyOrganisationsInputEnvelope
    set?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
    disconnect?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
    delete?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
    connect?: organisationsWhereUniqueInput | organisationsWhereUniqueInput[]
    update?: organisationsUpdateWithWhereUniqueWithoutOrganisationsInput | organisationsUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: organisationsUpdateManyWithWhereWithoutOrganisationsInput | organisationsUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: organisationsScalarWhereInput | organisationsScalarWhereInput[]
  }

  export type user_organisation_accessUncheckedUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<user_organisation_accessCreateWithoutOrganisationsInput, user_organisation_accessUncheckedCreateWithoutOrganisationsInput> | user_organisation_accessCreateWithoutOrganisationsInput[] | user_organisation_accessUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: user_organisation_accessCreateOrConnectWithoutOrganisationsInput | user_organisation_accessCreateOrConnectWithoutOrganisationsInput[]
    upsert?: user_organisation_accessUpsertWithWhereUniqueWithoutOrganisationsInput | user_organisation_accessUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: user_organisation_accessCreateManyOrganisationsInputEnvelope
    set?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    disconnect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    delete?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    connect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    update?: user_organisation_accessUpdateWithWhereUniqueWithoutOrganisationsInput | user_organisation_accessUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: user_organisation_accessUpdateManyWithWhereWithoutOrganisationsInput | user_organisation_accessUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: user_organisation_accessScalarWhereInput | user_organisation_accessScalarWhereInput[]
  }

  export type usersUncheckedUpdateManyWithoutOrganisationsNestedInput = {
    create?: XOR<usersCreateWithoutOrganisationsInput, usersUncheckedCreateWithoutOrganisationsInput> | usersCreateWithoutOrganisationsInput[] | usersUncheckedCreateWithoutOrganisationsInput[]
    connectOrCreate?: usersCreateOrConnectWithoutOrganisationsInput | usersCreateOrConnectWithoutOrganisationsInput[]
    upsert?: usersUpsertWithWhereUniqueWithoutOrganisationsInput | usersUpsertWithWhereUniqueWithoutOrganisationsInput[]
    createMany?: usersCreateManyOrganisationsInputEnvelope
    set?: usersWhereUniqueInput | usersWhereUniqueInput[]
    disconnect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    delete?: usersWhereUniqueInput | usersWhereUniqueInput[]
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    update?: usersUpdateWithWhereUniqueWithoutOrganisationsInput | usersUpdateWithWhereUniqueWithoutOrganisationsInput[]
    updateMany?: usersUpdateManyWithWhereWithoutOrganisationsInput | usersUpdateManyWithWhereWithoutOrganisationsInput[]
    deleteMany?: usersScalarWhereInput | usersScalarWhereInput[]
  }

  export type role_permissionsCreateNestedManyWithoutPermissionsInput = {
    create?: XOR<role_permissionsCreateWithoutPermissionsInput, role_permissionsUncheckedCreateWithoutPermissionsInput> | role_permissionsCreateWithoutPermissionsInput[] | role_permissionsUncheckedCreateWithoutPermissionsInput[]
    connectOrCreate?: role_permissionsCreateOrConnectWithoutPermissionsInput | role_permissionsCreateOrConnectWithoutPermissionsInput[]
    createMany?: role_permissionsCreateManyPermissionsInputEnvelope
    connect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
  }

  export type role_permissionsUncheckedCreateNestedManyWithoutPermissionsInput = {
    create?: XOR<role_permissionsCreateWithoutPermissionsInput, role_permissionsUncheckedCreateWithoutPermissionsInput> | role_permissionsCreateWithoutPermissionsInput[] | role_permissionsUncheckedCreateWithoutPermissionsInput[]
    connectOrCreate?: role_permissionsCreateOrConnectWithoutPermissionsInput | role_permissionsCreateOrConnectWithoutPermissionsInput[]
    createMany?: role_permissionsCreateManyPermissionsInputEnvelope
    connect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type role_permissionsUpdateManyWithoutPermissionsNestedInput = {
    create?: XOR<role_permissionsCreateWithoutPermissionsInput, role_permissionsUncheckedCreateWithoutPermissionsInput> | role_permissionsCreateWithoutPermissionsInput[] | role_permissionsUncheckedCreateWithoutPermissionsInput[]
    connectOrCreate?: role_permissionsCreateOrConnectWithoutPermissionsInput | role_permissionsCreateOrConnectWithoutPermissionsInput[]
    upsert?: role_permissionsUpsertWithWhereUniqueWithoutPermissionsInput | role_permissionsUpsertWithWhereUniqueWithoutPermissionsInput[]
    createMany?: role_permissionsCreateManyPermissionsInputEnvelope
    set?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    disconnect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    delete?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    connect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    update?: role_permissionsUpdateWithWhereUniqueWithoutPermissionsInput | role_permissionsUpdateWithWhereUniqueWithoutPermissionsInput[]
    updateMany?: role_permissionsUpdateManyWithWhereWithoutPermissionsInput | role_permissionsUpdateManyWithWhereWithoutPermissionsInput[]
    deleteMany?: role_permissionsScalarWhereInput | role_permissionsScalarWhereInput[]
  }

  export type role_permissionsUncheckedUpdateManyWithoutPermissionsNestedInput = {
    create?: XOR<role_permissionsCreateWithoutPermissionsInput, role_permissionsUncheckedCreateWithoutPermissionsInput> | role_permissionsCreateWithoutPermissionsInput[] | role_permissionsUncheckedCreateWithoutPermissionsInput[]
    connectOrCreate?: role_permissionsCreateOrConnectWithoutPermissionsInput | role_permissionsCreateOrConnectWithoutPermissionsInput[]
    upsert?: role_permissionsUpsertWithWhereUniqueWithoutPermissionsInput | role_permissionsUpsertWithWhereUniqueWithoutPermissionsInput[]
    createMany?: role_permissionsCreateManyPermissionsInputEnvelope
    set?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    disconnect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    delete?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    connect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    update?: role_permissionsUpdateWithWhereUniqueWithoutPermissionsInput | role_permissionsUpdateWithWhereUniqueWithoutPermissionsInput[]
    updateMany?: role_permissionsUpdateManyWithWhereWithoutPermissionsInput | role_permissionsUpdateManyWithWhereWithoutPermissionsInput[]
    deleteMany?: role_permissionsScalarWhereInput | role_permissionsScalarWhereInput[]
  }

  export type permissionsCreateNestedOneWithoutRole_permissionsInput = {
    create?: XOR<permissionsCreateWithoutRole_permissionsInput, permissionsUncheckedCreateWithoutRole_permissionsInput>
    connectOrCreate?: permissionsCreateOrConnectWithoutRole_permissionsInput
    connect?: permissionsWhereUniqueInput
  }

  export type rolesCreateNestedOneWithoutRole_permissionsInput = {
    create?: XOR<rolesCreateWithoutRole_permissionsInput, rolesUncheckedCreateWithoutRole_permissionsInput>
    connectOrCreate?: rolesCreateOrConnectWithoutRole_permissionsInput
    connect?: rolesWhereUniqueInput
  }

  export type permissionsUpdateOneRequiredWithoutRole_permissionsNestedInput = {
    create?: XOR<permissionsCreateWithoutRole_permissionsInput, permissionsUncheckedCreateWithoutRole_permissionsInput>
    connectOrCreate?: permissionsCreateOrConnectWithoutRole_permissionsInput
    upsert?: permissionsUpsertWithoutRole_permissionsInput
    connect?: permissionsWhereUniqueInput
    update?: XOR<XOR<permissionsUpdateToOneWithWhereWithoutRole_permissionsInput, permissionsUpdateWithoutRole_permissionsInput>, permissionsUncheckedUpdateWithoutRole_permissionsInput>
  }

  export type rolesUpdateOneRequiredWithoutRole_permissionsNestedInput = {
    create?: XOR<rolesCreateWithoutRole_permissionsInput, rolesUncheckedCreateWithoutRole_permissionsInput>
    connectOrCreate?: rolesCreateOrConnectWithoutRole_permissionsInput
    upsert?: rolesUpsertWithoutRole_permissionsInput
    connect?: rolesWhereUniqueInput
    update?: XOR<XOR<rolesUpdateToOneWithWhereWithoutRole_permissionsInput, rolesUpdateWithoutRole_permissionsInput>, rolesUncheckedUpdateWithoutRole_permissionsInput>
  }

  export type role_permissionsCreateNestedManyWithoutRolesInput = {
    create?: XOR<role_permissionsCreateWithoutRolesInput, role_permissionsUncheckedCreateWithoutRolesInput> | role_permissionsCreateWithoutRolesInput[] | role_permissionsUncheckedCreateWithoutRolesInput[]
    connectOrCreate?: role_permissionsCreateOrConnectWithoutRolesInput | role_permissionsCreateOrConnectWithoutRolesInput[]
    createMany?: role_permissionsCreateManyRolesInputEnvelope
    connect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
  }

  export type usersCreateNestedManyWithoutRolesInput = {
    create?: XOR<usersCreateWithoutRolesInput, usersUncheckedCreateWithoutRolesInput> | usersCreateWithoutRolesInput[] | usersUncheckedCreateWithoutRolesInput[]
    connectOrCreate?: usersCreateOrConnectWithoutRolesInput | usersCreateOrConnectWithoutRolesInput[]
    createMany?: usersCreateManyRolesInputEnvelope
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
  }

  export type role_permissionsUncheckedCreateNestedManyWithoutRolesInput = {
    create?: XOR<role_permissionsCreateWithoutRolesInput, role_permissionsUncheckedCreateWithoutRolesInput> | role_permissionsCreateWithoutRolesInput[] | role_permissionsUncheckedCreateWithoutRolesInput[]
    connectOrCreate?: role_permissionsCreateOrConnectWithoutRolesInput | role_permissionsCreateOrConnectWithoutRolesInput[]
    createMany?: role_permissionsCreateManyRolesInputEnvelope
    connect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
  }

  export type usersUncheckedCreateNestedManyWithoutRolesInput = {
    create?: XOR<usersCreateWithoutRolesInput, usersUncheckedCreateWithoutRolesInput> | usersCreateWithoutRolesInput[] | usersUncheckedCreateWithoutRolesInput[]
    connectOrCreate?: usersCreateOrConnectWithoutRolesInput | usersCreateOrConnectWithoutRolesInput[]
    createMany?: usersCreateManyRolesInputEnvelope
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
  }

  export type role_permissionsUpdateManyWithoutRolesNestedInput = {
    create?: XOR<role_permissionsCreateWithoutRolesInput, role_permissionsUncheckedCreateWithoutRolesInput> | role_permissionsCreateWithoutRolesInput[] | role_permissionsUncheckedCreateWithoutRolesInput[]
    connectOrCreate?: role_permissionsCreateOrConnectWithoutRolesInput | role_permissionsCreateOrConnectWithoutRolesInput[]
    upsert?: role_permissionsUpsertWithWhereUniqueWithoutRolesInput | role_permissionsUpsertWithWhereUniqueWithoutRolesInput[]
    createMany?: role_permissionsCreateManyRolesInputEnvelope
    set?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    disconnect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    delete?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    connect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    update?: role_permissionsUpdateWithWhereUniqueWithoutRolesInput | role_permissionsUpdateWithWhereUniqueWithoutRolesInput[]
    updateMany?: role_permissionsUpdateManyWithWhereWithoutRolesInput | role_permissionsUpdateManyWithWhereWithoutRolesInput[]
    deleteMany?: role_permissionsScalarWhereInput | role_permissionsScalarWhereInput[]
  }

  export type usersUpdateManyWithoutRolesNestedInput = {
    create?: XOR<usersCreateWithoutRolesInput, usersUncheckedCreateWithoutRolesInput> | usersCreateWithoutRolesInput[] | usersUncheckedCreateWithoutRolesInput[]
    connectOrCreate?: usersCreateOrConnectWithoutRolesInput | usersCreateOrConnectWithoutRolesInput[]
    upsert?: usersUpsertWithWhereUniqueWithoutRolesInput | usersUpsertWithWhereUniqueWithoutRolesInput[]
    createMany?: usersCreateManyRolesInputEnvelope
    set?: usersWhereUniqueInput | usersWhereUniqueInput[]
    disconnect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    delete?: usersWhereUniqueInput | usersWhereUniqueInput[]
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    update?: usersUpdateWithWhereUniqueWithoutRolesInput | usersUpdateWithWhereUniqueWithoutRolesInput[]
    updateMany?: usersUpdateManyWithWhereWithoutRolesInput | usersUpdateManyWithWhereWithoutRolesInput[]
    deleteMany?: usersScalarWhereInput | usersScalarWhereInput[]
  }

  export type role_permissionsUncheckedUpdateManyWithoutRolesNestedInput = {
    create?: XOR<role_permissionsCreateWithoutRolesInput, role_permissionsUncheckedCreateWithoutRolesInput> | role_permissionsCreateWithoutRolesInput[] | role_permissionsUncheckedCreateWithoutRolesInput[]
    connectOrCreate?: role_permissionsCreateOrConnectWithoutRolesInput | role_permissionsCreateOrConnectWithoutRolesInput[]
    upsert?: role_permissionsUpsertWithWhereUniqueWithoutRolesInput | role_permissionsUpsertWithWhereUniqueWithoutRolesInput[]
    createMany?: role_permissionsCreateManyRolesInputEnvelope
    set?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    disconnect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    delete?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    connect?: role_permissionsWhereUniqueInput | role_permissionsWhereUniqueInput[]
    update?: role_permissionsUpdateWithWhereUniqueWithoutRolesInput | role_permissionsUpdateWithWhereUniqueWithoutRolesInput[]
    updateMany?: role_permissionsUpdateManyWithWhereWithoutRolesInput | role_permissionsUpdateManyWithWhereWithoutRolesInput[]
    deleteMany?: role_permissionsScalarWhereInput | role_permissionsScalarWhereInput[]
  }

  export type usersUncheckedUpdateManyWithoutRolesNestedInput = {
    create?: XOR<usersCreateWithoutRolesInput, usersUncheckedCreateWithoutRolesInput> | usersCreateWithoutRolesInput[] | usersUncheckedCreateWithoutRolesInput[]
    connectOrCreate?: usersCreateOrConnectWithoutRolesInput | usersCreateOrConnectWithoutRolesInput[]
    upsert?: usersUpsertWithWhereUniqueWithoutRolesInput | usersUpsertWithWhereUniqueWithoutRolesInput[]
    createMany?: usersCreateManyRolesInputEnvelope
    set?: usersWhereUniqueInput | usersWhereUniqueInput[]
    disconnect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    delete?: usersWhereUniqueInput | usersWhereUniqueInput[]
    connect?: usersWhereUniqueInput | usersWhereUniqueInput[]
    update?: usersUpdateWithWhereUniqueWithoutRolesInput | usersUpdateWithWhereUniqueWithoutRolesInput[]
    updateMany?: usersUpdateManyWithWhereWithoutRolesInput | usersUpdateManyWithWhereWithoutRolesInput[]
    deleteMany?: usersScalarWhereInput | usersScalarWhereInput[]
  }

  export type user_asset_accessCreateNestedManyWithoutUsersInput = {
    create?: XOR<user_asset_accessCreateWithoutUsersInput, user_asset_accessUncheckedCreateWithoutUsersInput> | user_asset_accessCreateWithoutUsersInput[] | user_asset_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_asset_accessCreateOrConnectWithoutUsersInput | user_asset_accessCreateOrConnectWithoutUsersInput[]
    createMany?: user_asset_accessCreateManyUsersInputEnvelope
    connect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
  }

  export type user_device_accessCreateNestedManyWithoutUsersInput = {
    create?: XOR<user_device_accessCreateWithoutUsersInput, user_device_accessUncheckedCreateWithoutUsersInput> | user_device_accessCreateWithoutUsersInput[] | user_device_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_device_accessCreateOrConnectWithoutUsersInput | user_device_accessCreateOrConnectWithoutUsersInput[]
    createMany?: user_device_accessCreateManyUsersInputEnvelope
    connect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
  }

  export type user_organisation_accessCreateNestedManyWithoutUsersInput = {
    create?: XOR<user_organisation_accessCreateWithoutUsersInput, user_organisation_accessUncheckedCreateWithoutUsersInput> | user_organisation_accessCreateWithoutUsersInput[] | user_organisation_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_organisation_accessCreateOrConnectWithoutUsersInput | user_organisation_accessCreateOrConnectWithoutUsersInput[]
    createMany?: user_organisation_accessCreateManyUsersInputEnvelope
    connect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
  }

  export type organisationsCreateNestedOneWithoutUsersInput = {
    create?: XOR<organisationsCreateWithoutUsersInput, organisationsUncheckedCreateWithoutUsersInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutUsersInput
    connect?: organisationsWhereUniqueInput
  }

  export type rolesCreateNestedOneWithoutUsersInput = {
    create?: XOR<rolesCreateWithoutUsersInput, rolesUncheckedCreateWithoutUsersInput>
    connectOrCreate?: rolesCreateOrConnectWithoutUsersInput
    connect?: rolesWhereUniqueInput
  }

  export type user_asset_accessUncheckedCreateNestedManyWithoutUsersInput = {
    create?: XOR<user_asset_accessCreateWithoutUsersInput, user_asset_accessUncheckedCreateWithoutUsersInput> | user_asset_accessCreateWithoutUsersInput[] | user_asset_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_asset_accessCreateOrConnectWithoutUsersInput | user_asset_accessCreateOrConnectWithoutUsersInput[]
    createMany?: user_asset_accessCreateManyUsersInputEnvelope
    connect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
  }

  export type user_device_accessUncheckedCreateNestedManyWithoutUsersInput = {
    create?: XOR<user_device_accessCreateWithoutUsersInput, user_device_accessUncheckedCreateWithoutUsersInput> | user_device_accessCreateWithoutUsersInput[] | user_device_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_device_accessCreateOrConnectWithoutUsersInput | user_device_accessCreateOrConnectWithoutUsersInput[]
    createMany?: user_device_accessCreateManyUsersInputEnvelope
    connect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
  }

  export type user_organisation_accessUncheckedCreateNestedManyWithoutUsersInput = {
    create?: XOR<user_organisation_accessCreateWithoutUsersInput, user_organisation_accessUncheckedCreateWithoutUsersInput> | user_organisation_accessCreateWithoutUsersInput[] | user_organisation_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_organisation_accessCreateOrConnectWithoutUsersInput | user_organisation_accessCreateOrConnectWithoutUsersInput[]
    createMany?: user_organisation_accessCreateManyUsersInputEnvelope
    connect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type user_asset_accessUpdateManyWithoutUsersNestedInput = {
    create?: XOR<user_asset_accessCreateWithoutUsersInput, user_asset_accessUncheckedCreateWithoutUsersInput> | user_asset_accessCreateWithoutUsersInput[] | user_asset_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_asset_accessCreateOrConnectWithoutUsersInput | user_asset_accessCreateOrConnectWithoutUsersInput[]
    upsert?: user_asset_accessUpsertWithWhereUniqueWithoutUsersInput | user_asset_accessUpsertWithWhereUniqueWithoutUsersInput[]
    createMany?: user_asset_accessCreateManyUsersInputEnvelope
    set?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    disconnect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    delete?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    connect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    update?: user_asset_accessUpdateWithWhereUniqueWithoutUsersInput | user_asset_accessUpdateWithWhereUniqueWithoutUsersInput[]
    updateMany?: user_asset_accessUpdateManyWithWhereWithoutUsersInput | user_asset_accessUpdateManyWithWhereWithoutUsersInput[]
    deleteMany?: user_asset_accessScalarWhereInput | user_asset_accessScalarWhereInput[]
  }

  export type user_device_accessUpdateManyWithoutUsersNestedInput = {
    create?: XOR<user_device_accessCreateWithoutUsersInput, user_device_accessUncheckedCreateWithoutUsersInput> | user_device_accessCreateWithoutUsersInput[] | user_device_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_device_accessCreateOrConnectWithoutUsersInput | user_device_accessCreateOrConnectWithoutUsersInput[]
    upsert?: user_device_accessUpsertWithWhereUniqueWithoutUsersInput | user_device_accessUpsertWithWhereUniqueWithoutUsersInput[]
    createMany?: user_device_accessCreateManyUsersInputEnvelope
    set?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    disconnect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    delete?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    connect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    update?: user_device_accessUpdateWithWhereUniqueWithoutUsersInput | user_device_accessUpdateWithWhereUniqueWithoutUsersInput[]
    updateMany?: user_device_accessUpdateManyWithWhereWithoutUsersInput | user_device_accessUpdateManyWithWhereWithoutUsersInput[]
    deleteMany?: user_device_accessScalarWhereInput | user_device_accessScalarWhereInput[]
  }

  export type user_organisation_accessUpdateManyWithoutUsersNestedInput = {
    create?: XOR<user_organisation_accessCreateWithoutUsersInput, user_organisation_accessUncheckedCreateWithoutUsersInput> | user_organisation_accessCreateWithoutUsersInput[] | user_organisation_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_organisation_accessCreateOrConnectWithoutUsersInput | user_organisation_accessCreateOrConnectWithoutUsersInput[]
    upsert?: user_organisation_accessUpsertWithWhereUniqueWithoutUsersInput | user_organisation_accessUpsertWithWhereUniqueWithoutUsersInput[]
    createMany?: user_organisation_accessCreateManyUsersInputEnvelope
    set?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    disconnect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    delete?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    connect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    update?: user_organisation_accessUpdateWithWhereUniqueWithoutUsersInput | user_organisation_accessUpdateWithWhereUniqueWithoutUsersInput[]
    updateMany?: user_organisation_accessUpdateManyWithWhereWithoutUsersInput | user_organisation_accessUpdateManyWithWhereWithoutUsersInput[]
    deleteMany?: user_organisation_accessScalarWhereInput | user_organisation_accessScalarWhereInput[]
  }

  export type organisationsUpdateOneRequiredWithoutUsersNestedInput = {
    create?: XOR<organisationsCreateWithoutUsersInput, organisationsUncheckedCreateWithoutUsersInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutUsersInput
    upsert?: organisationsUpsertWithoutUsersInput
    connect?: organisationsWhereUniqueInput
    update?: XOR<XOR<organisationsUpdateToOneWithWhereWithoutUsersInput, organisationsUpdateWithoutUsersInput>, organisationsUncheckedUpdateWithoutUsersInput>
  }

  export type rolesUpdateOneRequiredWithoutUsersNestedInput = {
    create?: XOR<rolesCreateWithoutUsersInput, rolesUncheckedCreateWithoutUsersInput>
    connectOrCreate?: rolesCreateOrConnectWithoutUsersInput
    upsert?: rolesUpsertWithoutUsersInput
    connect?: rolesWhereUniqueInput
    update?: XOR<XOR<rolesUpdateToOneWithWhereWithoutUsersInput, rolesUpdateWithoutUsersInput>, rolesUncheckedUpdateWithoutUsersInput>
  }

  export type user_asset_accessUncheckedUpdateManyWithoutUsersNestedInput = {
    create?: XOR<user_asset_accessCreateWithoutUsersInput, user_asset_accessUncheckedCreateWithoutUsersInput> | user_asset_accessCreateWithoutUsersInput[] | user_asset_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_asset_accessCreateOrConnectWithoutUsersInput | user_asset_accessCreateOrConnectWithoutUsersInput[]
    upsert?: user_asset_accessUpsertWithWhereUniqueWithoutUsersInput | user_asset_accessUpsertWithWhereUniqueWithoutUsersInput[]
    createMany?: user_asset_accessCreateManyUsersInputEnvelope
    set?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    disconnect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    delete?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    connect?: user_asset_accessWhereUniqueInput | user_asset_accessWhereUniqueInput[]
    update?: user_asset_accessUpdateWithWhereUniqueWithoutUsersInput | user_asset_accessUpdateWithWhereUniqueWithoutUsersInput[]
    updateMany?: user_asset_accessUpdateManyWithWhereWithoutUsersInput | user_asset_accessUpdateManyWithWhereWithoutUsersInput[]
    deleteMany?: user_asset_accessScalarWhereInput | user_asset_accessScalarWhereInput[]
  }

  export type user_device_accessUncheckedUpdateManyWithoutUsersNestedInput = {
    create?: XOR<user_device_accessCreateWithoutUsersInput, user_device_accessUncheckedCreateWithoutUsersInput> | user_device_accessCreateWithoutUsersInput[] | user_device_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_device_accessCreateOrConnectWithoutUsersInput | user_device_accessCreateOrConnectWithoutUsersInput[]
    upsert?: user_device_accessUpsertWithWhereUniqueWithoutUsersInput | user_device_accessUpsertWithWhereUniqueWithoutUsersInput[]
    createMany?: user_device_accessCreateManyUsersInputEnvelope
    set?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    disconnect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    delete?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    connect?: user_device_accessWhereUniqueInput | user_device_accessWhereUniqueInput[]
    update?: user_device_accessUpdateWithWhereUniqueWithoutUsersInput | user_device_accessUpdateWithWhereUniqueWithoutUsersInput[]
    updateMany?: user_device_accessUpdateManyWithWhereWithoutUsersInput | user_device_accessUpdateManyWithWhereWithoutUsersInput[]
    deleteMany?: user_device_accessScalarWhereInput | user_device_accessScalarWhereInput[]
  }

  export type user_organisation_accessUncheckedUpdateManyWithoutUsersNestedInput = {
    create?: XOR<user_organisation_accessCreateWithoutUsersInput, user_organisation_accessUncheckedCreateWithoutUsersInput> | user_organisation_accessCreateWithoutUsersInput[] | user_organisation_accessUncheckedCreateWithoutUsersInput[]
    connectOrCreate?: user_organisation_accessCreateOrConnectWithoutUsersInput | user_organisation_accessCreateOrConnectWithoutUsersInput[]
    upsert?: user_organisation_accessUpsertWithWhereUniqueWithoutUsersInput | user_organisation_accessUpsertWithWhereUniqueWithoutUsersInput[]
    createMany?: user_organisation_accessCreateManyUsersInputEnvelope
    set?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    disconnect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    delete?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    connect?: user_organisation_accessWhereUniqueInput | user_organisation_accessWhereUniqueInput[]
    update?: user_organisation_accessUpdateWithWhereUniqueWithoutUsersInput | user_organisation_accessUpdateWithWhereUniqueWithoutUsersInput[]
    updateMany?: user_organisation_accessUpdateManyWithWhereWithoutUsersInput | user_organisation_accessUpdateManyWithWhereWithoutUsersInput[]
    deleteMany?: user_organisation_accessScalarWhereInput | user_organisation_accessScalarWhereInput[]
  }

  export type organisationsCreateNestedOneWithoutUser_organisation_accessInput = {
    create?: XOR<organisationsCreateWithoutUser_organisation_accessInput, organisationsUncheckedCreateWithoutUser_organisation_accessInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutUser_organisation_accessInput
    connect?: organisationsWhereUniqueInput
  }

  export type usersCreateNestedOneWithoutUser_organisation_accessInput = {
    create?: XOR<usersCreateWithoutUser_organisation_accessInput, usersUncheckedCreateWithoutUser_organisation_accessInput>
    connectOrCreate?: usersCreateOrConnectWithoutUser_organisation_accessInput
    connect?: usersWhereUniqueInput
  }

  export type organisationsUpdateOneRequiredWithoutUser_organisation_accessNestedInput = {
    create?: XOR<organisationsCreateWithoutUser_organisation_accessInput, organisationsUncheckedCreateWithoutUser_organisation_accessInput>
    connectOrCreate?: organisationsCreateOrConnectWithoutUser_organisation_accessInput
    upsert?: organisationsUpsertWithoutUser_organisation_accessInput
    connect?: organisationsWhereUniqueInput
    update?: XOR<XOR<organisationsUpdateToOneWithWhereWithoutUser_organisation_accessInput, organisationsUpdateWithoutUser_organisation_accessInput>, organisationsUncheckedUpdateWithoutUser_organisation_accessInput>
  }

  export type usersUpdateOneRequiredWithoutUser_organisation_accessNestedInput = {
    create?: XOR<usersCreateWithoutUser_organisation_accessInput, usersUncheckedCreateWithoutUser_organisation_accessInput>
    connectOrCreate?: usersCreateOrConnectWithoutUser_organisation_accessInput
    upsert?: usersUpsertWithoutUser_organisation_accessInput
    connect?: usersWhereUniqueInput
    update?: XOR<XOR<usersUpdateToOneWithWhereWithoutUser_organisation_accessInput, usersUpdateWithoutUser_organisation_accessInput>, usersUncheckedUpdateWithoutUser_organisation_accessInput>
  }

  export type assetsCreateNestedOneWithoutUser_asset_accessInput = {
    create?: XOR<assetsCreateWithoutUser_asset_accessInput, assetsUncheckedCreateWithoutUser_asset_accessInput>
    connectOrCreate?: assetsCreateOrConnectWithoutUser_asset_accessInput
    connect?: assetsWhereUniqueInput
  }

  export type usersCreateNestedOneWithoutUser_asset_accessInput = {
    create?: XOR<usersCreateWithoutUser_asset_accessInput, usersUncheckedCreateWithoutUser_asset_accessInput>
    connectOrCreate?: usersCreateOrConnectWithoutUser_asset_accessInput
    connect?: usersWhereUniqueInput
  }

  export type assetsUpdateOneRequiredWithoutUser_asset_accessNestedInput = {
    create?: XOR<assetsCreateWithoutUser_asset_accessInput, assetsUncheckedCreateWithoutUser_asset_accessInput>
    connectOrCreate?: assetsCreateOrConnectWithoutUser_asset_accessInput
    upsert?: assetsUpsertWithoutUser_asset_accessInput
    connect?: assetsWhereUniqueInput
    update?: XOR<XOR<assetsUpdateToOneWithWhereWithoutUser_asset_accessInput, assetsUpdateWithoutUser_asset_accessInput>, assetsUncheckedUpdateWithoutUser_asset_accessInput>
  }

  export type usersUpdateOneRequiredWithoutUser_asset_accessNestedInput = {
    create?: XOR<usersCreateWithoutUser_asset_accessInput, usersUncheckedCreateWithoutUser_asset_accessInput>
    connectOrCreate?: usersCreateOrConnectWithoutUser_asset_accessInput
    upsert?: usersUpsertWithoutUser_asset_accessInput
    connect?: usersWhereUniqueInput
    update?: XOR<XOR<usersUpdateToOneWithWhereWithoutUser_asset_accessInput, usersUpdateWithoutUser_asset_accessInput>, usersUncheckedUpdateWithoutUser_asset_accessInput>
  }

  export type devicesCreateNestedOneWithoutUser_device_accessInput = {
    create?: XOR<devicesCreateWithoutUser_device_accessInput, devicesUncheckedCreateWithoutUser_device_accessInput>
    connectOrCreate?: devicesCreateOrConnectWithoutUser_device_accessInput
    connect?: devicesWhereUniqueInput
  }

  export type usersCreateNestedOneWithoutUser_device_accessInput = {
    create?: XOR<usersCreateWithoutUser_device_accessInput, usersUncheckedCreateWithoutUser_device_accessInput>
    connectOrCreate?: usersCreateOrConnectWithoutUser_device_accessInput
    connect?: usersWhereUniqueInput
  }

  export type devicesUpdateOneRequiredWithoutUser_device_accessNestedInput = {
    create?: XOR<devicesCreateWithoutUser_device_accessInput, devicesUncheckedCreateWithoutUser_device_accessInput>
    connectOrCreate?: devicesCreateOrConnectWithoutUser_device_accessInput
    upsert?: devicesUpsertWithoutUser_device_accessInput
    connect?: devicesWhereUniqueInput
    update?: XOR<XOR<devicesUpdateToOneWithWhereWithoutUser_device_accessInput, devicesUpdateWithoutUser_device_accessInput>, devicesUncheckedUpdateWithoutUser_device_accessInput>
  }

  export type usersUpdateOneRequiredWithoutUser_device_accessNestedInput = {
    create?: XOR<usersCreateWithoutUser_device_accessInput, usersUncheckedCreateWithoutUser_device_accessInput>
    connectOrCreate?: usersCreateOrConnectWithoutUser_device_accessInput
    upsert?: usersUpsertWithoutUser_device_accessInput
    connect?: usersWhereUniqueInput
    update?: XOR<XOR<usersUpdateToOneWithWhereWithoutUser_device_accessInput, usersUpdateWithoutUser_device_accessInput>, usersUncheckedUpdateWithoutUser_device_accessInput>
  }

  export type imagesCreatetagsInput = {
    set: string[]
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type imagesUpdatetagsInput = {
    set?: string[]
    push?: string | string[]
  }

  export type NestedBigIntFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntFilter<$PrismaModel> | bigint | number
  }

  export type NestedUuidNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedUuidNullableFilter<$PrismaModel> | string | null
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedBigIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel>
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntWithAggregatesFilter<$PrismaModel> | bigint | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedBigIntFilter<$PrismaModel>
    _min?: NestedBigIntFilter<$PrismaModel>
    _max?: NestedBigIntFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedUuidNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedUuidNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }
  export type NestedJsonFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedBigIntNullableFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel> | null
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel> | null
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel> | null
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntNullableFilter<$PrismaModel> | bigint | number | null
  }

  export type NestedBigIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: bigint | number | BigIntFieldRefInput<$PrismaModel> | null
    in?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel> | null
    notIn?: bigint[] | number[] | ListBigIntFieldRefInput<$PrismaModel> | null
    lt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    lte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gt?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    gte?: bigint | number | BigIntFieldRefInput<$PrismaModel>
    not?: NestedBigIntNullableWithAggregatesFilter<$PrismaModel> | bigint | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedBigIntNullableFilter<$PrismaModel>
    _min?: NestedBigIntNullableFilter<$PrismaModel>
    _max?: NestedBigIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedUuidFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedUuidFilter<$PrismaModel> | string
  }

  export type NestedBoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type NestedUuidWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedUuidWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedBoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type organisationsCreateWithoutAssetsInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    devices?: devicesCreateNestedManyWithoutOrganisationsInput
    organisations?: organisationsCreateNestedOneWithoutOther_organisationsInput
    other_organisations?: organisationsCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutOrganisationsInput
    users?: usersCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsUncheckedCreateWithoutAssetsInput = {
    id?: bigint | number
    uuid?: string
    name: string
    parent_org_id?: bigint | number | null
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    devices?: devicesUncheckedCreateNestedManyWithoutOrganisationsInput
    other_organisations?: organisationsUncheckedCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutOrganisationsInput
    users?: usersUncheckedCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsCreateOrConnectWithoutAssetsInput = {
    where: organisationsWhereUniqueInput
    create: XOR<organisationsCreateWithoutAssetsInput, organisationsUncheckedCreateWithoutAssetsInput>
  }

  export type devicesCreateWithoutAssetsInput = {
    id?: bigint | number
    uuid?: string | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
    organisations?: organisationsCreateNestedOneWithoutDevicesInput
    user_device_access?: user_device_accessCreateNestedManyWithoutDevicesInput
  }

  export type devicesUncheckedCreateWithoutAssetsInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
    user_device_access?: user_device_accessUncheckedCreateNestedManyWithoutDevicesInput
  }

  export type devicesCreateOrConnectWithoutAssetsInput = {
    where: devicesWhereUniqueInput
    create: XOR<devicesCreateWithoutAssetsInput, devicesUncheckedCreateWithoutAssetsInput>
  }

  export type devicesCreateManyAssetsInputEnvelope = {
    data: devicesCreateManyAssetsInput | devicesCreateManyAssetsInput[]
    skipDuplicates?: boolean
  }

  export type user_asset_accessCreateWithoutAssetsInput = {
    is_allowed?: boolean
    users: usersCreateNestedOneWithoutUser_asset_accessInput
  }

  export type user_asset_accessUncheckedCreateWithoutAssetsInput = {
    user_id: bigint | number
    is_allowed?: boolean
  }

  export type user_asset_accessCreateOrConnectWithoutAssetsInput = {
    where: user_asset_accessWhereUniqueInput
    create: XOR<user_asset_accessCreateWithoutAssetsInput, user_asset_accessUncheckedCreateWithoutAssetsInput>
  }

  export type user_asset_accessCreateManyAssetsInputEnvelope = {
    data: user_asset_accessCreateManyAssetsInput | user_asset_accessCreateManyAssetsInput[]
    skipDuplicates?: boolean
  }

  export type organisationsUpsertWithoutAssetsInput = {
    update: XOR<organisationsUpdateWithoutAssetsInput, organisationsUncheckedUpdateWithoutAssetsInput>
    create: XOR<organisationsCreateWithoutAssetsInput, organisationsUncheckedCreateWithoutAssetsInput>
    where?: organisationsWhereInput
  }

  export type organisationsUpdateToOneWithWhereWithoutAssetsInput = {
    where?: organisationsWhereInput
    data: XOR<organisationsUpdateWithoutAssetsInput, organisationsUncheckedUpdateWithoutAssetsInput>
  }

  export type organisationsUpdateWithoutAssetsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    devices?: devicesUpdateManyWithoutOrganisationsNestedInput
    organisations?: organisationsUpdateOneWithoutOther_organisationsNestedInput
    other_organisations?: organisationsUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutOrganisationsNestedInput
    users?: usersUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUncheckedUpdateWithoutAssetsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    parent_org_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    devices?: devicesUncheckedUpdateManyWithoutOrganisationsNestedInput
    other_organisations?: organisationsUncheckedUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutOrganisationsNestedInput
    users?: usersUncheckedUpdateManyWithoutOrganisationsNestedInput
  }

  export type devicesUpsertWithWhereUniqueWithoutAssetsInput = {
    where: devicesWhereUniqueInput
    update: XOR<devicesUpdateWithoutAssetsInput, devicesUncheckedUpdateWithoutAssetsInput>
    create: XOR<devicesCreateWithoutAssetsInput, devicesUncheckedCreateWithoutAssetsInput>
  }

  export type devicesUpdateWithWhereUniqueWithoutAssetsInput = {
    where: devicesWhereUniqueInput
    data: XOR<devicesUpdateWithoutAssetsInput, devicesUncheckedUpdateWithoutAssetsInput>
  }

  export type devicesUpdateManyWithWhereWithoutAssetsInput = {
    where: devicesScalarWhereInput
    data: XOR<devicesUpdateManyMutationInput, devicesUncheckedUpdateManyWithoutAssetsInput>
  }

  export type devicesScalarWhereInput = {
    AND?: devicesScalarWhereInput | devicesScalarWhereInput[]
    OR?: devicesScalarWhereInput[]
    NOT?: devicesScalarWhereInput | devicesScalarWhereInput[]
    id?: BigIntFilter<"devices"> | bigint | number
    uuid?: UuidNullableFilter<"devices"> | string | null
    organisation_id?: BigIntFilter<"devices"> | bigint | number
    asset_id?: BigIntNullableFilter<"devices"> | bigint | number | null
    external_id?: StringFilter<"devices"> | string
    external_id_type?: StringFilter<"devices"> | string
    protocol?: StringNullableFilter<"devices"> | string | null
    vendor?: StringNullableFilter<"devices"> | string | null
    model?: StringNullableFilter<"devices"> | string | null
    status?: StringFilter<"devices"> | string
    attributes?: JsonFilter<"devices">
    last_telemetry?: JsonFilter<"devices">
    last_telemetry_ts?: DateTimeFilter<"devices"> | Date | string
    created_at?: DateTimeFilter<"devices"> | Date | string
    updated_at?: DateTimeFilter<"devices"> | Date | string
  }

  export type user_asset_accessUpsertWithWhereUniqueWithoutAssetsInput = {
    where: user_asset_accessWhereUniqueInput
    update: XOR<user_asset_accessUpdateWithoutAssetsInput, user_asset_accessUncheckedUpdateWithoutAssetsInput>
    create: XOR<user_asset_accessCreateWithoutAssetsInput, user_asset_accessUncheckedCreateWithoutAssetsInput>
  }

  export type user_asset_accessUpdateWithWhereUniqueWithoutAssetsInput = {
    where: user_asset_accessWhereUniqueInput
    data: XOR<user_asset_accessUpdateWithoutAssetsInput, user_asset_accessUncheckedUpdateWithoutAssetsInput>
  }

  export type user_asset_accessUpdateManyWithWhereWithoutAssetsInput = {
    where: user_asset_accessScalarWhereInput
    data: XOR<user_asset_accessUpdateManyMutationInput, user_asset_accessUncheckedUpdateManyWithoutAssetsInput>
  }

  export type user_asset_accessScalarWhereInput = {
    AND?: user_asset_accessScalarWhereInput | user_asset_accessScalarWhereInput[]
    OR?: user_asset_accessScalarWhereInput[]
    NOT?: user_asset_accessScalarWhereInput | user_asset_accessScalarWhereInput[]
    user_id?: BigIntFilter<"user_asset_access"> | bigint | number
    asset_id?: BigIntFilter<"user_asset_access"> | bigint | number
    is_allowed?: BoolFilter<"user_asset_access"> | boolean
  }

  export type assetsCreateWithoutDevicesInput = {
    id?: bigint | number
    uuid?: string | null
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    organisations?: organisationsCreateNestedOneWithoutAssetsInput
    user_asset_access?: user_asset_accessCreateNestedManyWithoutAssetsInput
  }

  export type assetsUncheckedCreateWithoutDevicesInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    user_asset_access?: user_asset_accessUncheckedCreateNestedManyWithoutAssetsInput
  }

  export type assetsCreateOrConnectWithoutDevicesInput = {
    where: assetsWhereUniqueInput
    create: XOR<assetsCreateWithoutDevicesInput, assetsUncheckedCreateWithoutDevicesInput>
  }

  export type organisationsCreateWithoutDevicesInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedManyWithoutOrganisationsInput
    organisations?: organisationsCreateNestedOneWithoutOther_organisationsInput
    other_organisations?: organisationsCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutOrganisationsInput
    users?: usersCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsUncheckedCreateWithoutDevicesInput = {
    id?: bigint | number
    uuid?: string
    name: string
    parent_org_id?: bigint | number | null
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsUncheckedCreateNestedManyWithoutOrganisationsInput
    other_organisations?: organisationsUncheckedCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutOrganisationsInput
    users?: usersUncheckedCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsCreateOrConnectWithoutDevicesInput = {
    where: organisationsWhereUniqueInput
    create: XOR<organisationsCreateWithoutDevicesInput, organisationsUncheckedCreateWithoutDevicesInput>
  }

  export type user_device_accessCreateWithoutDevicesInput = {
    is_allowed?: boolean
    users: usersCreateNestedOneWithoutUser_device_accessInput
  }

  export type user_device_accessUncheckedCreateWithoutDevicesInput = {
    user_id: bigint | number
    is_allowed?: boolean
  }

  export type user_device_accessCreateOrConnectWithoutDevicesInput = {
    where: user_device_accessWhereUniqueInput
    create: XOR<user_device_accessCreateWithoutDevicesInput, user_device_accessUncheckedCreateWithoutDevicesInput>
  }

  export type user_device_accessCreateManyDevicesInputEnvelope = {
    data: user_device_accessCreateManyDevicesInput | user_device_accessCreateManyDevicesInput[]
    skipDuplicates?: boolean
  }

  export type assetsUpsertWithoutDevicesInput = {
    update: XOR<assetsUpdateWithoutDevicesInput, assetsUncheckedUpdateWithoutDevicesInput>
    create: XOR<assetsCreateWithoutDevicesInput, assetsUncheckedCreateWithoutDevicesInput>
    where?: assetsWhereInput
  }

  export type assetsUpdateToOneWithWhereWithoutDevicesInput = {
    where?: assetsWhereInput
    data: XOR<assetsUpdateWithoutDevicesInput, assetsUncheckedUpdateWithoutDevicesInput>
  }

  export type assetsUpdateWithoutDevicesInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    organisations?: organisationsUpdateOneRequiredWithoutAssetsNestedInput
    user_asset_access?: user_asset_accessUpdateManyWithoutAssetsNestedInput
  }

  export type assetsUncheckedUpdateWithoutDevicesInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    user_asset_access?: user_asset_accessUncheckedUpdateManyWithoutAssetsNestedInput
  }

  export type organisationsUpsertWithoutDevicesInput = {
    update: XOR<organisationsUpdateWithoutDevicesInput, organisationsUncheckedUpdateWithoutDevicesInput>
    create: XOR<organisationsCreateWithoutDevicesInput, organisationsUncheckedCreateWithoutDevicesInput>
    where?: organisationsWhereInput
  }

  export type organisationsUpdateToOneWithWhereWithoutDevicesInput = {
    where?: organisationsWhereInput
    data: XOR<organisationsUpdateWithoutDevicesInput, organisationsUncheckedUpdateWithoutDevicesInput>
  }

  export type organisationsUpdateWithoutDevicesInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateManyWithoutOrganisationsNestedInput
    organisations?: organisationsUpdateOneWithoutOther_organisationsNestedInput
    other_organisations?: organisationsUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutOrganisationsNestedInput
    users?: usersUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUncheckedUpdateWithoutDevicesInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    parent_org_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUncheckedUpdateManyWithoutOrganisationsNestedInput
    other_organisations?: organisationsUncheckedUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutOrganisationsNestedInput
    users?: usersUncheckedUpdateManyWithoutOrganisationsNestedInput
  }

  export type user_device_accessUpsertWithWhereUniqueWithoutDevicesInput = {
    where: user_device_accessWhereUniqueInput
    update: XOR<user_device_accessUpdateWithoutDevicesInput, user_device_accessUncheckedUpdateWithoutDevicesInput>
    create: XOR<user_device_accessCreateWithoutDevicesInput, user_device_accessUncheckedCreateWithoutDevicesInput>
  }

  export type user_device_accessUpdateWithWhereUniqueWithoutDevicesInput = {
    where: user_device_accessWhereUniqueInput
    data: XOR<user_device_accessUpdateWithoutDevicesInput, user_device_accessUncheckedUpdateWithoutDevicesInput>
  }

  export type user_device_accessUpdateManyWithWhereWithoutDevicesInput = {
    where: user_device_accessScalarWhereInput
    data: XOR<user_device_accessUpdateManyMutationInput, user_device_accessUncheckedUpdateManyWithoutDevicesInput>
  }

  export type user_device_accessScalarWhereInput = {
    AND?: user_device_accessScalarWhereInput | user_device_accessScalarWhereInput[]
    OR?: user_device_accessScalarWhereInput[]
    NOT?: user_device_accessScalarWhereInput | user_device_accessScalarWhereInput[]
    user_id?: BigIntFilter<"user_device_access"> | bigint | number
    device_id?: BigIntFilter<"user_device_access"> | bigint | number
    is_allowed?: BoolFilter<"user_device_access"> | boolean
  }

  export type assetsCreateWithoutOrganisationsInput = {
    id?: bigint | number
    uuid?: string | null
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    devices?: devicesCreateNestedManyWithoutAssetsInput
    user_asset_access?: user_asset_accessCreateNestedManyWithoutAssetsInput
  }

  export type assetsUncheckedCreateWithoutOrganisationsInput = {
    id?: bigint | number
    uuid?: string | null
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    devices?: devicesUncheckedCreateNestedManyWithoutAssetsInput
    user_asset_access?: user_asset_accessUncheckedCreateNestedManyWithoutAssetsInput
  }

  export type assetsCreateOrConnectWithoutOrganisationsInput = {
    where: assetsWhereUniqueInput
    create: XOR<assetsCreateWithoutOrganisationsInput, assetsUncheckedCreateWithoutOrganisationsInput>
  }

  export type assetsCreateManyOrganisationsInputEnvelope = {
    data: assetsCreateManyOrganisationsInput | assetsCreateManyOrganisationsInput[]
    skipDuplicates?: boolean
  }

  export type devicesCreateWithoutOrganisationsInput = {
    id?: bigint | number
    uuid?: string | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedOneWithoutDevicesInput
    user_device_access?: user_device_accessCreateNestedManyWithoutDevicesInput
  }

  export type devicesUncheckedCreateWithoutOrganisationsInput = {
    id?: bigint | number
    uuid?: string | null
    asset_id?: bigint | number | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
    user_device_access?: user_device_accessUncheckedCreateNestedManyWithoutDevicesInput
  }

  export type devicesCreateOrConnectWithoutOrganisationsInput = {
    where: devicesWhereUniqueInput
    create: XOR<devicesCreateWithoutOrganisationsInput, devicesUncheckedCreateWithoutOrganisationsInput>
  }

  export type devicesCreateManyOrganisationsInputEnvelope = {
    data: devicesCreateManyOrganisationsInput | devicesCreateManyOrganisationsInput[]
    skipDuplicates?: boolean
  }

  export type organisationsCreateWithoutOther_organisationsInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedManyWithoutOrganisationsInput
    devices?: devicesCreateNestedManyWithoutOrganisationsInput
    organisations?: organisationsCreateNestedOneWithoutOther_organisationsInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutOrganisationsInput
    users?: usersCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsUncheckedCreateWithoutOther_organisationsInput = {
    id?: bigint | number
    uuid?: string
    name: string
    parent_org_id?: bigint | number | null
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsUncheckedCreateNestedManyWithoutOrganisationsInput
    devices?: devicesUncheckedCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutOrganisationsInput
    users?: usersUncheckedCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsCreateOrConnectWithoutOther_organisationsInput = {
    where: organisationsWhereUniqueInput
    create: XOR<organisationsCreateWithoutOther_organisationsInput, organisationsUncheckedCreateWithoutOther_organisationsInput>
  }

  export type organisationsCreateWithoutOrganisationsInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedManyWithoutOrganisationsInput
    devices?: devicesCreateNestedManyWithoutOrganisationsInput
    other_organisations?: organisationsCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutOrganisationsInput
    users?: usersCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsUncheckedCreateWithoutOrganisationsInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsUncheckedCreateNestedManyWithoutOrganisationsInput
    devices?: devicesUncheckedCreateNestedManyWithoutOrganisationsInput
    other_organisations?: organisationsUncheckedCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutOrganisationsInput
    users?: usersUncheckedCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsCreateOrConnectWithoutOrganisationsInput = {
    where: organisationsWhereUniqueInput
    create: XOR<organisationsCreateWithoutOrganisationsInput, organisationsUncheckedCreateWithoutOrganisationsInput>
  }

  export type organisationsCreateManyOrganisationsInputEnvelope = {
    data: organisationsCreateManyOrganisationsInput | organisationsCreateManyOrganisationsInput[]
    skipDuplicates?: boolean
  }

  export type user_organisation_accessCreateWithoutOrganisationsInput = {
    is_allowed?: boolean
    users: usersCreateNestedOneWithoutUser_organisation_accessInput
  }

  export type user_organisation_accessUncheckedCreateWithoutOrganisationsInput = {
    user_id: bigint | number
    is_allowed?: boolean
  }

  export type user_organisation_accessCreateOrConnectWithoutOrganisationsInput = {
    where: user_organisation_accessWhereUniqueInput
    create: XOR<user_organisation_accessCreateWithoutOrganisationsInput, user_organisation_accessUncheckedCreateWithoutOrganisationsInput>
  }

  export type user_organisation_accessCreateManyOrganisationsInputEnvelope = {
    data: user_organisation_accessCreateManyOrganisationsInput | user_organisation_accessCreateManyOrganisationsInput[]
    skipDuplicates?: boolean
  }

  export type usersCreateWithoutOrganisationsInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessCreateNestedManyWithoutUsersInput
    user_device_access?: user_device_accessCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutUsersInput
    roles: rolesCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateWithoutOrganisationsInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    role_id: number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessUncheckedCreateNestedManyWithoutUsersInput
    user_device_access?: user_device_accessUncheckedCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutUsersInput
  }

  export type usersCreateOrConnectWithoutOrganisationsInput = {
    where: usersWhereUniqueInput
    create: XOR<usersCreateWithoutOrganisationsInput, usersUncheckedCreateWithoutOrganisationsInput>
  }

  export type usersCreateManyOrganisationsInputEnvelope = {
    data: usersCreateManyOrganisationsInput | usersCreateManyOrganisationsInput[]
    skipDuplicates?: boolean
  }

  export type assetsUpsertWithWhereUniqueWithoutOrganisationsInput = {
    where: assetsWhereUniqueInput
    update: XOR<assetsUpdateWithoutOrganisationsInput, assetsUncheckedUpdateWithoutOrganisationsInput>
    create: XOR<assetsCreateWithoutOrganisationsInput, assetsUncheckedCreateWithoutOrganisationsInput>
  }

  export type assetsUpdateWithWhereUniqueWithoutOrganisationsInput = {
    where: assetsWhereUniqueInput
    data: XOR<assetsUpdateWithoutOrganisationsInput, assetsUncheckedUpdateWithoutOrganisationsInput>
  }

  export type assetsUpdateManyWithWhereWithoutOrganisationsInput = {
    where: assetsScalarWhereInput
    data: XOR<assetsUpdateManyMutationInput, assetsUncheckedUpdateManyWithoutOrganisationsInput>
  }

  export type assetsScalarWhereInput = {
    AND?: assetsScalarWhereInput | assetsScalarWhereInput[]
    OR?: assetsScalarWhereInput[]
    NOT?: assetsScalarWhereInput | assetsScalarWhereInput[]
    id?: BigIntFilter<"assets"> | bigint | number
    uuid?: UuidNullableFilter<"assets"> | string | null
    organisation_id?: BigIntFilter<"assets"> | bigint | number
    name?: StringFilter<"assets"> | string
    asset_type?: StringNullableFilter<"assets"> | string | null
    attributes?: JsonFilter<"assets">
    created_at?: DateTimeFilter<"assets"> | Date | string
    updated_at?: DateTimeFilter<"assets"> | Date | string
  }

  export type devicesUpsertWithWhereUniqueWithoutOrganisationsInput = {
    where: devicesWhereUniqueInput
    update: XOR<devicesUpdateWithoutOrganisationsInput, devicesUncheckedUpdateWithoutOrganisationsInput>
    create: XOR<devicesCreateWithoutOrganisationsInput, devicesUncheckedCreateWithoutOrganisationsInput>
  }

  export type devicesUpdateWithWhereUniqueWithoutOrganisationsInput = {
    where: devicesWhereUniqueInput
    data: XOR<devicesUpdateWithoutOrganisationsInput, devicesUncheckedUpdateWithoutOrganisationsInput>
  }

  export type devicesUpdateManyWithWhereWithoutOrganisationsInput = {
    where: devicesScalarWhereInput
    data: XOR<devicesUpdateManyMutationInput, devicesUncheckedUpdateManyWithoutOrganisationsInput>
  }

  export type organisationsUpsertWithoutOther_organisationsInput = {
    update: XOR<organisationsUpdateWithoutOther_organisationsInput, organisationsUncheckedUpdateWithoutOther_organisationsInput>
    create: XOR<organisationsCreateWithoutOther_organisationsInput, organisationsUncheckedCreateWithoutOther_organisationsInput>
    where?: organisationsWhereInput
  }

  export type organisationsUpdateToOneWithWhereWithoutOther_organisationsInput = {
    where?: organisationsWhereInput
    data: XOR<organisationsUpdateWithoutOther_organisationsInput, organisationsUncheckedUpdateWithoutOther_organisationsInput>
  }

  export type organisationsUpdateWithoutOther_organisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUpdateManyWithoutOrganisationsNestedInput
    organisations?: organisationsUpdateOneWithoutOther_organisationsNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutOrganisationsNestedInput
    users?: usersUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUncheckedUpdateWithoutOther_organisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    parent_org_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUncheckedUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUncheckedUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutOrganisationsNestedInput
    users?: usersUncheckedUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUpsertWithWhereUniqueWithoutOrganisationsInput = {
    where: organisationsWhereUniqueInput
    update: XOR<organisationsUpdateWithoutOrganisationsInput, organisationsUncheckedUpdateWithoutOrganisationsInput>
    create: XOR<organisationsCreateWithoutOrganisationsInput, organisationsUncheckedCreateWithoutOrganisationsInput>
  }

  export type organisationsUpdateWithWhereUniqueWithoutOrganisationsInput = {
    where: organisationsWhereUniqueInput
    data: XOR<organisationsUpdateWithoutOrganisationsInput, organisationsUncheckedUpdateWithoutOrganisationsInput>
  }

  export type organisationsUpdateManyWithWhereWithoutOrganisationsInput = {
    where: organisationsScalarWhereInput
    data: XOR<organisationsUpdateManyMutationInput, organisationsUncheckedUpdateManyWithoutOrganisationsInput>
  }

  export type organisationsScalarWhereInput = {
    AND?: organisationsScalarWhereInput | organisationsScalarWhereInput[]
    OR?: organisationsScalarWhereInput[]
    NOT?: organisationsScalarWhereInput | organisationsScalarWhereInput[]
    id?: BigIntFilter<"organisations"> | bigint | number
    uuid?: UuidFilter<"organisations"> | string
    name?: StringFilter<"organisations"> | string
    parent_org_id?: BigIntNullableFilter<"organisations"> | bigint | number | null
    path?: StringNullableFilter<"organisations"> | string | null
    maps_api_key?: StringNullableFilter<"organisations"> | string | null
    can_inherit_key?: BoolNullableFilter<"organisations"> | boolean | null
    attributes?: JsonFilter<"organisations">
    created_at?: DateTimeFilter<"organisations"> | Date | string
    updated_at?: DateTimeFilter<"organisations"> | Date | string
  }

  export type user_organisation_accessUpsertWithWhereUniqueWithoutOrganisationsInput = {
    where: user_organisation_accessWhereUniqueInput
    update: XOR<user_organisation_accessUpdateWithoutOrganisationsInput, user_organisation_accessUncheckedUpdateWithoutOrganisationsInput>
    create: XOR<user_organisation_accessCreateWithoutOrganisationsInput, user_organisation_accessUncheckedCreateWithoutOrganisationsInput>
  }

  export type user_organisation_accessUpdateWithWhereUniqueWithoutOrganisationsInput = {
    where: user_organisation_accessWhereUniqueInput
    data: XOR<user_organisation_accessUpdateWithoutOrganisationsInput, user_organisation_accessUncheckedUpdateWithoutOrganisationsInput>
  }

  export type user_organisation_accessUpdateManyWithWhereWithoutOrganisationsInput = {
    where: user_organisation_accessScalarWhereInput
    data: XOR<user_organisation_accessUpdateManyMutationInput, user_organisation_accessUncheckedUpdateManyWithoutOrganisationsInput>
  }

  export type user_organisation_accessScalarWhereInput = {
    AND?: user_organisation_accessScalarWhereInput | user_organisation_accessScalarWhereInput[]
    OR?: user_organisation_accessScalarWhereInput[]
    NOT?: user_organisation_accessScalarWhereInput | user_organisation_accessScalarWhereInput[]
    user_id?: BigIntFilter<"user_organisation_access"> | bigint | number
    organisation_id?: BigIntFilter<"user_organisation_access"> | bigint | number
    is_allowed?: BoolFilter<"user_organisation_access"> | boolean
  }

  export type usersUpsertWithWhereUniqueWithoutOrganisationsInput = {
    where: usersWhereUniqueInput
    update: XOR<usersUpdateWithoutOrganisationsInput, usersUncheckedUpdateWithoutOrganisationsInput>
    create: XOR<usersCreateWithoutOrganisationsInput, usersUncheckedCreateWithoutOrganisationsInput>
  }

  export type usersUpdateWithWhereUniqueWithoutOrganisationsInput = {
    where: usersWhereUniqueInput
    data: XOR<usersUpdateWithoutOrganisationsInput, usersUncheckedUpdateWithoutOrganisationsInput>
  }

  export type usersUpdateManyWithWhereWithoutOrganisationsInput = {
    where: usersScalarWhereInput
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyWithoutOrganisationsInput>
  }

  export type usersScalarWhereInput = {
    AND?: usersScalarWhereInput | usersScalarWhereInput[]
    OR?: usersScalarWhereInput[]
    NOT?: usersScalarWhereInput | usersScalarWhereInput[]
    id?: BigIntFilter<"users"> | bigint | number
    uuid?: UuidFilter<"users"> | string
    first_name?: StringFilter<"users"> | string
    last_name?: StringFilter<"users"> | string
    email?: StringFilter<"users"> | string
    password_hash?: StringFilter<"users"> | string
    role_id?: IntFilter<"users"> | number
    organisation_id?: BigIntFilter<"users"> | bigint | number
    active?: BoolFilter<"users"> | boolean
    last_login_at?: DateTimeNullableFilter<"users"> | Date | string | null
    created_at?: DateTimeFilter<"users"> | Date | string
    updated_at?: DateTimeFilter<"users"> | Date | string
    token_version?: IntFilter<"users"> | number
  }

  export type role_permissionsCreateWithoutPermissionsInput = {
    roles: rolesCreateNestedOneWithoutRole_permissionsInput
  }

  export type role_permissionsUncheckedCreateWithoutPermissionsInput = {
    role_id: number
  }

  export type role_permissionsCreateOrConnectWithoutPermissionsInput = {
    where: role_permissionsWhereUniqueInput
    create: XOR<role_permissionsCreateWithoutPermissionsInput, role_permissionsUncheckedCreateWithoutPermissionsInput>
  }

  export type role_permissionsCreateManyPermissionsInputEnvelope = {
    data: role_permissionsCreateManyPermissionsInput | role_permissionsCreateManyPermissionsInput[]
    skipDuplicates?: boolean
  }

  export type role_permissionsUpsertWithWhereUniqueWithoutPermissionsInput = {
    where: role_permissionsWhereUniqueInput
    update: XOR<role_permissionsUpdateWithoutPermissionsInput, role_permissionsUncheckedUpdateWithoutPermissionsInput>
    create: XOR<role_permissionsCreateWithoutPermissionsInput, role_permissionsUncheckedCreateWithoutPermissionsInput>
  }

  export type role_permissionsUpdateWithWhereUniqueWithoutPermissionsInput = {
    where: role_permissionsWhereUniqueInput
    data: XOR<role_permissionsUpdateWithoutPermissionsInput, role_permissionsUncheckedUpdateWithoutPermissionsInput>
  }

  export type role_permissionsUpdateManyWithWhereWithoutPermissionsInput = {
    where: role_permissionsScalarWhereInput
    data: XOR<role_permissionsUpdateManyMutationInput, role_permissionsUncheckedUpdateManyWithoutPermissionsInput>
  }

  export type role_permissionsScalarWhereInput = {
    AND?: role_permissionsScalarWhereInput | role_permissionsScalarWhereInput[]
    OR?: role_permissionsScalarWhereInput[]
    NOT?: role_permissionsScalarWhereInput | role_permissionsScalarWhereInput[]
    role_id?: IntFilter<"role_permissions"> | number
    perm_id?: IntFilter<"role_permissions"> | number
  }

  export type permissionsCreateWithoutRole_permissionsInput = {
    perm_id: number
    key: string
    description: string
  }

  export type permissionsUncheckedCreateWithoutRole_permissionsInput = {
    perm_id: number
    key: string
    description: string
  }

  export type permissionsCreateOrConnectWithoutRole_permissionsInput = {
    where: permissionsWhereUniqueInput
    create: XOR<permissionsCreateWithoutRole_permissionsInput, permissionsUncheckedCreateWithoutRole_permissionsInput>
  }

  export type rolesCreateWithoutRole_permissionsInput = {
    role_id: number
    name: string
    users?: usersCreateNestedManyWithoutRolesInput
  }

  export type rolesUncheckedCreateWithoutRole_permissionsInput = {
    role_id: number
    name: string
    users?: usersUncheckedCreateNestedManyWithoutRolesInput
  }

  export type rolesCreateOrConnectWithoutRole_permissionsInput = {
    where: rolesWhereUniqueInput
    create: XOR<rolesCreateWithoutRole_permissionsInput, rolesUncheckedCreateWithoutRole_permissionsInput>
  }

  export type permissionsUpsertWithoutRole_permissionsInput = {
    update: XOR<permissionsUpdateWithoutRole_permissionsInput, permissionsUncheckedUpdateWithoutRole_permissionsInput>
    create: XOR<permissionsCreateWithoutRole_permissionsInput, permissionsUncheckedCreateWithoutRole_permissionsInput>
    where?: permissionsWhereInput
  }

  export type permissionsUpdateToOneWithWhereWithoutRole_permissionsInput = {
    where?: permissionsWhereInput
    data: XOR<permissionsUpdateWithoutRole_permissionsInput, permissionsUncheckedUpdateWithoutRole_permissionsInput>
  }

  export type permissionsUpdateWithoutRole_permissionsInput = {
    perm_id?: IntFieldUpdateOperationsInput | number
    key?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
  }

  export type permissionsUncheckedUpdateWithoutRole_permissionsInput = {
    perm_id?: IntFieldUpdateOperationsInput | number
    key?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
  }

  export type rolesUpsertWithoutRole_permissionsInput = {
    update: XOR<rolesUpdateWithoutRole_permissionsInput, rolesUncheckedUpdateWithoutRole_permissionsInput>
    create: XOR<rolesCreateWithoutRole_permissionsInput, rolesUncheckedCreateWithoutRole_permissionsInput>
    where?: rolesWhereInput
  }

  export type rolesUpdateToOneWithWhereWithoutRole_permissionsInput = {
    where?: rolesWhereInput
    data: XOR<rolesUpdateWithoutRole_permissionsInput, rolesUncheckedUpdateWithoutRole_permissionsInput>
  }

  export type rolesUpdateWithoutRole_permissionsInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    users?: usersUpdateManyWithoutRolesNestedInput
  }

  export type rolesUncheckedUpdateWithoutRole_permissionsInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    users?: usersUncheckedUpdateManyWithoutRolesNestedInput
  }

  export type role_permissionsCreateWithoutRolesInput = {
    permissions: permissionsCreateNestedOneWithoutRole_permissionsInput
  }

  export type role_permissionsUncheckedCreateWithoutRolesInput = {
    perm_id: number
  }

  export type role_permissionsCreateOrConnectWithoutRolesInput = {
    where: role_permissionsWhereUniqueInput
    create: XOR<role_permissionsCreateWithoutRolesInput, role_permissionsUncheckedCreateWithoutRolesInput>
  }

  export type role_permissionsCreateManyRolesInputEnvelope = {
    data: role_permissionsCreateManyRolesInput | role_permissionsCreateManyRolesInput[]
    skipDuplicates?: boolean
  }

  export type usersCreateWithoutRolesInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessCreateNestedManyWithoutUsersInput
    user_device_access?: user_device_accessCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutUsersInput
    organisations: organisationsCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateWithoutRolesInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    organisation_id: bigint | number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessUncheckedCreateNestedManyWithoutUsersInput
    user_device_access?: user_device_accessUncheckedCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutUsersInput
  }

  export type usersCreateOrConnectWithoutRolesInput = {
    where: usersWhereUniqueInput
    create: XOR<usersCreateWithoutRolesInput, usersUncheckedCreateWithoutRolesInput>
  }

  export type usersCreateManyRolesInputEnvelope = {
    data: usersCreateManyRolesInput | usersCreateManyRolesInput[]
    skipDuplicates?: boolean
  }

  export type role_permissionsUpsertWithWhereUniqueWithoutRolesInput = {
    where: role_permissionsWhereUniqueInput
    update: XOR<role_permissionsUpdateWithoutRolesInput, role_permissionsUncheckedUpdateWithoutRolesInput>
    create: XOR<role_permissionsCreateWithoutRolesInput, role_permissionsUncheckedCreateWithoutRolesInput>
  }

  export type role_permissionsUpdateWithWhereUniqueWithoutRolesInput = {
    where: role_permissionsWhereUniqueInput
    data: XOR<role_permissionsUpdateWithoutRolesInput, role_permissionsUncheckedUpdateWithoutRolesInput>
  }

  export type role_permissionsUpdateManyWithWhereWithoutRolesInput = {
    where: role_permissionsScalarWhereInput
    data: XOR<role_permissionsUpdateManyMutationInput, role_permissionsUncheckedUpdateManyWithoutRolesInput>
  }

  export type usersUpsertWithWhereUniqueWithoutRolesInput = {
    where: usersWhereUniqueInput
    update: XOR<usersUpdateWithoutRolesInput, usersUncheckedUpdateWithoutRolesInput>
    create: XOR<usersCreateWithoutRolesInput, usersUncheckedCreateWithoutRolesInput>
  }

  export type usersUpdateWithWhereUniqueWithoutRolesInput = {
    where: usersWhereUniqueInput
    data: XOR<usersUpdateWithoutRolesInput, usersUncheckedUpdateWithoutRolesInput>
  }

  export type usersUpdateManyWithWhereWithoutRolesInput = {
    where: usersScalarWhereInput
    data: XOR<usersUpdateManyMutationInput, usersUncheckedUpdateManyWithoutRolesInput>
  }

  export type user_asset_accessCreateWithoutUsersInput = {
    is_allowed?: boolean
    assets: assetsCreateNestedOneWithoutUser_asset_accessInput
  }

  export type user_asset_accessUncheckedCreateWithoutUsersInput = {
    asset_id: bigint | number
    is_allowed?: boolean
  }

  export type user_asset_accessCreateOrConnectWithoutUsersInput = {
    where: user_asset_accessWhereUniqueInput
    create: XOR<user_asset_accessCreateWithoutUsersInput, user_asset_accessUncheckedCreateWithoutUsersInput>
  }

  export type user_asset_accessCreateManyUsersInputEnvelope = {
    data: user_asset_accessCreateManyUsersInput | user_asset_accessCreateManyUsersInput[]
    skipDuplicates?: boolean
  }

  export type user_device_accessCreateWithoutUsersInput = {
    is_allowed?: boolean
    devices: devicesCreateNestedOneWithoutUser_device_accessInput
  }

  export type user_device_accessUncheckedCreateWithoutUsersInput = {
    device_id: bigint | number
    is_allowed?: boolean
  }

  export type user_device_accessCreateOrConnectWithoutUsersInput = {
    where: user_device_accessWhereUniqueInput
    create: XOR<user_device_accessCreateWithoutUsersInput, user_device_accessUncheckedCreateWithoutUsersInput>
  }

  export type user_device_accessCreateManyUsersInputEnvelope = {
    data: user_device_accessCreateManyUsersInput | user_device_accessCreateManyUsersInput[]
    skipDuplicates?: boolean
  }

  export type user_organisation_accessCreateWithoutUsersInput = {
    is_allowed?: boolean
    organisations: organisationsCreateNestedOneWithoutUser_organisation_accessInput
  }

  export type user_organisation_accessUncheckedCreateWithoutUsersInput = {
    organisation_id: bigint | number
    is_allowed?: boolean
  }

  export type user_organisation_accessCreateOrConnectWithoutUsersInput = {
    where: user_organisation_accessWhereUniqueInput
    create: XOR<user_organisation_accessCreateWithoutUsersInput, user_organisation_accessUncheckedCreateWithoutUsersInput>
  }

  export type user_organisation_accessCreateManyUsersInputEnvelope = {
    data: user_organisation_accessCreateManyUsersInput | user_organisation_accessCreateManyUsersInput[]
    skipDuplicates?: boolean
  }

  export type organisationsCreateWithoutUsersInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedManyWithoutOrganisationsInput
    devices?: devicesCreateNestedManyWithoutOrganisationsInput
    organisations?: organisationsCreateNestedOneWithoutOther_organisationsInput
    other_organisations?: organisationsCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsUncheckedCreateWithoutUsersInput = {
    id?: bigint | number
    uuid?: string
    name: string
    parent_org_id?: bigint | number | null
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsUncheckedCreateNestedManyWithoutOrganisationsInput
    devices?: devicesUncheckedCreateNestedManyWithoutOrganisationsInput
    other_organisations?: organisationsUncheckedCreateNestedManyWithoutOrganisationsInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsCreateOrConnectWithoutUsersInput = {
    where: organisationsWhereUniqueInput
    create: XOR<organisationsCreateWithoutUsersInput, organisationsUncheckedCreateWithoutUsersInput>
  }

  export type rolesCreateWithoutUsersInput = {
    role_id: number
    name: string
    role_permissions?: role_permissionsCreateNestedManyWithoutRolesInput
  }

  export type rolesUncheckedCreateWithoutUsersInput = {
    role_id: number
    name: string
    role_permissions?: role_permissionsUncheckedCreateNestedManyWithoutRolesInput
  }

  export type rolesCreateOrConnectWithoutUsersInput = {
    where: rolesWhereUniqueInput
    create: XOR<rolesCreateWithoutUsersInput, rolesUncheckedCreateWithoutUsersInput>
  }

  export type user_asset_accessUpsertWithWhereUniqueWithoutUsersInput = {
    where: user_asset_accessWhereUniqueInput
    update: XOR<user_asset_accessUpdateWithoutUsersInput, user_asset_accessUncheckedUpdateWithoutUsersInput>
    create: XOR<user_asset_accessCreateWithoutUsersInput, user_asset_accessUncheckedCreateWithoutUsersInput>
  }

  export type user_asset_accessUpdateWithWhereUniqueWithoutUsersInput = {
    where: user_asset_accessWhereUniqueInput
    data: XOR<user_asset_accessUpdateWithoutUsersInput, user_asset_accessUncheckedUpdateWithoutUsersInput>
  }

  export type user_asset_accessUpdateManyWithWhereWithoutUsersInput = {
    where: user_asset_accessScalarWhereInput
    data: XOR<user_asset_accessUpdateManyMutationInput, user_asset_accessUncheckedUpdateManyWithoutUsersInput>
  }

  export type user_device_accessUpsertWithWhereUniqueWithoutUsersInput = {
    where: user_device_accessWhereUniqueInput
    update: XOR<user_device_accessUpdateWithoutUsersInput, user_device_accessUncheckedUpdateWithoutUsersInput>
    create: XOR<user_device_accessCreateWithoutUsersInput, user_device_accessUncheckedCreateWithoutUsersInput>
  }

  export type user_device_accessUpdateWithWhereUniqueWithoutUsersInput = {
    where: user_device_accessWhereUniqueInput
    data: XOR<user_device_accessUpdateWithoutUsersInput, user_device_accessUncheckedUpdateWithoutUsersInput>
  }

  export type user_device_accessUpdateManyWithWhereWithoutUsersInput = {
    where: user_device_accessScalarWhereInput
    data: XOR<user_device_accessUpdateManyMutationInput, user_device_accessUncheckedUpdateManyWithoutUsersInput>
  }

  export type user_organisation_accessUpsertWithWhereUniqueWithoutUsersInput = {
    where: user_organisation_accessWhereUniqueInput
    update: XOR<user_organisation_accessUpdateWithoutUsersInput, user_organisation_accessUncheckedUpdateWithoutUsersInput>
    create: XOR<user_organisation_accessCreateWithoutUsersInput, user_organisation_accessUncheckedCreateWithoutUsersInput>
  }

  export type user_organisation_accessUpdateWithWhereUniqueWithoutUsersInput = {
    where: user_organisation_accessWhereUniqueInput
    data: XOR<user_organisation_accessUpdateWithoutUsersInput, user_organisation_accessUncheckedUpdateWithoutUsersInput>
  }

  export type user_organisation_accessUpdateManyWithWhereWithoutUsersInput = {
    where: user_organisation_accessScalarWhereInput
    data: XOR<user_organisation_accessUpdateManyMutationInput, user_organisation_accessUncheckedUpdateManyWithoutUsersInput>
  }

  export type organisationsUpsertWithoutUsersInput = {
    update: XOR<organisationsUpdateWithoutUsersInput, organisationsUncheckedUpdateWithoutUsersInput>
    create: XOR<organisationsCreateWithoutUsersInput, organisationsUncheckedCreateWithoutUsersInput>
    where?: organisationsWhereInput
  }

  export type organisationsUpdateToOneWithWhereWithoutUsersInput = {
    where?: organisationsWhereInput
    data: XOR<organisationsUpdateWithoutUsersInput, organisationsUncheckedUpdateWithoutUsersInput>
  }

  export type organisationsUpdateWithoutUsersInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUpdateManyWithoutOrganisationsNestedInput
    organisations?: organisationsUpdateOneWithoutOther_organisationsNestedInput
    other_organisations?: organisationsUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUncheckedUpdateWithoutUsersInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    parent_org_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUncheckedUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUncheckedUpdateManyWithoutOrganisationsNestedInput
    other_organisations?: organisationsUncheckedUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutOrganisationsNestedInput
  }

  export type rolesUpsertWithoutUsersInput = {
    update: XOR<rolesUpdateWithoutUsersInput, rolesUncheckedUpdateWithoutUsersInput>
    create: XOR<rolesCreateWithoutUsersInput, rolesUncheckedCreateWithoutUsersInput>
    where?: rolesWhereInput
  }

  export type rolesUpdateToOneWithWhereWithoutUsersInput = {
    where?: rolesWhereInput
    data: XOR<rolesUpdateWithoutUsersInput, rolesUncheckedUpdateWithoutUsersInput>
  }

  export type rolesUpdateWithoutUsersInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    role_permissions?: role_permissionsUpdateManyWithoutRolesNestedInput
  }

  export type rolesUncheckedUpdateWithoutUsersInput = {
    role_id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    role_permissions?: role_permissionsUncheckedUpdateManyWithoutRolesNestedInput
  }

  export type organisationsCreateWithoutUser_organisation_accessInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedManyWithoutOrganisationsInput
    devices?: devicesCreateNestedManyWithoutOrganisationsInput
    organisations?: organisationsCreateNestedOneWithoutOther_organisationsInput
    other_organisations?: organisationsCreateNestedManyWithoutOrganisationsInput
    users?: usersCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsUncheckedCreateWithoutUser_organisation_accessInput = {
    id?: bigint | number
    uuid?: string
    name: string
    parent_org_id?: bigint | number | null
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsUncheckedCreateNestedManyWithoutOrganisationsInput
    devices?: devicesUncheckedCreateNestedManyWithoutOrganisationsInput
    other_organisations?: organisationsUncheckedCreateNestedManyWithoutOrganisationsInput
    users?: usersUncheckedCreateNestedManyWithoutOrganisationsInput
  }

  export type organisationsCreateOrConnectWithoutUser_organisation_accessInput = {
    where: organisationsWhereUniqueInput
    create: XOR<organisationsCreateWithoutUser_organisation_accessInput, organisationsUncheckedCreateWithoutUser_organisation_accessInput>
  }

  export type usersCreateWithoutUser_organisation_accessInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessCreateNestedManyWithoutUsersInput
    user_device_access?: user_device_accessCreateNestedManyWithoutUsersInput
    organisations: organisationsCreateNestedOneWithoutUsersInput
    roles: rolesCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateWithoutUser_organisation_accessInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    role_id: number
    organisation_id: bigint | number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessUncheckedCreateNestedManyWithoutUsersInput
    user_device_access?: user_device_accessUncheckedCreateNestedManyWithoutUsersInput
  }

  export type usersCreateOrConnectWithoutUser_organisation_accessInput = {
    where: usersWhereUniqueInput
    create: XOR<usersCreateWithoutUser_organisation_accessInput, usersUncheckedCreateWithoutUser_organisation_accessInput>
  }

  export type organisationsUpsertWithoutUser_organisation_accessInput = {
    update: XOR<organisationsUpdateWithoutUser_organisation_accessInput, organisationsUncheckedUpdateWithoutUser_organisation_accessInput>
    create: XOR<organisationsCreateWithoutUser_organisation_accessInput, organisationsUncheckedCreateWithoutUser_organisation_accessInput>
    where?: organisationsWhereInput
  }

  export type organisationsUpdateToOneWithWhereWithoutUser_organisation_accessInput = {
    where?: organisationsWhereInput
    data: XOR<organisationsUpdateWithoutUser_organisation_accessInput, organisationsUncheckedUpdateWithoutUser_organisation_accessInput>
  }

  export type organisationsUpdateWithoutUser_organisation_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUpdateManyWithoutOrganisationsNestedInput
    organisations?: organisationsUpdateOneWithoutOther_organisationsNestedInput
    other_organisations?: organisationsUpdateManyWithoutOrganisationsNestedInput
    users?: usersUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUncheckedUpdateWithoutUser_organisation_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    parent_org_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUncheckedUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUncheckedUpdateManyWithoutOrganisationsNestedInput
    other_organisations?: organisationsUncheckedUpdateManyWithoutOrganisationsNestedInput
    users?: usersUncheckedUpdateManyWithoutOrganisationsNestedInput
  }

  export type usersUpsertWithoutUser_organisation_accessInput = {
    update: XOR<usersUpdateWithoutUser_organisation_accessInput, usersUncheckedUpdateWithoutUser_organisation_accessInput>
    create: XOR<usersCreateWithoutUser_organisation_accessInput, usersUncheckedCreateWithoutUser_organisation_accessInput>
    where?: usersWhereInput
  }

  export type usersUpdateToOneWithWhereWithoutUser_organisation_accessInput = {
    where?: usersWhereInput
    data: XOR<usersUpdateWithoutUser_organisation_accessInput, usersUncheckedUpdateWithoutUser_organisation_accessInput>
  }

  export type usersUpdateWithoutUser_organisation_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUpdateManyWithoutUsersNestedInput
    user_device_access?: user_device_accessUpdateManyWithoutUsersNestedInput
    organisations?: organisationsUpdateOneRequiredWithoutUsersNestedInput
    roles?: rolesUpdateOneRequiredWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateWithoutUser_organisation_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role_id?: IntFieldUpdateOperationsInput | number
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_device_access?: user_device_accessUncheckedUpdateManyWithoutUsersNestedInput
  }

  export type assetsCreateWithoutUser_asset_accessInput = {
    id?: bigint | number
    uuid?: string | null
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    organisations?: organisationsCreateNestedOneWithoutAssetsInput
    devices?: devicesCreateNestedManyWithoutAssetsInput
  }

  export type assetsUncheckedCreateWithoutUser_asset_accessInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
    devices?: devicesUncheckedCreateNestedManyWithoutAssetsInput
  }

  export type assetsCreateOrConnectWithoutUser_asset_accessInput = {
    where: assetsWhereUniqueInput
    create: XOR<assetsCreateWithoutUser_asset_accessInput, assetsUncheckedCreateWithoutUser_asset_accessInput>
  }

  export type usersCreateWithoutUser_asset_accessInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_device_access?: user_device_accessCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutUsersInput
    organisations: organisationsCreateNestedOneWithoutUsersInput
    roles: rolesCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateWithoutUser_asset_accessInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    role_id: number
    organisation_id: bigint | number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_device_access?: user_device_accessUncheckedCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutUsersInput
  }

  export type usersCreateOrConnectWithoutUser_asset_accessInput = {
    where: usersWhereUniqueInput
    create: XOR<usersCreateWithoutUser_asset_accessInput, usersUncheckedCreateWithoutUser_asset_accessInput>
  }

  export type assetsUpsertWithoutUser_asset_accessInput = {
    update: XOR<assetsUpdateWithoutUser_asset_accessInput, assetsUncheckedUpdateWithoutUser_asset_accessInput>
    create: XOR<assetsCreateWithoutUser_asset_accessInput, assetsUncheckedCreateWithoutUser_asset_accessInput>
    where?: assetsWhereInput
  }

  export type assetsUpdateToOneWithWhereWithoutUser_asset_accessInput = {
    where?: assetsWhereInput
    data: XOR<assetsUpdateWithoutUser_asset_accessInput, assetsUncheckedUpdateWithoutUser_asset_accessInput>
  }

  export type assetsUpdateWithoutUser_asset_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    organisations?: organisationsUpdateOneRequiredWithoutAssetsNestedInput
    devices?: devicesUpdateManyWithoutAssetsNestedInput
  }

  export type assetsUncheckedUpdateWithoutUser_asset_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    devices?: devicesUncheckedUpdateManyWithoutAssetsNestedInput
  }

  export type usersUpsertWithoutUser_asset_accessInput = {
    update: XOR<usersUpdateWithoutUser_asset_accessInput, usersUncheckedUpdateWithoutUser_asset_accessInput>
    create: XOR<usersCreateWithoutUser_asset_accessInput, usersUncheckedCreateWithoutUser_asset_accessInput>
    where?: usersWhereInput
  }

  export type usersUpdateToOneWithWhereWithoutUser_asset_accessInput = {
    where?: usersWhereInput
    data: XOR<usersUpdateWithoutUser_asset_accessInput, usersUncheckedUpdateWithoutUser_asset_accessInput>
  }

  export type usersUpdateWithoutUser_asset_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_device_access?: user_device_accessUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutUsersNestedInput
    organisations?: organisationsUpdateOneRequiredWithoutUsersNestedInput
    roles?: rolesUpdateOneRequiredWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateWithoutUser_asset_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role_id?: IntFieldUpdateOperationsInput | number
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_device_access?: user_device_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutUsersNestedInput
  }

  export type devicesCreateWithoutUser_device_accessInput = {
    id?: bigint | number
    uuid?: string | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
    assets?: assetsCreateNestedOneWithoutDevicesInput
    organisations?: organisationsCreateNestedOneWithoutDevicesInput
  }

  export type devicesUncheckedCreateWithoutUser_device_accessInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    asset_id?: bigint | number | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type devicesCreateOrConnectWithoutUser_device_accessInput = {
    where: devicesWhereUniqueInput
    create: XOR<devicesCreateWithoutUser_device_accessInput, devicesUncheckedCreateWithoutUser_device_accessInput>
  }

  export type usersCreateWithoutUser_device_accessInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessCreateNestedManyWithoutUsersInput
    organisations: organisationsCreateNestedOneWithoutUsersInput
    roles: rolesCreateNestedOneWithoutUsersInput
  }

  export type usersUncheckedCreateWithoutUser_device_accessInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    role_id: number
    organisation_id: bigint | number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
    user_asset_access?: user_asset_accessUncheckedCreateNestedManyWithoutUsersInput
    user_organisation_access?: user_organisation_accessUncheckedCreateNestedManyWithoutUsersInput
  }

  export type usersCreateOrConnectWithoutUser_device_accessInput = {
    where: usersWhereUniqueInput
    create: XOR<usersCreateWithoutUser_device_accessInput, usersUncheckedCreateWithoutUser_device_accessInput>
  }

  export type devicesUpsertWithoutUser_device_accessInput = {
    update: XOR<devicesUpdateWithoutUser_device_accessInput, devicesUncheckedUpdateWithoutUser_device_accessInput>
    create: XOR<devicesCreateWithoutUser_device_accessInput, devicesUncheckedCreateWithoutUser_device_accessInput>
    where?: devicesWhereInput
  }

  export type devicesUpdateToOneWithWhereWithoutUser_device_accessInput = {
    where?: devicesWhereInput
    data: XOR<devicesUpdateWithoutUser_device_accessInput, devicesUncheckedUpdateWithoutUser_device_accessInput>
  }

  export type devicesUpdateWithoutUser_device_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateOneWithoutDevicesNestedInput
    organisations?: organisationsUpdateOneRequiredWithoutDevicesNestedInput
  }

  export type devicesUncheckedUpdateWithoutUser_device_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type usersUpsertWithoutUser_device_accessInput = {
    update: XOR<usersUpdateWithoutUser_device_accessInput, usersUncheckedUpdateWithoutUser_device_accessInput>
    create: XOR<usersCreateWithoutUser_device_accessInput, usersUncheckedCreateWithoutUser_device_accessInput>
    where?: usersWhereInput
  }

  export type usersUpdateToOneWithWhereWithoutUser_device_accessInput = {
    where?: usersWhereInput
    data: XOR<usersUpdateWithoutUser_device_accessInput, usersUncheckedUpdateWithoutUser_device_accessInput>
  }

  export type usersUpdateWithoutUser_device_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutUsersNestedInput
    organisations?: organisationsUpdateOneRequiredWithoutUsersNestedInput
    roles?: rolesUpdateOneRequiredWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateWithoutUser_device_accessInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role_id?: IntFieldUpdateOperationsInput | number
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutUsersNestedInput
  }

  export type devicesCreateManyAssetsInput = {
    id?: bigint | number
    uuid?: string | null
    organisation_id?: bigint | number
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type user_asset_accessCreateManyAssetsInput = {
    user_id: bigint | number
    is_allowed?: boolean
  }

  export type devicesUpdateWithoutAssetsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    organisations?: organisationsUpdateOneRequiredWithoutDevicesNestedInput
    user_device_access?: user_device_accessUpdateManyWithoutDevicesNestedInput
  }

  export type devicesUncheckedUpdateWithoutAssetsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    user_device_access?: user_device_accessUncheckedUpdateManyWithoutDevicesNestedInput
  }

  export type devicesUncheckedUpdateManyWithoutAssetsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type user_asset_accessUpdateWithoutAssetsInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    users?: usersUpdateOneRequiredWithoutUser_asset_accessNestedInput
  }

  export type user_asset_accessUncheckedUpdateWithoutAssetsInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_asset_accessUncheckedUpdateManyWithoutAssetsInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_device_accessCreateManyDevicesInput = {
    user_id: bigint | number
    is_allowed?: boolean
  }

  export type user_device_accessUpdateWithoutDevicesInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    users?: usersUpdateOneRequiredWithoutUser_device_accessNestedInput
  }

  export type user_device_accessUncheckedUpdateWithoutDevicesInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_device_accessUncheckedUpdateManyWithoutDevicesInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type assetsCreateManyOrganisationsInput = {
    id?: bigint | number
    uuid?: string | null
    name: string
    asset_type?: string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type devicesCreateManyOrganisationsInput = {
    id?: bigint | number
    uuid?: string | null
    asset_id?: bigint | number | null
    external_id: string
    external_id_type: string
    protocol?: string | null
    vendor?: string | null
    model?: string | null
    status?: string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: Date | string
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type organisationsCreateManyOrganisationsInput = {
    id?: bigint | number
    uuid?: string
    name: string
    path?: string | null
    maps_api_key?: string | null
    can_inherit_key?: boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: Date | string
    updated_at?: Date | string
  }

  export type user_organisation_accessCreateManyOrganisationsInput = {
    user_id: bigint | number
    is_allowed?: boolean
  }

  export type usersCreateManyOrganisationsInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    role_id: number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
  }

  export type assetsUpdateWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    devices?: devicesUpdateManyWithoutAssetsNestedInput
    user_asset_access?: user_asset_accessUpdateManyWithoutAssetsNestedInput
  }

  export type assetsUncheckedUpdateWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    devices?: devicesUncheckedUpdateManyWithoutAssetsNestedInput
    user_asset_access?: user_asset_accessUncheckedUpdateManyWithoutAssetsNestedInput
  }

  export type assetsUncheckedUpdateManyWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    name?: StringFieldUpdateOperationsInput | string
    asset_type?: NullableStringFieldUpdateOperationsInput | string | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type devicesUpdateWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateOneWithoutDevicesNestedInput
    user_device_access?: user_device_accessUpdateManyWithoutDevicesNestedInput
  }

  export type devicesUncheckedUpdateWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    user_device_access?: user_device_accessUncheckedUpdateManyWithoutDevicesNestedInput
  }

  export type devicesUncheckedUpdateManyWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: NullableStringFieldUpdateOperationsInput | string | null
    asset_id?: NullableBigIntFieldUpdateOperationsInput | bigint | number | null
    external_id?: StringFieldUpdateOperationsInput | string
    external_id_type?: StringFieldUpdateOperationsInput | string
    protocol?: NullableStringFieldUpdateOperationsInput | string | null
    vendor?: NullableStringFieldUpdateOperationsInput | string | null
    model?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    attributes?: JsonNullValueInput | InputJsonValue
    last_telemetry?: JsonNullValueInput | InputJsonValue
    last_telemetry_ts?: DateTimeFieldUpdateOperationsInput | Date | string
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type organisationsUpdateWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUpdateManyWithoutOrganisationsNestedInput
    other_organisations?: organisationsUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutOrganisationsNestedInput
    users?: usersUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUncheckedUpdateWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    assets?: assetsUncheckedUpdateManyWithoutOrganisationsNestedInput
    devices?: devicesUncheckedUpdateManyWithoutOrganisationsNestedInput
    other_organisations?: organisationsUncheckedUpdateManyWithoutOrganisationsNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutOrganisationsNestedInput
    users?: usersUncheckedUpdateManyWithoutOrganisationsNestedInput
  }

  export type organisationsUncheckedUpdateManyWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: NullableStringFieldUpdateOperationsInput | string | null
    maps_api_key?: NullableStringFieldUpdateOperationsInput | string | null
    can_inherit_key?: NullableBoolFieldUpdateOperationsInput | boolean | null
    attributes?: JsonNullValueInput | InputJsonValue
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type user_organisation_accessUpdateWithoutOrganisationsInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    users?: usersUpdateOneRequiredWithoutUser_organisation_accessNestedInput
  }

  export type user_organisation_accessUncheckedUpdateWithoutOrganisationsInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_organisation_accessUncheckedUpdateManyWithoutOrganisationsInput = {
    user_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type usersUpdateWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUpdateManyWithoutUsersNestedInput
    user_device_access?: user_device_accessUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutUsersNestedInput
    roles?: rolesUpdateOneRequiredWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role_id?: IntFieldUpdateOperationsInput | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_device_access?: user_device_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateManyWithoutOrganisationsInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role_id?: IntFieldUpdateOperationsInput | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
  }

  export type role_permissionsCreateManyPermissionsInput = {
    role_id: number
  }

  export type role_permissionsUpdateWithoutPermissionsInput = {
    roles?: rolesUpdateOneRequiredWithoutRole_permissionsNestedInput
  }

  export type role_permissionsUncheckedUpdateWithoutPermissionsInput = {
    role_id?: IntFieldUpdateOperationsInput | number
  }

  export type role_permissionsUncheckedUpdateManyWithoutPermissionsInput = {
    role_id?: IntFieldUpdateOperationsInput | number
  }

  export type role_permissionsCreateManyRolesInput = {
    perm_id: number
  }

  export type usersCreateManyRolesInput = {
    id?: bigint | number
    uuid?: string
    first_name: string
    last_name: string
    email: string
    password_hash: string
    organisation_id: bigint | number
    active?: boolean
    last_login_at?: Date | string | null
    created_at?: Date | string
    updated_at?: Date | string
    token_version?: number
  }

  export type role_permissionsUpdateWithoutRolesInput = {
    permissions?: permissionsUpdateOneRequiredWithoutRole_permissionsNestedInput
  }

  export type role_permissionsUncheckedUpdateWithoutRolesInput = {
    perm_id?: IntFieldUpdateOperationsInput | number
  }

  export type role_permissionsUncheckedUpdateManyWithoutRolesInput = {
    perm_id?: IntFieldUpdateOperationsInput | number
  }

  export type usersUpdateWithoutRolesInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUpdateManyWithoutUsersNestedInput
    user_device_access?: user_device_accessUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUpdateManyWithoutUsersNestedInput
    organisations?: organisationsUpdateOneRequiredWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateWithoutRolesInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
    user_asset_access?: user_asset_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_device_access?: user_device_accessUncheckedUpdateManyWithoutUsersNestedInput
    user_organisation_access?: user_organisation_accessUncheckedUpdateManyWithoutUsersNestedInput
  }

  export type usersUncheckedUpdateManyWithoutRolesInput = {
    id?: BigIntFieldUpdateOperationsInput | bigint | number
    uuid?: StringFieldUpdateOperationsInput | string
    first_name?: StringFieldUpdateOperationsInput | string
    last_name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    active?: BoolFieldUpdateOperationsInput | boolean
    last_login_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    updated_at?: DateTimeFieldUpdateOperationsInput | Date | string
    token_version?: IntFieldUpdateOperationsInput | number
  }

  export type user_asset_accessCreateManyUsersInput = {
    asset_id: bigint | number
    is_allowed?: boolean
  }

  export type user_device_accessCreateManyUsersInput = {
    device_id: bigint | number
    is_allowed?: boolean
  }

  export type user_organisation_accessCreateManyUsersInput = {
    organisation_id: bigint | number
    is_allowed?: boolean
  }

  export type user_asset_accessUpdateWithoutUsersInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    assets?: assetsUpdateOneRequiredWithoutUser_asset_accessNestedInput
  }

  export type user_asset_accessUncheckedUpdateWithoutUsersInput = {
    asset_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_asset_accessUncheckedUpdateManyWithoutUsersInput = {
    asset_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_device_accessUpdateWithoutUsersInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    devices?: devicesUpdateOneRequiredWithoutUser_device_accessNestedInput
  }

  export type user_device_accessUncheckedUpdateWithoutUsersInput = {
    device_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_device_accessUncheckedUpdateManyWithoutUsersInput = {
    device_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_organisation_accessUpdateWithoutUsersInput = {
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
    organisations?: organisationsUpdateOneRequiredWithoutUser_organisation_accessNestedInput
  }

  export type user_organisation_accessUncheckedUpdateWithoutUsersInput = {
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type user_organisation_accessUncheckedUpdateManyWithoutUsersInput = {
    organisation_id?: BigIntFieldUpdateOperationsInput | bigint | number
    is_allowed?: BoolFieldUpdateOperationsInput | boolean
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}