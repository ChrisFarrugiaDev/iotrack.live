### go-chi/chi

https://github.com/go-chi/chi

    go get -u github.com/go-chi/chi/v5
    go get -u github.com/go-chi/chi/v5/middleware

https://github.com/go-chi/cors

    go get github.com/go-chi/cors
