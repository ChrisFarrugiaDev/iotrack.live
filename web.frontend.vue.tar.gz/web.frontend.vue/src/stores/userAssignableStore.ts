import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { useAppStore } from './appStore';
import axios from '@/axios';
import type { Asset } from '@/types/asset.type';


export const useUserAssignableStore = defineStore('userAssignableStore', () => {

    // ---- Types ------------------------------------------------------

    type TreeNode = {
        id: number | string
        label: string
        children?: TreeNode[]
    }

    const appStore = useAppStore();


    // ---- State ------------------------------------------------------

    const selectedOrgId = ref<string>('0');
    const fetchedOrgIds = ref<string[]>([]);
    const assignableResources = ref<Record<string, any>>({});


    // ---- Getters ----------------------------------------------------

    const getAssignableResources = computed(() => {
        return assignableResources.value;
    });

    const getSelectedOrgId = computed(()=>{
        return selectedOrgId.value;
    });

    const getGroupedAssets = computed(()=>{
        return buildAssetsTree();
    });

    const getGroupedOrganisations = computed(()=>{
        return buildOrgTree();
    });

    // ---- Actions ----------------------------------------------------


    async function fetchAssignableResources(org_id: string) {
        try {

            if (fetchedOrgIds.value.includes(org_id)) { 
                selectedOrgId.value = org_id;
                return; 
            }


            const url = `${appStore.getAppUrl}/api/user/assignment-options`;
            const result = await axios.request({
                method: 'POST',
                url,
                data: { org_id }
            });

            fetchedOrgIds.value.push(org_id);
            selectedOrgId.value = org_id;

            assignableResources.value[org_id] = result.data.data


        } catch (err) {
            console.error('! useAssignableStore fetchAssignableResources !\n', err);
            throw err;
        }
    }

    function buildOrgTree() {

        const orgId = selectedOrgId.value;

        const orgs = assignableResources.value[orgId]?.organisation;

        const rootToSkipId = orgId;

        if (!orgs || !rootToSkipId) {

            const r: Record<string, any>[] = []
            return r;
        } 

        // nodeMap is an internal lookup table used while constructing the tree.
        // - Each key is an organisation ID (string) eg: ("1", "2", "4", etc.).
        // - Each value is a TreeNode, but with `children` ALWAYS defined as an array.
        //   (TreeNode normally has optional children, but for building the tree we
        //    want a guaranteed empty array so we can safely push child nodes into it
        //    without checking for undefined.)
        const nodeMap: Record<string, TreeNode & { children: TreeNode[] }> = {};

        Object.values(orgs as Record<string, any>).forEach((org) => {


            nodeMap[org.id] = {
                id: org.id,
                label: org.name,
                children: [],
            };
        });

        const topLevel: TreeNode[] = [];

        // Second: link children to parents, and decide top-level nodes
        Object.values(orgs as Record<string, any>).forEach((org) => {

            if (org.id === rootToSkipId) {
                // We completely skip this org in the tree
                return;
            }


            const parentId = org.parent_org_id ?? null;

            if (parentId === rootToSkipId) {
                // Direct child of the skipped root → becomes top-level
                topLevel.push(nodeMap[org.id]);
            } else if (parentId && nodeMap[parentId]) {
                // Normal child → attach to its parent
                nodeMap[parentId].children.push(nodeMap[org.id]);
            } else {
                // No parent or parent not in map → also treat as top-level
                topLevel.push(nodeMap[org.id]);
            }
        });

        // Optionally clean up empty children arrays
        const stripEmptyChildren = (node: TreeNode & { children?: TreeNode[] }): TreeNode => {
            const { id, label, children } = node;
            if (!children || children.length === 0) {
                return { id, label };
            }
            return {
                id,
                label,
                children: children.map(stripEmptyChildren),
            };
        };

        return topLevel.map(stripEmptyChildren);
    }



    function buildAssetsTree() {

        const orgId = selectedOrgId.value;
        
        // Object to store groupings: { [orgName]: TreeNode }
        const groupedAssets: Record<string, TreeNode> = {};

        const orgs = assignableResources.value[orgId]?.organisation;
        const assets = assignableResources.value[orgId]?.assets as Record<string, Asset>;  

        if (!assets || !orgs) return groupedAssets;

        const assetsList = Object.values(assets);


        for (const asset of assetsList) {
            // Find the organisation for this asset
            const organisation = orgs[asset.organisation_id];
            if (!organisation) continue; // skip if no org (defensive)

            // Create org group node if not exists
            if (!(organisation.name in groupedAssets)) {
                groupedAssets[organisation.name] = {
                    label: organisation.name,
                    id: organisation.name,
                    children: []
                }
            }

            // Add asset as child node under its org
            groupedAssets[organisation.name]!.children!.push({
                label: asset.name,
                id: asset.id,
            });
        }
        return groupedAssets;
    }



    // - Expose --------------------------------------------------------
    return { 
        fetchAssignableResources, 
        buildOrgTree, 
        buildAssetsTree,
        getAssignableResources,
        getGroupedAssets,
        getGroupedOrganisations,
        getSelectedOrgId,
    };
});
