import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import type { Organisation } from '@/types/organisation.type';

export const useOrganisationStore = defineStore('organisationStore', () => {

    
    type TreeNode = {
        id: string;
        label: string;
        children?: TreeNode[];
    };

    // ---- State ------------------------------------------------------

    const organisation = ref<Record<string, string> | null>(null);
    const organisationScope = ref<Record<string, any> | null>(null);

    // ---- Getters ----------------------------------------------------

    const getOrganisation = computed(() => organisation.value);
    const getOrganisationScope = computed(() => organisationScope.value);

    const getChildrenIds = computed(() => {

        const parentOrg = organisation.value;

        const orgs = {...organisationScope.value};

        if (orgs && parentOrg) {
            delete orgs[parentOrg.id]
            return Object.keys(orgs);
            
        } else {
            return [];
        }
    });

    // ---- Setters (Actions) ------------------------------------------

    function setOrganisation(val: Record<string, string> | null) {
        organisation.value = val
    }
    function setOrganisationScope(val: Record<string, any> | null) {
        organisationScope.value = val
    }

    function clear() {
        organisation.value = null;
        organisationScope.value = null;
    }

    // ---- Expose -----------------------------------------------------
    return {

        getOrganisation,
        setOrganisation,

        getOrganisationScope,
        setOrganisationScope,  
        getChildrenIds,

        clear,
    }
});
