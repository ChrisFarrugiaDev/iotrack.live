import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useTempStore = defineStore('tempStore', () => {

    // ---- State ------------------------------------------------------



    // ---- Getters ----------------------------------------------------



    // ---- Actions ----------------------------------------------------


    // - Expose --------------------------------------------------------
    return { };
});
