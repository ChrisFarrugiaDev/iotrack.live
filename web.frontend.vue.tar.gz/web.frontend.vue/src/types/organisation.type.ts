export interface Organisation {


  id: string,
  uuid: string, 
  name: string,

}