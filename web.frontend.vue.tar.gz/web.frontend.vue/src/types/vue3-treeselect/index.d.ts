// src/types/vue3-treeselect.d.ts
declare module 'vue3-treeselect' {
  import type { DefineComponent } from 'vue';
  const Treeselect: DefineComponent<Record<string, unknown>, {}, any>;
  export default Treeselect;
}
