<template>
	<main class="map">
		<TheMap></TheMap>
	</main>
</template>

<!-- --------------------------------------------------------------- -->

<script setup lang="ts">
import TheMap from "../components/map/TheMap.vue";
</script>

<!-- --------------------------------------------------------------- -->

<style lang="scss" scoped>
.map {
    // width: 100%;
    // height: 100%;
    // background-image: url('@/assets/images/sample-map.png');
	// background-size: cover;
	// background-repeat: no-repeat;
	// background-position: center;
}
</style>